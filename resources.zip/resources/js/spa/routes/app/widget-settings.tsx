import { useMutation, useQuery } from '@tanstack/react-query';
import { ArrowLeft, Bot, Code2, Copy, Download, Globe2, Layers3, Loader2, Save, Settings2, ShieldCheck, Sparkles, Wrench } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { toast } from 'sonner';

import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { ApiError, apiRequest } from '@/spa/lib/api';
import { authHeaders } from '@/spa/lib/auth-token';
import { queryClient } from '@/spa/lib/query-client';

type WidgetKnowledge = {
    id: string;
    name: string;
    type: 'text' | 'url' | 'pdf';
    source_url?: string | null;
    status: 'processing' | 'ready' | 'failed';
    content: string;
};

type WidgetTool = {
    id: string;
    tool_type: 'http' | 'mcp_server';
    name: string;
    description: string;
    endpoint_url: string;
    method: string;
    transport?: string | null;
    is_active: boolean;
};

type WidgetWebsiteSourcePage = {
    id: string;
    url: string;
    path: string;
    title?: string | null;
    status: 'queued' | 'crawling' | 'ready' | 'failed' | 'skipped';
    failure_reason?: string | null;
    last_crawled_at?: string | null;
    knowledge_item_id?: string | null;
};

type WidgetWebsiteSource = {
    id: string;
    source_type: 'wordpress_url' | 'wordpress_plugin';
    site_name?: string | null;
    site_url: string;
    site_host: string;
    is_wordpress: boolean;
    verification_method?: 'meta_tag' | 'file' | null;
    verification_status: 'pending' | 'verified' | 'failed';
    verification_token: string;
    verification_meta_tag: string;
    verification_filename: string;
    verification_file_content: string;
    connection_token?: string | null;
    connection_secret?: string | null;
    plugin_sync_url?: string | null;
    crawl_status: 'idle' | 'queued' | 'crawling' | 'completed' | 'failed';
    include_paths: string[];
    exclude_paths: string[];
    seed_urls: string[];
    settings: {
        recrawl_interval_hours?: number;
    };
    last_verified_at?: string | null;
    last_crawled_at?: string | null;
    last_sync_at?: string | null;
    next_recrawl_at?: string | null;
    is_active: boolean;
    stats: {
        pages_total: number;
        pages_ready: number;
        pages_failed: number;
        pages_skipped: number;
    };
    pages: WidgetWebsiteSourcePage[];
};

type WidgetDetail = {
    id: string;
    name: string;
    token: string;
    bot_name: string;
    greeting: string;
    theme_color: string;
    avatar_url?: string | null;
    system_prompt?: string | null;
    is_active: boolean;
    allow_file_uploads: boolean;
    allowed_domains: string[];
    knowledge: WidgetKnowledge[];
    website_sources: WidgetWebsiteSource[];
    tools: WidgetTool[];
    embed_script_url: string;
    embed_code: string;
    preview_url: string;
    analytics: {
        sessions: number;
        messages: number;
    };
};

export function Component() {
    const { widgetId } = useParams();
    const [widget, setWidget] = useState<WidgetDetail | null>(null);
    const [textKnowledge, setTextKnowledge] = useState({ name: '', content: '' });
    const [urlKnowledge, setUrlKnowledge] = useState({ name: '', url: '' });
    const [websiteSourceForm, setWebsiteSourceForm] = useState({
        source_type: 'wordpress_url' as 'wordpress_url' | 'wordpress_plugin',
        site_name: '',
        site_url: '',
        verification_method: 'meta_tag' as 'meta_tag' | 'file',
        include_paths: '',
        exclude_paths: '',
        seed_urls: '',
        scope_mode: 'safe_public' as 'safe_public' | 'custom',
        recrawl_interval_hours: '24',
    });
    const [toolForm, setToolForm] = useState({
        tool_type: 'http' as 'http' | 'mcp_server',
        name: '',
        description: '',
        endpoint_url: '',
        method: 'GET',
        transport: 'http',
        headers: '{}',
        parameters: '{ "type": "object", "properties": {} }',
        configuration: '{}',
    });

    const widgetQuery = useQuery({
        queryKey: ['spa', 'widget', widgetId],
        queryFn: async () => apiRequest<{ widget: WidgetDetail }>(`/api/widget/${widgetId}`),
        enabled: Boolean(widgetId),
    });

    useEffect(() => {
        if (widgetQuery.data?.widget) {
            setWidget(widgetQuery.data.widget);
        }
    }, [widgetQuery.data?.widget]);

    const saveMutation = useMutation({
        mutationFn: () => apiRequest(`/api/widget/${widgetId}`, { method: 'PUT', json: widget }),
        onSuccess: async () => {
            toast.success('Widget updated');
            await Promise.all([
                queryClient.invalidateQueries({ queryKey: ['spa', 'widget', widgetId] }),
                queryClient.invalidateQueries({ queryKey: ['spa', 'widgets'] }),
            ]);
        },
        onError: (error) => toast.error(error instanceof ApiError ? error.message : 'Failed to save widget.'),
    });

    const addTextMutation = useMutation({
        mutationFn: () => apiRequest(`/api/widget/${widgetId}/knowledge`, { method: 'POST', json: { type: 'text', name: textKnowledge.name || 'Text note', content: textKnowledge.content } }),
        onSuccess: async () => {
            toast.success('Text knowledge added');
            setTextKnowledge({ name: '', content: '' });
            await queryClient.invalidateQueries({ queryKey: ['spa', 'widget', widgetId] });
        },
        onError: (error) => toast.error(error instanceof ApiError ? error.message : 'Failed to save text knowledge.'),
    });

    const addUrlMutation = useMutation({
        mutationFn: () => apiRequest(`/api/widget/${widgetId}/knowledge`, { method: 'POST', json: { type: 'url', name: urlKnowledge.name || urlKnowledge.url, url: urlKnowledge.url } }),
        onSuccess: async () => {
            toast.success('URL knowledge added');
            setUrlKnowledge({ name: '', url: '' });
            await queryClient.invalidateQueries({ queryKey: ['spa', 'widget', widgetId] });
        },
        onError: (error) => toast.error(error instanceof ApiError ? error.message : 'Failed to fetch URL knowledge.'),
    });

    const addWebsiteSourceMutation = useMutation({
        mutationFn: () => apiRequest(`/api/widget/${widgetId}/website-sources`, {
            method: 'POST',
            json: {
                source_type: websiteSourceForm.source_type,
                site_name: websiteSourceForm.site_name || null,
                site_url: websiteSourceForm.site_url,
                verification_method: websiteSourceForm.source_type === 'wordpress_url' ? websiteSourceForm.verification_method : null,
                include_paths: splitLines(websiteSourceForm.include_paths),
                exclude_paths: splitLines(websiteSourceForm.exclude_paths),
                seed_urls: splitLines(websiteSourceForm.seed_urls),
                scope_mode: websiteSourceForm.scope_mode,
                recrawl_interval_hours: Number(websiteSourceForm.recrawl_interval_hours || '24'),
            },
        }),
        onSuccess: async () => {
            toast.success('Website source connected');
            setWebsiteSourceForm({
                source_type: 'wordpress_url',
                site_name: '',
                site_url: '',
                verification_method: 'meta_tag',
                include_paths: '',
                exclude_paths: '',
                seed_urls: '',
                scope_mode: 'safe_public',
                recrawl_interval_hours: '24',
            });
            await queryClient.invalidateQueries({ queryKey: ['spa', 'widget', widgetId] });
        },
        onError: (error) => toast.error(error instanceof ApiError ? error.message : 'Failed to connect website source.'),
    });

    const verifyWebsiteSourceMutation = useMutation({
        mutationFn: (sourceId: string) => apiRequest(`/api/widget/${widgetId}/website-sources/${sourceId}/verify`, { method: 'POST' }),
        onSuccess: async () => {
            toast.success('Verification check completed');
            await queryClient.invalidateQueries({ queryKey: ['spa', 'widget', widgetId] });
        },
        onError: (error) => toast.error(error instanceof ApiError ? error.message : 'Failed to verify website source.'),
    });

    const crawlWebsiteSourceMutation = useMutation({
        mutationFn: (sourceId: string) => apiRequest(`/api/widget/${widgetId}/website-sources/${sourceId}/crawl`, { method: 'POST' }),
        onSuccess: async () => {
            toast.success('Website crawl queued');
            await queryClient.invalidateQueries({ queryKey: ['spa', 'widget', widgetId] });
        },
        onError: (error) => toast.error(error instanceof ApiError ? error.message : 'Failed to queue website crawl.'),
    });

    const uploadPdfMutation = useMutation({
        mutationFn: async (file: File) => {
            const formData = new FormData();
            formData.append('file', file);
            const response = await fetch(`/api/widget/${widgetId}/knowledge/pdf`, {
                method: 'POST',
                body: formData,
                credentials: 'same-origin',
                headers: {
                    Accept: 'application/json',
                    ...authHeaders(),
                    ...xsrfHeader(),
                },
            });

            if (!response.ok) {
                const payload = await response.json().catch(() => ({}));
                throw new Error(payload.message || 'Failed to upload PDF.');
            }

            return response.json();
        },
        onSuccess: async () => {
            toast.success('PDF knowledge uploaded');
            await queryClient.invalidateQueries({ queryKey: ['spa', 'widget', widgetId] });
        },
        onError: (error) => toast.error(error instanceof Error ? error.message : 'Failed to upload PDF.'),
    });

    const addToolMutation = useMutation({
        mutationFn: () => apiRequest(`/api/widget/${widgetId}/tools`, {
            method: 'POST',
            json: {
                tool_type: toolForm.tool_type,
                name: toolForm.name,
                description: toolForm.description,
                endpoint_url: toolForm.endpoint_url,
                method: toolForm.method,
                transport: toolForm.transport,
                headers: parseJson(toolForm.headers),
                parameters: parseJson(toolForm.parameters),
                configuration: parseJson(toolForm.configuration),
                is_active: true,
            },
        }),
        onSuccess: async () => {
            toast.success('Tool saved');
            setToolForm({
                tool_type: 'http',
                name: '',
                description: '',
                endpoint_url: '',
                method: 'GET',
                transport: 'http',
                headers: '{}',
                parameters: '{ "type": "object", "properties": {} }',
                configuration: '{}',
            });
            await queryClient.invalidateQueries({ queryKey: ['spa', 'widget', widgetId] });
        },
        onError: (error) => toast.error(error instanceof ApiError ? error.message : 'Failed to save tool.'),
    });

    const deleteKnowledgeMutation = useMutation({
        mutationFn: (knowledgeId: string) => apiRequest(`/api/widget/${widgetId}/knowledge/${knowledgeId}`, { method: 'DELETE' }),
        onSuccess: async () => {
            await queryClient.invalidateQueries({ queryKey: ['spa', 'widget', widgetId] });
        },
    });

    const deleteToolMutation = useMutation({
        mutationFn: (toolId: string) => apiRequest(`/api/widget/${widgetId}/tools/${toolId}`, { method: 'DELETE' }),
        onSuccess: async () => {
            await queryClient.invalidateQueries({ queryKey: ['spa', 'widget', widgetId] });
        },
    });

    if (widgetQuery.isLoading || !widget) {
        return (
            <div className="mx-auto flex w-full max-w-6xl flex-col gap-4">
                <Skeleton className="h-48 w-full rounded-[32px]" />
                <Skeleton className="h-[720px] w-full rounded-[32px]" />
            </div>
        );
    }

    return (
        <div className="mx-auto flex w-full max-w-7xl flex-col gap-6">
            <section className="relative overflow-hidden rounded-[32px] border border-border/60 bg-card px-6 py-7 shadow-sm sm:px-8">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(59,130,246,0.12),transparent_30%),radial-gradient(circle_at_bottom_right,rgba(16,185,129,0.12),transparent_26%)]" />
                <div className="relative flex flex-col gap-6 xl:flex-row xl:items-end xl:justify-between">
                    <div className="space-y-3">
                        <Button asChild variant="ghost" className="w-fit px-0 text-muted-foreground hover:text-foreground">
                            <Link to="/widget">
                                <ArrowLeft className="mr-2 h-4 w-4" />
                                Back to widgets
                            </Link>
                        </Button>
                        <div className="space-y-2">
                            <div className="flex items-center gap-2">
                                <h1 className="text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">{widget.name}</h1>
                                <Badge variant={widget.is_active ? 'default' : 'secondary'}>
                                    {widget.is_active ? 'Live' : 'Paused'}
                                </Badge>
                            </div>
                            <p className="max-w-2xl text-sm leading-6 text-muted-foreground">
                                Configure branding, deployment, knowledge, tools, and assistant behavior for the widget your customers will interact with.
                            </p>
                        </div>
                    </div>
                    <div className="flex gap-3">
                        <StatCard label="Sessions" value={widget.analytics.sessions} icon={<Globe2 className="h-4 w-4" />} />
                        <StatCard label="Messages" value={widget.analytics.messages} icon={<Bot className="h-4 w-4" />} />
                        <StatCard label="Knowledge" value={widget.knowledge.length} icon={<Layers3 className="h-4 w-4" />} />
                    </div>
                </div>
            </section>

            <Tabs defaultValue="general" className="space-y-6">
                <TabsList className="grid h-auto w-full grid-cols-2 gap-2 rounded-2xl border border-border/60 bg-card p-2 md:grid-cols-5">
                    <TabsTrigger value="general" className="rounded-xl">General</TabsTrigger>
                    <TabsTrigger value="embed" className="rounded-xl">Embed</TabsTrigger>
                    <TabsTrigger value="knowledge" className="rounded-xl">Knowledge</TabsTrigger>
                    <TabsTrigger value="tools" className="rounded-xl">Tools</TabsTrigger>
                    <TabsTrigger value="analytics" className="rounded-xl">Analytics</TabsTrigger>
                </TabsList>

                <TabsContent value="general">
                    <div className="grid gap-6 xl:grid-cols-[1.15fr_0.85fr]">
                    <Card className="border-border/60">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Settings2 className="h-4 w-4 text-primary" />
                                General settings
                            </CardTitle>
                            <CardDescription>Define how the widget looks, speaks, and where it can run.</CardDescription>
                        </CardHeader>
                        <CardContent className="grid gap-5 md:grid-cols-2">
                            <Field label="Widget name">
                                <Input value={widget.name} onChange={(event) => setWidget({ ...widget, name: event.target.value })} />
                            </Field>
                            <Field label="Bot name">
                                <Input value={widget.bot_name} onChange={(event) => setWidget({ ...widget, bot_name: event.target.value })} />
                            </Field>
                            <Field label="Greeting" className="md:col-span-2">
                                <Input value={widget.greeting} onChange={(event) => setWidget({ ...widget, greeting: event.target.value })} />
                            </Field>
                            <Field label="Theme color">
                                <div className="flex items-center gap-3">
                                    <input
                                        type="color"
                                        value={widget.theme_color}
                                        onChange={(event) => setWidget({ ...widget, theme_color: event.target.value })}
                                        className="h-10 w-10 cursor-pointer rounded-lg border border-input p-0.5"
                                    />
                                    <Input
                                        value={widget.theme_color}
                                        onChange={(event) => setWidget({ ...widget, theme_color: event.target.value })}
                                        className="font-mono"
                                        placeholder="#7c3aed"
                                        maxLength={7}
                                    />
                                </div>
                            </Field>
                            <Field label="Avatar URL">
                                <Input value={widget.avatar_url ?? ''} onChange={(event) => setWidget({ ...widget, avatar_url: event.target.value })} />
                            </Field>
                            <Field label="System prompt" className="md:col-span-2">
                                <Textarea rows={7} value={widget.system_prompt ?? ''} onChange={(event) => setWidget({ ...widget, system_prompt: event.target.value })} />
                            </Field>
                            <Field label="Allowed domains" hint="One domain per line. Leave blank to allow all domains." className="md:col-span-2">
                                <Textarea
                                    rows={5}
                                    value={(widget.allowed_domains ?? []).join('\n')}
                                    onChange={(event) =>
                                        setWidget({
                                            ...widget,
                                            allowed_domains: event.target.value.split('\n').map((value) => value.trim()).filter(Boolean),
                                        })
                                    }
                                />
                            </Field>
                            <div className="rounded-2xl border border-border/60 p-4">
                                <div className="flex items-start justify-between gap-4">
                                <div>
                                    <Label className="font-medium">Widget status</Label>
                                    <p className="text-sm text-muted-foreground">Turn the widget on or pause new sessions instantly.</p>
                                </div>
                                <Switch checked={widget.is_active} onCheckedChange={(value) => setWidget({ ...widget, is_active: value })} />
                                </div>
                            </div>
                            <div className="rounded-2xl border border-border/60 p-4">
                                <div className="flex items-start justify-between gap-4">
                                <div>
                                    <Label className="font-medium">Visitor file uploads</Label>
                                    <p className="text-sm text-muted-foreground">Allow customers to send files in the widget if their plan supports it.</p>
                                </div>
                                <Switch checked={widget.allow_file_uploads} onCheckedChange={(value) => setWidget({ ...widget, allow_file_uploads: value })} />
                                </div>
                            </div>
                            <div className="md:col-span-2 flex justify-end">
                                <Button type="button" onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending}>
                                    {saveMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                                    Save widget settings
                                </Button>
                            </div>
                        </CardContent>
                    </Card>
                    <Card className="border-border/60">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Sparkles className="h-4 w-4 text-primary" />
                                Deployment summary
                            </CardTitle>
                            <CardDescription>Quick reference for what is currently live on this widget.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <SummaryRow label="Public status" value={widget.is_active ? 'Live and accepting new sessions' : 'Paused'} />
                            <SummaryRow label="Bot identity" value={widget.bot_name} />
                            <SummaryRow label="Theme" value={widget.theme_color} />
                            <SummaryRow label="Allowed domains" value={widget.allowed_domains.length ? `${widget.allowed_domains.length} restricted domain(s)` : 'Open to all domains'} />
                            <SummaryRow label="File uploads" value={widget.allow_file_uploads ? 'Enabled' : 'Disabled'} />
                            <SummaryRow label="Tools" value={`${widget.tools.length} configured`} />
                            <SummaryRow label="Knowledge" value={`${widget.knowledge.length} added`} />
                            <div className="rounded-2xl border border-border/60 bg-muted/30 p-4">
                                <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Token</p>
                                <div className="mt-2 flex items-center gap-2">
                                    <code className="min-w-0 flex-1 truncate rounded-lg bg-background px-3 py-2 font-mono text-xs text-foreground">{widget.token}</code>
                                    <Button type="button" size="sm" variant="outline" onClick={() => copyText(widget.token)}>
                                        <Copy className="mr-2 h-3.5 w-3.5" />
                                        Copy
                                    </Button>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                    </div>
                </TabsContent>

                <TabsContent value="embed">
                    <div className="grid gap-6 xl:grid-cols-[0.92fr_1.08fr]">
                        <Card className="border-border/60">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <Code2 className="h-4 w-4 text-primary" />
                                    Embed code
                                </CardTitle>
                                <CardDescription>Paste this exact snippet before the closing `&lt;/body&gt;` tag on the target site.</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="rounded-2xl border border-border/60 bg-muted/30 p-4">
                                    <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Embed loader</p>
                                    <p className="mt-2 break-all font-mono text-xs text-foreground">{widget.embed_script_url}</p>
                                </div>
                                <div className="overflow-hidden rounded-2xl border border-border/60">
                                    <div className="border-b border-border/60 bg-muted/30 px-4 py-2 text-xs font-medium text-muted-foreground">
                                        Ready-to-paste snippet
                                    </div>
                                    <pre className="overflow-x-auto bg-background p-4 text-xs leading-6 text-foreground">
                                        <code>{widget.embed_code}</code>
                                    </pre>
                                </div>
                                <Button type="button" variant="outline" onClick={() => copyText(widget.embed_code)}>
                                    <Copy className="mr-2 h-4 w-4" />
                                    Copy embed code
                                </Button>
                            </CardContent>
                        </Card>

                        <Card className="border-border/60">
                            <CardHeader>
                                <CardTitle>Live preview</CardTitle>
                                <CardDescription>Preview the widget exactly as it will load through the app-hosted embed loader.</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <iframe src={widget.preview_url} title="Widget preview" className="h-[560px] w-full rounded-2xl border border-border/60 bg-white" />
                            </CardContent>
                        </Card>
                    </div>
                </TabsContent>

                <TabsContent value="knowledge">
                    <div className="grid gap-6 xl:grid-cols-[0.8fr_1.2fr]">
                        <Card className="border-border/60">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <Bot className="h-4 w-4 text-primary" />
                                    Add knowledge
                                </CardTitle>
                                <CardDescription>Connect a WordPress site for guided crawling, then add manual text, URLs, and PDFs when needed.</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-5">
                                <Field label="Connect website">
                                    <div className="grid gap-3">
                                        <Select
                                            value={websiteSourceForm.source_type}
                                            onValueChange={(value) =>
                                                setWebsiteSourceForm({
                                                    ...websiteSourceForm,
                                                    source_type: value as 'wordpress_url' | 'wordpress_plugin',
                                                })
                                            }
                                        >
                                            <SelectTrigger>
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="wordpress_url">Paste WordPress URL</SelectItem>
                                                <SelectItem value="wordpress_plugin">Connect with WordPress plugin</SelectItem>
                                            </SelectContent>
                                        </Select>
                                        <Input
                                            value={websiteSourceForm.site_url}
                                            onChange={(event) => setWebsiteSourceForm({ ...websiteSourceForm, site_url: event.target.value })}
                                            placeholder="https://example.com"
                                        />
                                        <Input
                                            value={websiteSourceForm.site_name}
                                            onChange={(event) => setWebsiteSourceForm({ ...websiteSourceForm, site_name: event.target.value })}
                                            placeholder="Optional site name"
                                        />
                                        {websiteSourceForm.source_type === 'wordpress_url' ? (
                                            <>
                                                <Select
                                                    value={websiteSourceForm.verification_method}
                                                    onValueChange={(value) =>
                                                        setWebsiteSourceForm({ ...websiteSourceForm, verification_method: value as 'meta_tag' | 'file' })
                                                    }
                                                >
                                                    <SelectTrigger>
                                                        <SelectValue />
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="meta_tag">Verify with meta tag</SelectItem>
                                                        <SelectItem value="file">Verify with file</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                                <Select
                                                    value={websiteSourceForm.scope_mode}
                                                    onValueChange={(value) =>
                                                        setWebsiteSourceForm({ ...websiteSourceForm, scope_mode: value as 'safe_public' | 'custom' })
                                                    }
                                                >
                                                    <SelectTrigger>
                                                        <SelectValue />
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="safe_public">Safe public pages</SelectItem>
                                                        <SelectItem value="custom">Custom scope</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                                <Input
                                                    value={websiteSourceForm.recrawl_interval_hours}
                                                    onChange={(event) => setWebsiteSourceForm({ ...websiteSourceForm, recrawl_interval_hours: event.target.value })}
                                                    placeholder="Recrawl interval in hours"
                                                    type="number"
                                                    min={1}
                                                    max={168}
                                                />
                                                <Textarea
                                                    rows={3}
                                                    value={websiteSourceForm.include_paths}
                                                    onChange={(event) => setWebsiteSourceForm({ ...websiteSourceForm, include_paths: event.target.value })}
                                                    placeholder="/blog&#10;/products"
                                                />
                                                <Textarea
                                                    rows={3}
                                                    value={websiteSourceForm.exclude_paths}
                                                    onChange={(event) => setWebsiteSourceForm({ ...websiteSourceForm, exclude_paths: event.target.value })}
                                                    placeholder="/cart&#10;/checkout"
                                                />
                                                <Textarea
                                                    rows={3}
                                                    value={websiteSourceForm.seed_urls}
                                                    onChange={(event) => setWebsiteSourceForm({ ...websiteSourceForm, seed_urls: event.target.value })}
                                                    placeholder="https://example.com/faq"
                                                />
                                            </>
                                        ) : null}
                                        <Button
                                            type="button"
                                            onClick={() => addWebsiteSourceMutation.mutate()}
                                            disabled={addWebsiteSourceMutation.isPending || !websiteSourceForm.site_url.trim()}
                                        >
                                            {addWebsiteSourceMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ShieldCheck className="mr-2 h-4 w-4" />}
                                            Connect website
                                        </Button>
                                    </div>
                                </Field>

                                <Field label="Text note">
                                    <Input value={textKnowledge.name} onChange={(event) => setTextKnowledge({ ...textKnowledge, name: event.target.value })} placeholder="Shipping policy" />
                                    <Textarea className="mt-2" rows={5} value={textKnowledge.content} onChange={(event) => setTextKnowledge({ ...textKnowledge, content: event.target.value })} />
                                    <Button type="button" className="mt-3" onClick={() => addTextMutation.mutate()} disabled={addTextMutation.isPending || !textKnowledge.content.trim()}>
                                        Save text knowledge
                                    </Button>
                                </Field>

                                <Field label="Website URL">
                                    <Input value={urlKnowledge.url} onChange={(event) => setUrlKnowledge({ ...urlKnowledge, url: event.target.value })} placeholder="https://example.com/faq" />
                                    <Input className="mt-2" value={urlKnowledge.name} onChange={(event) => setUrlKnowledge({ ...urlKnowledge, name: event.target.value })} placeholder="Optional title" />
                                    <Button type="button" className="mt-3" variant="outline" onClick={() => addUrlMutation.mutate()} disabled={addUrlMutation.isPending || !urlKnowledge.url.trim()}>
                                        <Globe2 className="mr-2 h-4 w-4" />
                                        Fetch URL
                                    </Button>
                                </Field>

                                <Field label="PDF file">
                                    <Input
                                        type="file"
                                        accept="application/pdf"
                                        onChange={(event) => {
                                            const file = event.target.files?.[0];
                                            if (file) {
                                                uploadPdfMutation.mutate(file);
                                            }
                                        }}
                                    />
                                </Field>
                            </CardContent>
                        </Card>

                        <Card className="border-border/60">
                            <CardHeader>
                                <CardTitle>Website sources and knowledge</CardTitle>
                                <CardDescription>Website sources are grouped separately from manual knowledge so you can verify, crawl, and monitor sync state.</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <ScrollArea className="h-[640px] pr-4">
                                    <div className="space-y-6">
                                        <div className="space-y-3">
                                            <div className="flex items-center justify-between gap-3">
                                                <h3 className="text-sm font-semibold text-foreground">Connected websites</h3>
                                                <Badge variant="outline">{widget.website_sources.length}</Badge>
                                            </div>
                                            {widget.website_sources.length ? widget.website_sources.map((source) => (
                                                <div key={source.id} className="rounded-2xl border border-border/60 p-4">
                                                    <div className="flex flex-wrap items-start justify-between gap-3">
                                                        <div className="space-y-2">
                                                            <div className="flex flex-wrap items-center gap-2">
                                                                <p className="font-medium text-foreground">{source.site_name || source.site_host}</p>
                                                                <Badge variant="outline">{source.source_type === 'wordpress_plugin' ? 'Plugin' : 'URL crawl'}</Badge>
                                                                <Badge variant={source.verification_status === 'verified' ? 'default' : source.verification_status === 'failed' ? 'destructive' : 'secondary'}>
                                                                    {source.verification_status}
                                                                </Badge>
                                                                <Badge variant={source.crawl_status === 'completed' ? 'default' : source.crawl_status === 'failed' ? 'destructive' : 'secondary'}>
                                                                    {source.crawl_status}
                                                                </Badge>
                                                            </div>
                                                            <p className="text-xs text-muted-foreground">{source.site_url}</p>
                                                            <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
                                                                <span>Ready pages: {source.stats.pages_ready}</span>
                                                                <span>Failed: {source.stats.pages_failed}</span>
                                                                <span>Skipped: {source.stats.pages_skipped}</span>
                                                                {source.last_sync_at ? <span>Last updated: {new Date(source.last_sync_at).toLocaleString()}</span> : null}
                                                            </div>
                                                        </div>
                                                        <div className="flex flex-wrap gap-2">
                                                            {source.source_type === 'wordpress_url' ? (
                                                                <>
                                                                    <Button type="button" size="sm" variant="outline" onClick={() => verifyWebsiteSourceMutation.mutate(source.id)}>
                                                                        Verify ownership
                                                                    </Button>
                                                                    <Button
                                                                        type="button"
                                                                        size="sm"
                                                                        onClick={() => crawlWebsiteSourceMutation.mutate(source.id)}
                                                                        disabled={source.verification_status !== 'verified'}
                                                                    >
                                                                        Sync now
                                                                    </Button>
                                                                    {source.verification_method === 'file' ? (
                                                                        <Button
                                                                            type="button"
                                                                            size="sm"
                                                                            variant="ghost"
                                                                            onClick={() => window.open(`/api/widget/${widget.id}/website-sources/${source.id}/verification-file`, '_blank')}
                                                                        >
                                                                            <Download className="mr-1 h-3.5 w-3.5" />
                                                                            File
                                                                        </Button>
                                                                    ) : null}
                                                                </>
                                                            ) : null}
                                                        </div>
                                                    </div>

                                                    {source.source_type === 'wordpress_url' && source.verification_status !== 'verified' ? (
                                                        <div className="mt-4 rounded-2xl border border-border/60 bg-muted/20 p-3 text-xs text-muted-foreground">
                                                            <p className="font-medium text-foreground">Verification instructions</p>
                                                            {source.verification_method === 'meta_tag' ? (
                                                                <code className="mt-2 block whitespace-pre-wrap rounded-lg bg-background px-3 py-2 text-[11px]">{source.verification_meta_tag}</code>
                                                            ) : (
                                                                <>
                                                                    <p className="mt-2">Upload this file to the root of your WordPress site:</p>
                                                                    <code className="mt-2 block rounded-lg bg-background px-3 py-2 text-[11px]">{source.verification_filename}</code>
                                                                    <code className="mt-2 block rounded-lg bg-background px-3 py-2 text-[11px]">{source.verification_file_content}</code>
                                                                </>
                                                            )}
                                                        </div>
                                                    ) : null}

                                                    {source.source_type === 'wordpress_plugin' ? (
                                                        <div className="mt-4 rounded-2xl border border-border/60 bg-muted/20 p-3 text-xs text-muted-foreground">
                                                            <p className="font-medium text-foreground">Plugin connection</p>
                                                            <p className="mt-2">Sync URL</p>
                                                            <code className="mt-1 block break-all rounded-lg bg-background px-3 py-2 text-[11px]">{source.plugin_sync_url}</code>
                                                            <p className="mt-2">Connection token</p>
                                                            <code className="mt-1 block break-all rounded-lg bg-background px-3 py-2 text-[11px]">{source.connection_token}</code>
                                                            <p className="mt-2">Connection secret</p>
                                                            <code className="mt-1 block break-all rounded-lg bg-background px-3 py-2 text-[11px]">{source.connection_secret}</code>
                                                        </div>
                                                    ) : null}

                                                    {source.pages.length ? (
                                                        <div className="mt-4 space-y-2">
                                                            <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">Crawled pages</p>
                                                            {source.pages.slice(0, 8).map((page) => (
                                                                <div key={page.id} className="rounded-xl border border-border/50 px-3 py-2">
                                                                    <div className="flex items-center gap-2">
                                                                        <p className="truncate text-sm font-medium text-foreground">{page.title || page.path}</p>
                                                                        <Badge variant={page.status === 'ready' ? 'default' : page.status === 'failed' ? 'destructive' : 'secondary'}>
                                                                            {page.status}
                                                                        </Badge>
                                                                    </div>
                                                                    <p className="mt-1 truncate text-xs text-muted-foreground">{page.url}</p>
                                                                    {page.failure_reason ? <p className="mt-1 text-xs text-destructive">{page.failure_reason}</p> : null}
                                                                </div>
                                                            ))}
                                                        </div>
                                                    ) : null}
                                                </div>
                                            )) : (
                                                <div className="rounded-2xl border border-dashed border-border/60 p-6 text-center text-sm text-muted-foreground">
                                                    No website sources connected yet.
                                                </div>
                                            )}
                                        </div>

                                        <div className="space-y-3">
                                            <div className="flex items-center justify-between gap-3">
                                                <h3 className="text-sm font-semibold text-foreground">Manual knowledge</h3>
                                                <Badge variant="outline">{widget.knowledge.length}</Badge>
                                            </div>
                                            {widget.knowledge.length ? widget.knowledge.map((item) => (
                                            <div key={item.id} className="rounded-2xl border border-border/60 p-4">
                                                <div className="flex items-start justify-between gap-3">
                                                    <div>
                                                        <div className="flex flex-wrap items-center gap-2">
                                                            <p className="font-medium text-foreground">{item.name}</p>
                                                            <Badge variant="outline">{item.type}</Badge>
                                                            <Badge variant={item.status === 'ready' ? 'default' : item.status === 'failed' ? 'destructive' : 'secondary'}>
                                                                {item.status}
                                                            </Badge>
                                                        </div>
                                                        {item.source_url ? <p className="mt-1 text-xs text-muted-foreground">{item.source_url}</p> : null}
                                                    </div>
                                                    <Button type="button" size="sm" variant="ghost" onClick={() => deleteKnowledgeMutation.mutate(item.id)}>
                                                        Remove
                                                    </Button>
                                                </div>
                                                <p className="mt-3 line-clamp-4 whitespace-pre-wrap text-sm text-muted-foreground">{item.content || 'No extracted content available.'}</p>
                                            </div>
                                        )) : (
                                            <div className="rounded-2xl border border-dashed border-border/60 p-8 text-center text-sm text-muted-foreground">
                                                No knowledge items yet.
                                            </div>
                                        )}
                                        </div>
                                    </div>
                                </ScrollArea>
                            </CardContent>
                        </Card>
                    </div>
                </TabsContent>

                <TabsContent value="tools">
                    <div className="grid gap-6 xl:grid-cols-[0.8fr_1.2fr]">
                        <Card className="border-border/60">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <Wrench className="h-4 w-4 text-primary" />
                                    Add tool or MCP server
                                </CardTitle>
                                <CardDescription>Connect external APIs or remote MCP servers the widget can call during conversations.</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <Field label="Type">
                                    <Select
                                        value={toolForm.tool_type}
                                        onValueChange={(value) => setToolForm({ ...toolForm, tool_type: value as 'http' | 'mcp_server' })}
                                    >
                                        <SelectTrigger>
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="http">HTTP tool</SelectItem>
                                            <SelectItem value="mcp_server">Remote MCP server</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </Field>
                                <Field label="Name">
                                    <Input value={toolForm.name} onChange={(event) => setToolForm({ ...toolForm, name: event.target.value })} />
                                </Field>
                                <Field label="Description">
                                    <Textarea rows={4} value={toolForm.description} onChange={(event) => setToolForm({ ...toolForm, description: event.target.value })} />
                                </Field>
                                <Field label="Endpoint URL">
                                    <Input value={toolForm.endpoint_url} onChange={(event) => setToolForm({ ...toolForm, endpoint_url: event.target.value })} placeholder="https://api.example.com/tool" />
                                </Field>
                                <Field label="Method / transport">
                                    <div className="grid gap-3 md:grid-cols-2">
                                        <Select
                                            value={toolForm.method}
                                            onValueChange={(value) => setToolForm({ ...toolForm, method: value })}
                                        >
                                            <SelectTrigger>
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="GET">GET</SelectItem>
                                                <SelectItem value="POST">POST</SelectItem>
                                                <SelectItem value="PUT">PUT</SelectItem>
                                                <SelectItem value="PATCH">PATCH</SelectItem>
                                                <SelectItem value="DELETE">DELETE</SelectItem>
                                            </SelectContent>
                                        </Select>
                                        <Select
                                            value={toolForm.transport}
                                            onValueChange={(value) => setToolForm({ ...toolForm, transport: value })}
                                        >
                                            <SelectTrigger>
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="http">HTTP</SelectItem>
                                                <SelectItem value="sse">SSE</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                </Field>
                                <Field label="Headers JSON">
                                    <Textarea rows={3} value={toolForm.headers} onChange={(event) => setToolForm({ ...toolForm, headers: event.target.value })} />
                                </Field>
                                <Field label="Parameters JSON Schema">
                                    <Textarea rows={5} value={toolForm.parameters} onChange={(event) => setToolForm({ ...toolForm, parameters: event.target.value })} />
                                </Field>
                                <Field label="Extra configuration JSON">
                                    <Textarea rows={4} value={toolForm.configuration} onChange={(event) => setToolForm({ ...toolForm, configuration: event.target.value })} />
                                </Field>
                                <Button type="button" onClick={() => addToolMutation.mutate()} disabled={addToolMutation.isPending || !toolForm.name.trim() || !toolForm.endpoint_url.trim()}>
                                    {addToolMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                    Save tool
                                </Button>
                            </CardContent>
                        </Card>
                        <Card className="border-border/60">
                            <CardHeader>
                                <CardTitle>Configured tools</CardTitle>
                                <CardDescription>These tools are available to the widget whenever the AI decides they are needed.</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <ScrollArea className="h-[680px] pr-4">
                                    <div className="space-y-3">
                                        {widget.tools.length ? widget.tools.map((tool) => (
                                            <div key={tool.id} className="rounded-2xl border border-border/60 p-4">
                                                <div className="flex items-start justify-between gap-3">
                                                    <div>
                                                        <div className="flex flex-wrap items-center gap-2">
                                                            <p className="font-medium text-foreground">{tool.name}</p>
                                                            <Badge variant="outline">{tool.tool_type === 'mcp_server' ? 'MCP' : tool.method}</Badge>
                                                            <Badge variant={tool.is_active ? 'default' : 'secondary'}>
                                                                {tool.is_active ? 'Active' : 'Paused'}
                                                            </Badge>
                                                        </div>
                                                        <p className="mt-1 text-sm text-muted-foreground">{tool.description}</p>
                                                        <p className="mt-2 text-xs text-muted-foreground">{tool.endpoint_url}</p>
                                                    </div>
                                                    <Button type="button" size="sm" variant="ghost" onClick={() => deleteToolMutation.mutate(tool.id)}>
                                                        Remove
                                                    </Button>
                                                </div>
                                            </div>
                                        )) : (
                                            <div className="rounded-2xl border border-dashed border-border/60 p-8 text-center text-sm text-muted-foreground">
                                                No tools configured yet.
                                            </div>
                                        )}
                                    </div>
                                </ScrollArea>
                            </CardContent>
                        </Card>
                    </div>
                </TabsContent>

                <TabsContent value="analytics">
                    <Card className="border-border/60">
                        <CardHeader>
                            <CardTitle>Analytics</CardTitle>
                            <CardDescription>High-level activity for this widget and room for deeper reporting later.</CardDescription>
                        </CardHeader>
                        <CardContent className="grid gap-4 md:grid-cols-3">
                            <StatCard label="Sessions" value={widget.analytics.sessions} icon={<Globe2 className="h-4 w-4" />} />
                            <StatCard label="Messages" value={widget.analytics.messages} icon={<Bot className="h-4 w-4" />} />
                            <div className="rounded-2xl border border-dashed border-border/60 p-4 text-sm leading-6 text-muted-foreground">
                                Message trends, conversion rates, and domain-level breakdowns can expand here in the next pass.
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>
        </div>
    );
}

function Field({ label, hint, className, children }: { label: string; hint?: string; className?: string; children: React.ReactNode }) {
    return (
        <div className={className}>
            <Label className="mb-2 block">{label}</Label>
            {children}
            {hint ? <p className="mt-2 text-xs leading-5 text-muted-foreground">{hint}</p> : null}
        </div>
    );
}

function StatCard({ label, value, icon }: { label: string; value: number; icon: React.ReactNode }) {
    return (
        <div className="rounded-2xl border border-border/60 bg-background/75 p-4">
            <div className="flex items-center justify-between gap-3">
                <div className="text-sm text-muted-foreground">{label}</div>
                <div className="text-muted-foreground">{icon}</div>
            </div>
            <div className="mt-3 text-2xl font-semibold text-foreground">{value}</div>
        </div>
    );
}

function SummaryRow({ label, value }: { label: string; value: string }) {
    return (
        <div className="rounded-2xl border border-border/60 bg-background/75 px-4 py-3">
            <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">{label}</p>
            <p className="mt-2 text-sm font-medium text-foreground">{value}</p>
        </div>
    );
}

function parseJson(value: string) {
    try {
        return JSON.parse(value);
    } catch {
        return {};
    }
}

function splitLines(value: string) {
    return value
        .split('\n')
        .map((line) => line.trim())
        .filter(Boolean);
}

async function copyText(value: string) {
    await navigator.clipboard.writeText(value);
    toast.success('Copied to clipboard');
}

function xsrfHeader(): Record<string, string> {
    const match = document.cookie.match(/(?:^|;\s*)XSRF-TOKEN=([^;]+)/);
    return match ? { 'X-XSRF-TOKEN': decodeURIComponent(match[1]) } : {};
}
