import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DeveloperApiDocsController::index
* @see app/Http/Controllers/DeveloperApiDocsController.php:11
* @route '/docs/api'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/docs/api',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeveloperApiDocsController::index
* @see app/Http/Controllers/DeveloperApiDocsController.php:11
* @route '/docs/api'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeveloperApiDocsController::index
* @see app/Http/Controllers/DeveloperApiDocsController.php:11
* @route '/docs/api'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeveloperApiDocsController::index
* @see app/Http/Controllers/DeveloperApiDocsController.php:11
* @route '/docs/api'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\DeveloperApiDocsController::agents
* @see app/Http/Controllers/DeveloperApiDocsController.php:33
* @route '/docs/agents'
*/
export const agents = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: agents.url(options),
    method: 'get',
})

agents.definition = {
    methods: ["get","head"],
    url: '/docs/agents',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeveloperApiDocsController::agents
* @see app/Http/Controllers/DeveloperApiDocsController.php:33
* @route '/docs/agents'
*/
agents.url = (options?: RouteQueryOptions) => {
    return agents.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeveloperApiDocsController::agents
* @see app/Http/Controllers/DeveloperApiDocsController.php:33
* @route '/docs/agents'
*/
agents.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: agents.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeveloperApiDocsController::agents
* @see app/Http/Controllers/DeveloperApiDocsController.php:33
* @route '/docs/agents'
*/
agents.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: agents.url(options),
    method: 'head',
})

const DeveloperApiDocsController = { index, agents }

export default DeveloperApiDocsController