import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Meta\MetaBroadcastController::index
* @see app/Http/Controllers/Meta/MetaBroadcastController.php:18
* @route '/api/meta/accounts/{account}/broadcasts'
*/
export const index = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/meta/accounts/{account}/broadcasts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Meta\MetaBroadcastController::index
* @see app/Http/Controllers/Meta/MetaBroadcastController.php:18
* @route '/api/meta/accounts/{account}/broadcasts'
*/
index.url = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { account: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { account: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            account: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        account: typeof args.account === 'object'
        ? args.account.id
        : args.account,
    }

    return index.definition.url
            .replace('{account}', parsedArgs.account.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Meta\MetaBroadcastController::index
* @see app/Http/Controllers/Meta/MetaBroadcastController.php:18
* @route '/api/meta/accounts/{account}/broadcasts'
*/
index.get = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Meta\MetaBroadcastController::index
* @see app/Http/Controllers/Meta/MetaBroadcastController.php:18
* @route '/api/meta/accounts/{account}/broadcasts'
*/
index.head = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Meta\MetaBroadcastController::store
* @see app/Http/Controllers/Meta/MetaBroadcastController.php:30
* @route '/api/meta/accounts/{account}/broadcasts'
*/
export const store = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/meta/accounts/{account}/broadcasts',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Meta\MetaBroadcastController::store
* @see app/Http/Controllers/Meta/MetaBroadcastController.php:30
* @route '/api/meta/accounts/{account}/broadcasts'
*/
store.url = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { account: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { account: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            account: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        account: typeof args.account === 'object'
        ? args.account.id
        : args.account,
    }

    return store.definition.url
            .replace('{account}', parsedArgs.account.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Meta\MetaBroadcastController::store
* @see app/Http/Controllers/Meta/MetaBroadcastController.php:30
* @route '/api/meta/accounts/{account}/broadcasts'
*/
store.post = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Meta\MetaBroadcastController::show
* @see app/Http/Controllers/Meta/MetaBroadcastController.php:65
* @route '/api/meta/accounts/{account}/broadcasts/{broadcast}'
*/
export const show = (args: { account: string | { id: string }, broadcast: string | { id: string } } | [account: string | { id: string }, broadcast: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/meta/accounts/{account}/broadcasts/{broadcast}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Meta\MetaBroadcastController::show
* @see app/Http/Controllers/Meta/MetaBroadcastController.php:65
* @route '/api/meta/accounts/{account}/broadcasts/{broadcast}'
*/
show.url = (args: { account: string | { id: string }, broadcast: string | { id: string } } | [account: string | { id: string }, broadcast: string | { id: string } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            account: args[0],
            broadcast: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        account: typeof args.account === 'object'
        ? args.account.id
        : args.account,
        broadcast: typeof args.broadcast === 'object'
        ? args.broadcast.id
        : args.broadcast,
    }

    return show.definition.url
            .replace('{account}', parsedArgs.account.toString())
            .replace('{broadcast}', parsedArgs.broadcast.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Meta\MetaBroadcastController::show
* @see app/Http/Controllers/Meta/MetaBroadcastController.php:65
* @route '/api/meta/accounts/{account}/broadcasts/{broadcast}'
*/
show.get = (args: { account: string | { id: string }, broadcast: string | { id: string } } | [account: string | { id: string }, broadcast: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Meta\MetaBroadcastController::show
* @see app/Http/Controllers/Meta/MetaBroadcastController.php:65
* @route '/api/meta/accounts/{account}/broadcasts/{broadcast}'
*/
show.head = (args: { account: string | { id: string }, broadcast: string | { id: string } } | [account: string | { id: string }, broadcast: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Meta\MetaBroadcastController::send
* @see app/Http/Controllers/Meta/MetaBroadcastController.php:85
* @route '/api/meta/accounts/{account}/broadcasts/{broadcast}/send'
*/
export const send = (args: { account: string | { id: string }, broadcast: string | { id: string } } | [account: string | { id: string }, broadcast: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(args, options),
    method: 'post',
})

send.definition = {
    methods: ["post"],
    url: '/api/meta/accounts/{account}/broadcasts/{broadcast}/send',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Meta\MetaBroadcastController::send
* @see app/Http/Controllers/Meta/MetaBroadcastController.php:85
* @route '/api/meta/accounts/{account}/broadcasts/{broadcast}/send'
*/
send.url = (args: { account: string | { id: string }, broadcast: string | { id: string } } | [account: string | { id: string }, broadcast: string | { id: string } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            account: args[0],
            broadcast: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        account: typeof args.account === 'object'
        ? args.account.id
        : args.account,
        broadcast: typeof args.broadcast === 'object'
        ? args.broadcast.id
        : args.broadcast,
    }

    return send.definition.url
            .replace('{account}', parsedArgs.account.toString())
            .replace('{broadcast}', parsedArgs.broadcast.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Meta\MetaBroadcastController::send
* @see app/Http/Controllers/Meta/MetaBroadcastController.php:85
* @route '/api/meta/accounts/{account}/broadcasts/{broadcast}/send'
*/
send.post = (args: { account: string | { id: string }, broadcast: string | { id: string } } | [account: string | { id: string }, broadcast: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(args, options),
    method: 'post',
})

const MetaBroadcastController = { index, store, show, send }

export default MetaBroadcastController