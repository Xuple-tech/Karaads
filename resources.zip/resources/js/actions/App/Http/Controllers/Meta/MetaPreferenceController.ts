import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Meta\MetaPreferenceController::show
* @see app/Http/Controllers/Meta/MetaPreferenceController.php:22
* @route '/api/meta/accounts/{account}/preferences'
*/
export const show = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/meta/accounts/{account}/preferences',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Meta\MetaPreferenceController::show
* @see app/Http/Controllers/Meta/MetaPreferenceController.php:22
* @route '/api/meta/accounts/{account}/preferences'
*/
show.url = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { account: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { account: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            account: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        account: typeof args.account === 'object'
        ? args.account.id
        : args.account,
    }

    return show.definition.url
            .replace('{account}', parsedArgs.account.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Meta\MetaPreferenceController::show
* @see app/Http/Controllers/Meta/MetaPreferenceController.php:22
* @route '/api/meta/accounts/{account}/preferences'
*/
show.get = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Meta\MetaPreferenceController::show
* @see app/Http/Controllers/Meta/MetaPreferenceController.php:22
* @route '/api/meta/accounts/{account}/preferences'
*/
show.head = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Meta\MetaPreferenceController::update
* @see app/Http/Controllers/Meta/MetaPreferenceController.php:79
* @route '/api/meta/accounts/{account}/preferences'
*/
export const update = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/meta/accounts/{account}/preferences',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Meta\MetaPreferenceController::update
* @see app/Http/Controllers/Meta/MetaPreferenceController.php:79
* @route '/api/meta/accounts/{account}/preferences'
*/
update.url = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { account: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { account: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            account: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        account: typeof args.account === 'object'
        ? args.account.id
        : args.account,
    }

    return update.definition.url
            .replace('{account}', parsedArgs.account.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Meta\MetaPreferenceController::update
* @see app/Http/Controllers/Meta/MetaPreferenceController.php:79
* @route '/api/meta/accounts/{account}/preferences'
*/
update.put = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

const MetaPreferenceController = { show, update }

export default MetaPreferenceController