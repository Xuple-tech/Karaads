import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Meta\MetaMessageController::conversations
* @see app/Http/Controllers/Meta/MetaMessageController.php:31
* @route '/api/meta/accounts/{account}/conversations'
*/
export const conversations = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: conversations.url(args, options),
    method: 'get',
})

conversations.definition = {
    methods: ["get","head"],
    url: '/api/meta/accounts/{account}/conversations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Meta\MetaMessageController::conversations
* @see app/Http/Controllers/Meta/MetaMessageController.php:31
* @route '/api/meta/accounts/{account}/conversations'
*/
conversations.url = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { account: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { account: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            account: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        account: typeof args.account === 'object'
        ? args.account.id
        : args.account,
    }

    return conversations.definition.url
            .replace('{account}', parsedArgs.account.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Meta\MetaMessageController::conversations
* @see app/Http/Controllers/Meta/MetaMessageController.php:31
* @route '/api/meta/accounts/{account}/conversations'
*/
conversations.get = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: conversations.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Meta\MetaMessageController::conversations
* @see app/Http/Controllers/Meta/MetaMessageController.php:31
* @route '/api/meta/accounts/{account}/conversations'
*/
conversations.head = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: conversations.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Meta\MetaMessageController::conversation
* @see app/Http/Controllers/Meta/MetaMessageController.php:80
* @route '/api/meta/accounts/{account}/conversations/{conversation}'
*/
export const conversation = (args: { account: string | { id: string }, conversation: string | { id: string } } | [account: string | { id: string }, conversation: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: conversation.url(args, options),
    method: 'get',
})

conversation.definition = {
    methods: ["get","head"],
    url: '/api/meta/accounts/{account}/conversations/{conversation}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Meta\MetaMessageController::conversation
* @see app/Http/Controllers/Meta/MetaMessageController.php:80
* @route '/api/meta/accounts/{account}/conversations/{conversation}'
*/
conversation.url = (args: { account: string | { id: string }, conversation: string | { id: string } } | [account: string | { id: string }, conversation: string | { id: string } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            account: args[0],
            conversation: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        account: typeof args.account === 'object'
        ? args.account.id
        : args.account,
        conversation: typeof args.conversation === 'object'
        ? args.conversation.id
        : args.conversation,
    }

    return conversation.definition.url
            .replace('{account}', parsedArgs.account.toString())
            .replace('{conversation}', parsedArgs.conversation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Meta\MetaMessageController::conversation
* @see app/Http/Controllers/Meta/MetaMessageController.php:80
* @route '/api/meta/accounts/{account}/conversations/{conversation}'
*/
conversation.get = (args: { account: string | { id: string }, conversation: string | { id: string } } | [account: string | { id: string }, conversation: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: conversation.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Meta\MetaMessageController::conversation
* @see app/Http/Controllers/Meta/MetaMessageController.php:80
* @route '/api/meta/accounts/{account}/conversations/{conversation}'
*/
conversation.head = (args: { account: string | { id: string }, conversation: string | { id: string } } | [account: string | { id: string }, conversation: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: conversation.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Meta\MetaMessageController::analyzeAndDraft
* @see app/Http/Controllers/Meta/MetaMessageController.php:151
* @route '/api/meta/messages/{message}/analyze'
*/
export const analyzeAndDraft = (args: { message: string | { id: string } } | [message: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: analyzeAndDraft.url(args, options),
    method: 'post',
})

analyzeAndDraft.definition = {
    methods: ["post"],
    url: '/api/meta/messages/{message}/analyze',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Meta\MetaMessageController::analyzeAndDraft
* @see app/Http/Controllers/Meta/MetaMessageController.php:151
* @route '/api/meta/messages/{message}/analyze'
*/
analyzeAndDraft.url = (args: { message: string | { id: string } } | [message: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { message: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { message: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            message: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        message: typeof args.message === 'object'
        ? args.message.id
        : args.message,
    }

    return analyzeAndDraft.definition.url
            .replace('{message}', parsedArgs.message.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Meta\MetaMessageController::analyzeAndDraft
* @see app/Http/Controllers/Meta/MetaMessageController.php:151
* @route '/api/meta/messages/{message}/analyze'
*/
analyzeAndDraft.post = (args: { message: string | { id: string } } | [message: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: analyzeAndDraft.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Meta\MetaMessageController::updateDraft
* @see app/Http/Controllers/Meta/MetaMessageController.php:222
* @route '/api/meta/drafts/{draft}'
*/
export const updateDraft = (args: { draft: string | { id: string } } | [draft: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateDraft.url(args, options),
    method: 'put',
})

updateDraft.definition = {
    methods: ["put"],
    url: '/api/meta/drafts/{draft}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Meta\MetaMessageController::updateDraft
* @see app/Http/Controllers/Meta/MetaMessageController.php:222
* @route '/api/meta/drafts/{draft}'
*/
updateDraft.url = (args: { draft: string | { id: string } } | [draft: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { draft: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { draft: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            draft: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        draft: typeof args.draft === 'object'
        ? args.draft.id
        : args.draft,
    }

    return updateDraft.definition.url
            .replace('{draft}', parsedArgs.draft.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Meta\MetaMessageController::updateDraft
* @see app/Http/Controllers/Meta/MetaMessageController.php:222
* @route '/api/meta/drafts/{draft}'
*/
updateDraft.put = (args: { draft: string | { id: string } } | [draft: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateDraft.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Meta\MetaMessageController::sendDraft
* @see app/Http/Controllers/Meta/MetaMessageController.php:250
* @route '/api/meta/drafts/{draft}/send'
*/
export const sendDraft = (args: { draft: string | { id: string } } | [draft: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendDraft.url(args, options),
    method: 'post',
})

sendDraft.definition = {
    methods: ["post"],
    url: '/api/meta/drafts/{draft}/send',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Meta\MetaMessageController::sendDraft
* @see app/Http/Controllers/Meta/MetaMessageController.php:250
* @route '/api/meta/drafts/{draft}/send'
*/
sendDraft.url = (args: { draft: string | { id: string } } | [draft: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { draft: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { draft: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            draft: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        draft: typeof args.draft === 'object'
        ? args.draft.id
        : args.draft,
    }

    return sendDraft.definition.url
            .replace('{draft}', parsedArgs.draft.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Meta\MetaMessageController::sendDraft
* @see app/Http/Controllers/Meta/MetaMessageController.php:250
* @route '/api/meta/drafts/{draft}/send'
*/
sendDraft.post = (args: { draft: string | { id: string } } | [draft: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendDraft.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Meta\MetaMessageController::rejectDraft
* @see app/Http/Controllers/Meta/MetaMessageController.php:269
* @route '/api/meta/drafts/{draft}/reject'
*/
export const rejectDraft = (args: { draft: string | { id: string } } | [draft: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rejectDraft.url(args, options),
    method: 'post',
})

rejectDraft.definition = {
    methods: ["post"],
    url: '/api/meta/drafts/{draft}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Meta\MetaMessageController::rejectDraft
* @see app/Http/Controllers/Meta/MetaMessageController.php:269
* @route '/api/meta/drafts/{draft}/reject'
*/
rejectDraft.url = (args: { draft: string | { id: string } } | [draft: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { draft: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { draft: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            draft: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        draft: typeof args.draft === 'object'
        ? args.draft.id
        : args.draft,
    }

    return rejectDraft.definition.url
            .replace('{draft}', parsedArgs.draft.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Meta\MetaMessageController::rejectDraft
* @see app/Http/Controllers/Meta/MetaMessageController.php:269
* @route '/api/meta/drafts/{draft}/reject'
*/
rejectDraft.post = (args: { draft: string | { id: string } } | [draft: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rejectDraft.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Meta\MetaMessageController::send
* @see app/Http/Controllers/Meta/MetaMessageController.php:292
* @route '/api/meta/conversations/{conversation}/send'
*/
export const send = (args: { conversation: string | { id: string } } | [conversation: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(args, options),
    method: 'post',
})

send.definition = {
    methods: ["post"],
    url: '/api/meta/conversations/{conversation}/send',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Meta\MetaMessageController::send
* @see app/Http/Controllers/Meta/MetaMessageController.php:292
* @route '/api/meta/conversations/{conversation}/send'
*/
send.url = (args: { conversation: string | { id: string } } | [conversation: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { conversation: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { conversation: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            conversation: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        conversation: typeof args.conversation === 'object'
        ? args.conversation.id
        : args.conversation,
    }

    return send.definition.url
            .replace('{conversation}', parsedArgs.conversation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Meta\MetaMessageController::send
* @see app/Http/Controllers/Meta/MetaMessageController.php:292
* @route '/api/meta/conversations/{conversation}/send'
*/
send.post = (args: { conversation: string | { id: string } } | [conversation: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Meta\MetaMessageController::updateCrm
* @see app/Http/Controllers/Meta/MetaMessageController.php:406
* @route '/api/meta/accounts/{account}/conversations/{conversation}/crm'
*/
export const updateCrm = (args: { account: string | { id: string }, conversation: string | { id: string } } | [account: string | { id: string }, conversation: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateCrm.url(args, options),
    method: 'patch',
})

updateCrm.definition = {
    methods: ["patch"],
    url: '/api/meta/accounts/{account}/conversations/{conversation}/crm',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Meta\MetaMessageController::updateCrm
* @see app/Http/Controllers/Meta/MetaMessageController.php:406
* @route '/api/meta/accounts/{account}/conversations/{conversation}/crm'
*/
updateCrm.url = (args: { account: string | { id: string }, conversation: string | { id: string } } | [account: string | { id: string }, conversation: string | { id: string } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            account: args[0],
            conversation: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        account: typeof args.account === 'object'
        ? args.account.id
        : args.account,
        conversation: typeof args.conversation === 'object'
        ? args.conversation.id
        : args.conversation,
    }

    return updateCrm.definition.url
            .replace('{account}', parsedArgs.account.toString())
            .replace('{conversation}', parsedArgs.conversation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Meta\MetaMessageController::updateCrm
* @see app/Http/Controllers/Meta/MetaMessageController.php:406
* @route '/api/meta/accounts/{account}/conversations/{conversation}/crm'
*/
updateCrm.patch = (args: { account: string | { id: string }, conversation: string | { id: string } } | [account: string | { id: string }, conversation: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateCrm.url(args, options),
    method: 'patch',
})

const MetaMessageController = { conversations, conversation, analyzeAndDraft, updateDraft, sendDraft, rejectDraft, send, updateCrm }

export default MetaMessageController