import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Meta\MetaReplyTemplateController::index
* @see app/Http/Controllers/Meta/MetaReplyTemplateController.php:13
* @route '/api/meta/accounts/{account}/templates'
*/
export const index = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/meta/accounts/{account}/templates',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Meta\MetaReplyTemplateController::index
* @see app/Http/Controllers/Meta/MetaReplyTemplateController.php:13
* @route '/api/meta/accounts/{account}/templates'
*/
index.url = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { account: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { account: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            account: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        account: typeof args.account === 'object'
        ? args.account.id
        : args.account,
    }

    return index.definition.url
            .replace('{account}', parsedArgs.account.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Meta\MetaReplyTemplateController::index
* @see app/Http/Controllers/Meta/MetaReplyTemplateController.php:13
* @route '/api/meta/accounts/{account}/templates'
*/
index.get = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Meta\MetaReplyTemplateController::index
* @see app/Http/Controllers/Meta/MetaReplyTemplateController.php:13
* @route '/api/meta/accounts/{account}/templates'
*/
index.head = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Meta\MetaReplyTemplateController::store
* @see app/Http/Controllers/Meta/MetaReplyTemplateController.php:26
* @route '/api/meta/accounts/{account}/templates'
*/
export const store = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/meta/accounts/{account}/templates',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Meta\MetaReplyTemplateController::store
* @see app/Http/Controllers/Meta/MetaReplyTemplateController.php:26
* @route '/api/meta/accounts/{account}/templates'
*/
store.url = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { account: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { account: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            account: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        account: typeof args.account === 'object'
        ? args.account.id
        : args.account,
    }

    return store.definition.url
            .replace('{account}', parsedArgs.account.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Meta\MetaReplyTemplateController::store
* @see app/Http/Controllers/Meta/MetaReplyTemplateController.php:26
* @route '/api/meta/accounts/{account}/templates'
*/
store.post = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Meta\MetaReplyTemplateController::update
* @see app/Http/Controllers/Meta/MetaReplyTemplateController.php:45
* @route '/api/meta/accounts/{account}/templates/{template}'
*/
export const update = (args: { account: string | { id: string }, template: string | { id: string } } | [account: string | { id: string }, template: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/meta/accounts/{account}/templates/{template}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Meta\MetaReplyTemplateController::update
* @see app/Http/Controllers/Meta/MetaReplyTemplateController.php:45
* @route '/api/meta/accounts/{account}/templates/{template}'
*/
update.url = (args: { account: string | { id: string }, template: string | { id: string } } | [account: string | { id: string }, template: string | { id: string } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            account: args[0],
            template: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        account: typeof args.account === 'object'
        ? args.account.id
        : args.account,
        template: typeof args.template === 'object'
        ? args.template.id
        : args.template,
    }

    return update.definition.url
            .replace('{account}', parsedArgs.account.toString())
            .replace('{template}', parsedArgs.template.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Meta\MetaReplyTemplateController::update
* @see app/Http/Controllers/Meta/MetaReplyTemplateController.php:45
* @route '/api/meta/accounts/{account}/templates/{template}'
*/
update.put = (args: { account: string | { id: string }, template: string | { id: string } } | [account: string | { id: string }, template: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Meta\MetaReplyTemplateController::destroy
* @see app/Http/Controllers/Meta/MetaReplyTemplateController.php:62
* @route '/api/meta/accounts/{account}/templates/{template}'
*/
export const destroy = (args: { account: string | { id: string }, template: string | { id: string } } | [account: string | { id: string }, template: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/meta/accounts/{account}/templates/{template}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Meta\MetaReplyTemplateController::destroy
* @see app/Http/Controllers/Meta/MetaReplyTemplateController.php:62
* @route '/api/meta/accounts/{account}/templates/{template}'
*/
destroy.url = (args: { account: string | { id: string }, template: string | { id: string } } | [account: string | { id: string }, template: string | { id: string } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            account: args[0],
            template: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        account: typeof args.account === 'object'
        ? args.account.id
        : args.account,
        template: typeof args.template === 'object'
        ? args.template.id
        : args.template,
    }

    return destroy.definition.url
            .replace('{account}', parsedArgs.account.toString())
            .replace('{template}', parsedArgs.template.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Meta\MetaReplyTemplateController::destroy
* @see app/Http/Controllers/Meta/MetaReplyTemplateController.php:62
* @route '/api/meta/accounts/{account}/templates/{template}'
*/
destroy.delete = (args: { account: string | { id: string }, template: string | { id: string } } | [account: string | { id: string }, template: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Meta\MetaReplyTemplateController::incrementUsage
* @see app/Http/Controllers/Meta/MetaReplyTemplateController.php:72
* @route '/api/meta/templates/{template}/use'
*/
export const incrementUsage = (args: { template: string | { id: string } } | [template: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: incrementUsage.url(args, options),
    method: 'post',
})

incrementUsage.definition = {
    methods: ["post"],
    url: '/api/meta/templates/{template}/use',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Meta\MetaReplyTemplateController::incrementUsage
* @see app/Http/Controllers/Meta/MetaReplyTemplateController.php:72
* @route '/api/meta/templates/{template}/use'
*/
incrementUsage.url = (args: { template: string | { id: string } } | [template: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { template: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { template: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            template: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        template: typeof args.template === 'object'
        ? args.template.id
        : args.template,
    }

    return incrementUsage.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Meta\MetaReplyTemplateController::incrementUsage
* @see app/Http/Controllers/Meta/MetaReplyTemplateController.php:72
* @route '/api/meta/templates/{template}/use'
*/
incrementUsage.post = (args: { template: string | { id: string } } | [template: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: incrementUsage.url(args, options),
    method: 'post',
})

const MetaReplyTemplateController = { index, store, update, destroy, incrementUsage }

export default MetaReplyTemplateController