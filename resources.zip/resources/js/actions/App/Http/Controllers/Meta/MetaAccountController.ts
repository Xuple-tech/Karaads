import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Meta\MetaAccountController::dashboard
* @see app/Http/Controllers/Meta/MetaAccountController.php:32
* @route '/api/meta/dashboard'
*/
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/api/meta/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Meta\MetaAccountController::dashboard
* @see app/Http/Controllers/Meta/MetaAccountController.php:32
* @route '/api/meta/dashboard'
*/
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Meta\MetaAccountController::dashboard
* @see app/Http/Controllers/Meta/MetaAccountController.php:32
* @route '/api/meta/dashboard'
*/
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Meta\MetaAccountController::dashboard
* @see app/Http/Controllers/Meta/MetaAccountController.php:32
* @route '/api/meta/dashboard'
*/
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Meta\MetaAccountController::index
* @see app/Http/Controllers/Meta/MetaAccountController.php:112
* @route '/api/meta/accounts'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/meta/accounts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Meta\MetaAccountController::index
* @see app/Http/Controllers/Meta/MetaAccountController.php:112
* @route '/api/meta/accounts'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Meta\MetaAccountController::index
* @see app/Http/Controllers/Meta/MetaAccountController.php:112
* @route '/api/meta/accounts'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Meta\MetaAccountController::index
* @see app/Http/Controllers/Meta/MetaAccountController.php:112
* @route '/api/meta/accounts'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Meta\MetaAccountController::initiateOAuth
* @see app/Http/Controllers/Meta/MetaAccountController.php:154
* @route '/api/meta/accounts/initiate-oauth'
*/
export const initiateOAuth = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: initiateOAuth.url(options),
    method: 'post',
})

initiateOAuth.definition = {
    methods: ["post"],
    url: '/api/meta/accounts/initiate-oauth',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Meta\MetaAccountController::initiateOAuth
* @see app/Http/Controllers/Meta/MetaAccountController.php:154
* @route '/api/meta/accounts/initiate-oauth'
*/
initiateOAuth.url = (options?: RouteQueryOptions) => {
    return initiateOAuth.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Meta\MetaAccountController::initiateOAuth
* @see app/Http/Controllers/Meta/MetaAccountController.php:154
* @route '/api/meta/accounts/initiate-oauth'
*/
initiateOAuth.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: initiateOAuth.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Meta\MetaAccountController::disconnect
* @see app/Http/Controllers/Meta/MetaAccountController.php:386
* @route '/api/meta/accounts/{account}'
*/
export const disconnect = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: disconnect.url(args, options),
    method: 'delete',
})

disconnect.definition = {
    methods: ["delete"],
    url: '/api/meta/accounts/{account}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Meta\MetaAccountController::disconnect
* @see app/Http/Controllers/Meta/MetaAccountController.php:386
* @route '/api/meta/accounts/{account}'
*/
disconnect.url = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { account: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { account: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            account: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        account: typeof args.account === 'object'
        ? args.account.id
        : args.account,
    }

    return disconnect.definition.url
            .replace('{account}', parsedArgs.account.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Meta\MetaAccountController::disconnect
* @see app/Http/Controllers/Meta/MetaAccountController.php:386
* @route '/api/meta/accounts/{account}'
*/
disconnect.delete = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: disconnect.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Meta\MetaAccountController::updateStatus
* @see app/Http/Controllers/Meta/MetaAccountController.php:437
* @route '/api/meta/accounts/{account}/status'
*/
export const updateStatus = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStatus.url(args, options),
    method: 'patch',
})

updateStatus.definition = {
    methods: ["patch"],
    url: '/api/meta/accounts/{account}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Meta\MetaAccountController::updateStatus
* @see app/Http/Controllers/Meta/MetaAccountController.php:437
* @route '/api/meta/accounts/{account}/status'
*/
updateStatus.url = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { account: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { account: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            account: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        account: typeof args.account === 'object'
        ? args.account.id
        : args.account,
    }

    return updateStatus.definition.url
            .replace('{account}', parsedArgs.account.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Meta\MetaAccountController::updateStatus
* @see app/Http/Controllers/Meta/MetaAccountController.php:437
* @route '/api/meta/accounts/{account}/status'
*/
updateStatus.patch = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStatus.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Meta\MetaAccountController::webhookInfo
* @see app/Http/Controllers/Meta/MetaAccountController.php:553
* @route '/api/meta/accounts/{account}/webhook-info'
*/
export const webhookInfo = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: webhookInfo.url(args, options),
    method: 'get',
})

webhookInfo.definition = {
    methods: ["get","head"],
    url: '/api/meta/accounts/{account}/webhook-info',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Meta\MetaAccountController::webhookInfo
* @see app/Http/Controllers/Meta/MetaAccountController.php:553
* @route '/api/meta/accounts/{account}/webhook-info'
*/
webhookInfo.url = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { account: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { account: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            account: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        account: typeof args.account === 'object'
        ? args.account.id
        : args.account,
    }

    return webhookInfo.definition.url
            .replace('{account}', parsedArgs.account.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Meta\MetaAccountController::webhookInfo
* @see app/Http/Controllers/Meta/MetaAccountController.php:553
* @route '/api/meta/accounts/{account}/webhook-info'
*/
webhookInfo.get = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: webhookInfo.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Meta\MetaAccountController::webhookInfo
* @see app/Http/Controllers/Meta/MetaAccountController.php:553
* @route '/api/meta/accounts/{account}/webhook-info'
*/
webhookInfo.head = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: webhookInfo.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Meta\MetaAccountController::testConnection
* @see app/Http/Controllers/Meta/MetaAccountController.php:482
* @route '/api/meta/accounts/{account}/test-connection'
*/
export const testConnection = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: testConnection.url(args, options),
    method: 'post',
})

testConnection.definition = {
    methods: ["post"],
    url: '/api/meta/accounts/{account}/test-connection',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Meta\MetaAccountController::testConnection
* @see app/Http/Controllers/Meta/MetaAccountController.php:482
* @route '/api/meta/accounts/{account}/test-connection'
*/
testConnection.url = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { account: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { account: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            account: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        account: typeof args.account === 'object'
        ? args.account.id
        : args.account,
    }

    return testConnection.definition.url
            .replace('{account}', parsedArgs.account.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Meta\MetaAccountController::testConnection
* @see app/Http/Controllers/Meta/MetaAccountController.php:482
* @route '/api/meta/accounts/{account}/test-connection'
*/
testConnection.post = (args: { account: string | { id: string } } | [account: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: testConnection.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Meta\MetaAccountController::handleCallback
* @see app/Http/Controllers/Meta/MetaAccountController.php:180
* @route '/meta/oauth/callback'
*/
export const handleCallback = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: handleCallback.url(options),
    method: 'get',
})

handleCallback.definition = {
    methods: ["get","head"],
    url: '/meta/oauth/callback',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Meta\MetaAccountController::handleCallback
* @see app/Http/Controllers/Meta/MetaAccountController.php:180
* @route '/meta/oauth/callback'
*/
handleCallback.url = (options?: RouteQueryOptions) => {
    return handleCallback.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Meta\MetaAccountController::handleCallback
* @see app/Http/Controllers/Meta/MetaAccountController.php:180
* @route '/meta/oauth/callback'
*/
handleCallback.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: handleCallback.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Meta\MetaAccountController::handleCallback
* @see app/Http/Controllers/Meta/MetaAccountController.php:180
* @route '/meta/oauth/callback'
*/
handleCallback.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: handleCallback.url(options),
    method: 'head',
})

const MetaAccountController = { dashboard, index, initiateOAuth, disconnect, updateStatus, webhookInfo, testConnection, handleCallback }

export default MetaAccountController