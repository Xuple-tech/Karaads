import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PaystackWebhookController::callback
* @see app/Http/Controllers/PaystackWebhookController.php:25
* @route '/paystack/callback'
*/
export const callback = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: callback.url(options),
    method: 'get',
})

callback.definition = {
    methods: ["get","head"],
    url: '/paystack/callback',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PaystackWebhookController::callback
* @see app/Http/Controllers/PaystackWebhookController.php:25
* @route '/paystack/callback'
*/
callback.url = (options?: RouteQueryOptions) => {
    return callback.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaystackWebhookController::callback
* @see app/Http/Controllers/PaystackWebhookController.php:25
* @route '/paystack/callback'
*/
callback.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: callback.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PaystackWebhookController::callback
* @see app/Http/Controllers/PaystackWebhookController.php:25
* @route '/paystack/callback'
*/
callback.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: callback.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PaystackWebhookController::webhook
* @see app/Http/Controllers/PaystackWebhookController.php:51
* @route '/paystack/webhook'
*/
export const webhook = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: webhook.url(options),
    method: 'post',
})

webhook.definition = {
    methods: ["post"],
    url: '/paystack/webhook',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PaystackWebhookController::webhook
* @see app/Http/Controllers/PaystackWebhookController.php:51
* @route '/paystack/webhook'
*/
webhook.url = (options?: RouteQueryOptions) => {
    return webhook.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaystackWebhookController::webhook
* @see app/Http/Controllers/PaystackWebhookController.php:51
* @route '/paystack/webhook'
*/
webhook.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: webhook.url(options),
    method: 'post',
})

const PaystackWebhookController = { callback, webhook }

export default PaystackWebhookController