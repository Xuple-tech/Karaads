import Auth from './Auth'
import OverviewController from './OverviewController'
import KeysController from './KeysController'
import UsageController from './UsageController'
import BillingController from './BillingController'
import ModelsController from './ModelsController'
const Console = {
    Auth: Object.assign(Auth, Auth),
OverviewController: Object.assign(OverviewController, OverviewController),
KeysController: Object.assign(KeysController, KeysController),
UsageController: Object.assign(UsageController, UsageController),
BillingController: Object.assign(BillingController, BillingController),
ModelsController: Object.assign(ModelsController, ModelsController),
}

export default Console