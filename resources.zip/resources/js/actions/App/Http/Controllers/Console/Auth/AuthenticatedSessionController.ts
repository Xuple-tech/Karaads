import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Console\Auth\AuthenticatedSessionController::create
 * @see app/Http/Controllers/Console/Auth/AuthenticatedSessionController.php:18
 * @route '/console/login'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/console/login',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Console\Auth\AuthenticatedSessionController::create
 * @see app/Http/Controllers/Console/Auth/AuthenticatedSessionController.php:18
 * @route '/console/login'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Console\Auth\AuthenticatedSessionController::create
 * @see app/Http/Controllers/Console/Auth/AuthenticatedSessionController.php:18
 * @route '/console/login'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Console\Auth\AuthenticatedSessionController::create
 * @see app/Http/Controllers/Console/Auth/AuthenticatedSessionController.php:18
 * @route '/console/login'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Console\Auth\AuthenticatedSessionController::store
 * @see app/Http/Controllers/Console/Auth/AuthenticatedSessionController.php:26
 * @route '/console/login'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/console/login',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Console\Auth\AuthenticatedSessionController::store
 * @see app/Http/Controllers/Console/Auth/AuthenticatedSessionController.php:26
 * @route '/console/login'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Console\Auth\AuthenticatedSessionController::store
 * @see app/Http/Controllers/Console/Auth/AuthenticatedSessionController.php:26
 * @route '/console/login'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Console\Auth\AuthenticatedSessionController::destroy
 * @see app/Http/Controllers/Console/Auth/AuthenticatedSessionController.php:66
 * @route '/console/logout'
 */
export const destroy = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: destroy.url(options),
    method: 'post',
})

destroy.definition = {
    methods: ["post"],
    url: '/console/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Console\Auth\AuthenticatedSessionController::destroy
 * @see app/Http/Controllers/Console/Auth/AuthenticatedSessionController.php:66
 * @route '/console/logout'
 */
destroy.url = (options?: RouteQueryOptions) => {
    return destroy.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Console\Auth\AuthenticatedSessionController::destroy
 * @see app/Http/Controllers/Console/Auth/AuthenticatedSessionController.php:66
 * @route '/console/logout'
 */
destroy.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: destroy.url(options),
    method: 'post',
})
const AuthenticatedSessionController = { create, store, destroy }

export default AuthenticatedSessionController