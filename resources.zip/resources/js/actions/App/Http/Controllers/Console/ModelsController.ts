import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Console\ModelsController::index
 * @see app/Http/Controllers/Console/ModelsController.php:11
 * @route '/console/models'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/console/models',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Console\ModelsController::index
 * @see app/Http/Controllers/Console/ModelsController.php:11
 * @route '/console/models'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Console\ModelsController::index
 * @see app/Http/Controllers/Console/ModelsController.php:11
 * @route '/console/models'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Console\ModelsController::index
 * @see app/Http/Controllers/Console/ModelsController.php:11
 * @route '/console/models'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})
const ModelsController = { index }

export default ModelsController