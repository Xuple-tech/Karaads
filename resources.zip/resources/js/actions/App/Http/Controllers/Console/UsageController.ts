import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Console\UsageController::index
 * @see app/Http/Controllers/Console/UsageController.php:11
 * @route '/console/usage'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/console/usage',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Console\UsageController::index
 * @see app/Http/Controllers/Console/UsageController.php:11
 * @route '/console/usage'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Console\UsageController::index
 * @see app/Http/Controllers/Console/UsageController.php:11
 * @route '/console/usage'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Console\UsageController::index
 * @see app/Http/Controllers/Console/UsageController.php:11
 * @route '/console/usage'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})
const UsageController = { index }

export default UsageController