import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Console\BillingController::index
 * @see app/Http/Controllers/Console/BillingController.php:11
 * @route '/console/billing'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/console/billing',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Console\BillingController::index
 * @see app/Http/Controllers/Console/BillingController.php:11
 * @route '/console/billing'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Console\BillingController::index
 * @see app/Http/Controllers/Console/BillingController.php:11
 * @route '/console/billing'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Console\BillingController::index
 * @see app/Http/Controllers/Console/BillingController.php:11
 * @route '/console/billing'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Console\BillingController::topup
 * @see app/Http/Controllers/Console/BillingController.php:60
 * @route '/console/billing/top-up'
 */
export const topup = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: topup.url(options),
    method: 'post',
})

topup.definition = {
    methods: ["post"],
    url: '/console/billing/top-up',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Console\BillingController::topup
 * @see app/Http/Controllers/Console/BillingController.php:60
 * @route '/console/billing/top-up'
 */
topup.url = (options?: RouteQueryOptions) => {
    return topup.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Console\BillingController::topup
 * @see app/Http/Controllers/Console/BillingController.php:60
 * @route '/console/billing/top-up'
 */
topup.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: topup.url(options),
    method: 'post',
})
const BillingController = { index, topup }

export default BillingController