import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Console\KeysController::index
 * @see app/Http/Controllers/Console/KeysController.php:13
 * @route '/console/keys'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/console/keys',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Console\KeysController::index
 * @see app/Http/Controllers/Console/KeysController.php:13
 * @route '/console/keys'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Console\KeysController::index
 * @see app/Http/Controllers/Console/KeysController.php:13
 * @route '/console/keys'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Console\KeysController::index
 * @see app/Http/Controllers/Console/KeysController.php:13
 * @route '/console/keys'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Console\KeysController::store
 * @see app/Http/Controllers/Console/KeysController.php:48
 * @route '/console/keys'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/console/keys',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Console\KeysController::store
 * @see app/Http/Controllers/Console/KeysController.php:48
 * @route '/console/keys'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Console\KeysController::store
 * @see app/Http/Controllers/Console/KeysController.php:48
 * @route '/console/keys'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Console\KeysController::update
 * @see app/Http/Controllers/Console/KeysController.php:71
 * @route '/console/keys/{developerApiKey}'
 */
export const update = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/console/keys/{developerApiKey}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Console\KeysController::update
 * @see app/Http/Controllers/Console/KeysController.php:71
 * @route '/console/keys/{developerApiKey}'
 */
update.url = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { developerApiKey: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { developerApiKey: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    developerApiKey: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        developerApiKey: typeof args.developerApiKey === 'object'
                ? args.developerApiKey.id
                : args.developerApiKey,
                }

    return update.definition.url
            .replace('{developerApiKey}', parsedArgs.developerApiKey.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Console\KeysController::update
 * @see app/Http/Controllers/Console/KeysController.php:71
 * @route '/console/keys/{developerApiKey}'
 */
update.put = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Console\KeysController::revoke
 * @see app/Http/Controllers/Console/KeysController.php:94
 * @route '/console/keys/{developerApiKey}/revoke'
 */
export const revoke = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: revoke.url(args, options),
    method: 'post',
})

revoke.definition = {
    methods: ["post"],
    url: '/console/keys/{developerApiKey}/revoke',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Console\KeysController::revoke
 * @see app/Http/Controllers/Console/KeysController.php:94
 * @route '/console/keys/{developerApiKey}/revoke'
 */
revoke.url = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { developerApiKey: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { developerApiKey: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    developerApiKey: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        developerApiKey: typeof args.developerApiKey === 'object'
                ? args.developerApiKey.id
                : args.developerApiKey,
                }

    return revoke.definition.url
            .replace('{developerApiKey}', parsedArgs.developerApiKey.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Console\KeysController::revoke
 * @see app/Http/Controllers/Console/KeysController.php:94
 * @route '/console/keys/{developerApiKey}/revoke'
 */
revoke.post = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: revoke.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Console\KeysController::regenerate
 * @see app/Http/Controllers/Console/KeysController.php:103
 * @route '/console/keys/{developerApiKey}/regenerate'
 */
export const regenerate = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerate.url(args, options),
    method: 'post',
})

regenerate.definition = {
    methods: ["post"],
    url: '/console/keys/{developerApiKey}/regenerate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Console\KeysController::regenerate
 * @see app/Http/Controllers/Console/KeysController.php:103
 * @route '/console/keys/{developerApiKey}/regenerate'
 */
regenerate.url = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { developerApiKey: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { developerApiKey: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    developerApiKey: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        developerApiKey: typeof args.developerApiKey === 'object'
                ? args.developerApiKey.id
                : args.developerApiKey,
                }

    return regenerate.definition.url
            .replace('{developerApiKey}', parsedArgs.developerApiKey.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Console\KeysController::regenerate
 * @see app/Http/Controllers/Console/KeysController.php:103
 * @route '/console/keys/{developerApiKey}/regenerate'
 */
regenerate.post = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerate.url(args, options),
    method: 'post',
})
const KeysController = { index, store, update, revoke, regenerate }

export default KeysController