import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Console\OverviewController::index
 * @see app/Http/Controllers/Console/OverviewController.php:11
 * @route '/console'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/console',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Console\OverviewController::index
 * @see app/Http/Controllers/Console/OverviewController.php:11
 * @route '/console'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Console\OverviewController::index
 * @see app/Http/Controllers/Console/OverviewController.php:11
 * @route '/console'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Console\OverviewController::index
 * @see app/Http/Controllers/Console/OverviewController.php:11
 * @route '/console'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})
const OverviewController = { index }

export default OverviewController