import ConversationController from './ConversationController'
import MessageController from './MessageController'

const Chat = {
    ConversationController: Object.assign(ConversationController, ConversationController),
    MessageController: Object.assign(MessageController, MessageController),
}

export default Chat