import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\SessionAuthController::session
* @see app/Http/Controllers/Api/SessionAuthController.php:24
* @route '/api/session/user'
*/
export const session = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: session.url(options),
    method: 'get',
})

session.definition = {
    methods: ["get","head"],
    url: '/api/session/user',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\SessionAuthController::session
* @see app/Http/Controllers/Api/SessionAuthController.php:24
* @route '/api/session/user'
*/
session.url = (options?: RouteQueryOptions) => {
    return session.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SessionAuthController::session
* @see app/Http/Controllers/Api/SessionAuthController.php:24
* @route '/api/session/user'
*/
session.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: session.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\SessionAuthController::session
* @see app/Http/Controllers/Api/SessionAuthController.php:24
* @route '/api/session/user'
*/
session.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: session.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\SessionAuthController::login
* @see app/Http/Controllers/Api/SessionAuthController.php:35
* @route '/api/session/login'
*/
export const login = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

login.definition = {
    methods: ["post"],
    url: '/api/session/login',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\SessionAuthController::login
* @see app/Http/Controllers/Api/SessionAuthController.php:35
* @route '/api/session/login'
*/
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SessionAuthController::login
* @see app/Http/Controllers/Api/SessionAuthController.php:35
* @route '/api/session/login'
*/
login.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\SessionAuthController::register
* @see app/Http/Controllers/Api/SessionAuthController.php:62
* @route '/api/session/register'
*/
export const register = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

register.definition = {
    methods: ["post"],
    url: '/api/session/register',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\SessionAuthController::register
* @see app/Http/Controllers/Api/SessionAuthController.php:62
* @route '/api/session/register'
*/
register.url = (options?: RouteQueryOptions) => {
    return register.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SessionAuthController::register
* @see app/Http/Controllers/Api/SessionAuthController.php:62
* @route '/api/session/register'
*/
register.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\SessionAuthController::forgotPassword
* @see app/Http/Controllers/Api/SessionAuthController.php:105
* @route '/api/session/forgot-password'
*/
export const forgotPassword = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: forgotPassword.url(options),
    method: 'post',
})

forgotPassword.definition = {
    methods: ["post"],
    url: '/api/session/forgot-password',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\SessionAuthController::forgotPassword
* @see app/Http/Controllers/Api/SessionAuthController.php:105
* @route '/api/session/forgot-password'
*/
forgotPassword.url = (options?: RouteQueryOptions) => {
    return forgotPassword.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SessionAuthController::forgotPassword
* @see app/Http/Controllers/Api/SessionAuthController.php:105
* @route '/api/session/forgot-password'
*/
forgotPassword.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: forgotPassword.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\SessionAuthController::resetPassword
* @see app/Http/Controllers/Api/SessionAuthController.php:119
* @route '/api/session/reset-password'
*/
export const resetPassword = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetPassword.url(options),
    method: 'post',
})

resetPassword.definition = {
    methods: ["post"],
    url: '/api/session/reset-password',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\SessionAuthController::resetPassword
* @see app/Http/Controllers/Api/SessionAuthController.php:119
* @route '/api/session/reset-password'
*/
resetPassword.url = (options?: RouteQueryOptions) => {
    return resetPassword.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SessionAuthController::resetPassword
* @see app/Http/Controllers/Api/SessionAuthController.php:119
* @route '/api/session/reset-password'
*/
resetPassword.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetPassword.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\SessionAuthController::verifyEmail
* @see app/Http/Controllers/Api/SessionAuthController.php:161
* @route '/api/session/verify-email/{id}/{hash}'
*/
export const verifyEmail = (args: { id: string | number, hash: string | number } | [id: string | number, hash: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: verifyEmail.url(args, options),
    method: 'get',
})

verifyEmail.definition = {
    methods: ["get","head"],
    url: '/api/session/verify-email/{id}/{hash}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\SessionAuthController::verifyEmail
* @see app/Http/Controllers/Api/SessionAuthController.php:161
* @route '/api/session/verify-email/{id}/{hash}'
*/
verifyEmail.url = (args: { id: string | number, hash: string | number } | [id: string | number, hash: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            id: args[0],
            hash: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
        hash: args.hash,
    }

    return verifyEmail.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace('{hash}', parsedArgs.hash.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SessionAuthController::verifyEmail
* @see app/Http/Controllers/Api/SessionAuthController.php:161
* @route '/api/session/verify-email/{id}/{hash}'
*/
verifyEmail.get = (args: { id: string | number, hash: string | number } | [id: string | number, hash: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: verifyEmail.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\SessionAuthController::verifyEmail
* @see app/Http/Controllers/Api/SessionAuthController.php:161
* @route '/api/session/verify-email/{id}/{hash}'
*/
verifyEmail.head = (args: { id: string | number, hash: string | number } | [id: string | number, hash: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: verifyEmail.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\SessionAuthController::logout
* @see app/Http/Controllers/Api/SessionAuthController.php:96
* @route '/api/session/logout'
*/
export const logout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

logout.definition = {
    methods: ["post"],
    url: '/api/session/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\SessionAuthController::logout
* @see app/Http/Controllers/Api/SessionAuthController.php:96
* @route '/api/session/logout'
*/
logout.url = (options?: RouteQueryOptions) => {
    return logout.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SessionAuthController::logout
* @see app/Http/Controllers/Api/SessionAuthController.php:96
* @route '/api/session/logout'
*/
logout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\SessionAuthController::confirmPassword
* @see app/Http/Controllers/Api/SessionAuthController.php:175
* @route '/api/session/confirm-password'
*/
export const confirmPassword = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: confirmPassword.url(options),
    method: 'post',
})

confirmPassword.definition = {
    methods: ["post"],
    url: '/api/session/confirm-password',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\SessionAuthController::confirmPassword
* @see app/Http/Controllers/Api/SessionAuthController.php:175
* @route '/api/session/confirm-password'
*/
confirmPassword.url = (options?: RouteQueryOptions) => {
    return confirmPassword.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SessionAuthController::confirmPassword
* @see app/Http/Controllers/Api/SessionAuthController.php:175
* @route '/api/session/confirm-password'
*/
confirmPassword.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: confirmPassword.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\SessionAuthController::resendVerification
* @see app/Http/Controllers/Api/SessionAuthController.php:151
* @route '/api/session/email/verification-notification'
*/
export const resendVerification = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resendVerification.url(options),
    method: 'post',
})

resendVerification.definition = {
    methods: ["post"],
    url: '/api/session/email/verification-notification',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\SessionAuthController::resendVerification
* @see app/Http/Controllers/Api/SessionAuthController.php:151
* @route '/api/session/email/verification-notification'
*/
resendVerification.url = (options?: RouteQueryOptions) => {
    return resendVerification.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SessionAuthController::resendVerification
* @see app/Http/Controllers/Api/SessionAuthController.php:151
* @route '/api/session/email/verification-notification'
*/
resendVerification.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resendVerification.url(options),
    method: 'post',
})

const SessionAuthController = { session, login, register, forgotPassword, resetPassword, verifyEmail, logout, confirmPassword, resendVerification }

export default SessionAuthController