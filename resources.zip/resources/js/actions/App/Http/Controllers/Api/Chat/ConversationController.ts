import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Chat\ConversationController::index
* @see app/Http/Controllers/Api/Chat/ConversationController.php:21
* @route '/api/chat/conversations'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/chat/conversations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Chat\ConversationController::index
* @see app/Http/Controllers/Api/Chat/ConversationController.php:21
* @route '/api/chat/conversations'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Chat\ConversationController::index
* @see app/Http/Controllers/Api/Chat/ConversationController.php:21
* @route '/api/chat/conversations'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\Chat\ConversationController::index
* @see app/Http/Controllers/Api/Chat/ConversationController.php:21
* @route '/api/chat/conversations'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\Chat\ConversationController::store
* @see app/Http/Controllers/Api/Chat/ConversationController.php:29
* @route '/api/chat/conversations'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/chat/conversations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Chat\ConversationController::store
* @see app/Http/Controllers/Api/Chat/ConversationController.php:29
* @route '/api/chat/conversations'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Chat\ConversationController::store
* @see app/Http/Controllers/Api/Chat/ConversationController.php:29
* @route '/api/chat/conversations'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\Chat\ConversationController::destroyAll
* @see app/Http/Controllers/Api/Chat/ConversationController.php:91
* @route '/api/chat/conversations'
*/
export const destroyAll = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyAll.url(options),
    method: 'delete',
})

destroyAll.definition = {
    methods: ["delete"],
    url: '/api/chat/conversations',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\Chat\ConversationController::destroyAll
* @see app/Http/Controllers/Api/Chat/ConversationController.php:91
* @route '/api/chat/conversations'
*/
destroyAll.url = (options?: RouteQueryOptions) => {
    return destroyAll.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Chat\ConversationController::destroyAll
* @see app/Http/Controllers/Api/Chat/ConversationController.php:91
* @route '/api/chat/conversations'
*/
destroyAll.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyAll.url(options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Api\Chat\ConversationController::show
* @see app/Http/Controllers/Api/Chat/ConversationController.php:46
* @route '/api/chat/conversations/{conversation}'
*/
export const show = (args: { conversation: string | { id: string } } | [conversation: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/chat/conversations/{conversation}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Chat\ConversationController::show
* @see app/Http/Controllers/Api/Chat/ConversationController.php:46
* @route '/api/chat/conversations/{conversation}'
*/
show.url = (args: { conversation: string | { id: string } } | [conversation: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { conversation: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { conversation: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            conversation: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        conversation: typeof args.conversation === 'object'
        ? args.conversation.id
        : args.conversation,
    }

    return show.definition.url
            .replace('{conversation}', parsedArgs.conversation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Chat\ConversationController::show
* @see app/Http/Controllers/Api/Chat/ConversationController.php:46
* @route '/api/chat/conversations/{conversation}'
*/
show.get = (args: { conversation: string | { id: string } } | [conversation: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\Chat\ConversationController::show
* @see app/Http/Controllers/Api/Chat/ConversationController.php:46
* @route '/api/chat/conversations/{conversation}'
*/
show.head = (args: { conversation: string | { id: string } } | [conversation: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\Chat\ConversationController::exportMethod
* @see app/Http/Controllers/Api/Chat/ConversationController.php:106
* @route '/api/chat/conversations/{conversation}/export'
*/
export const exportMethod = (args: { conversation: string | { id: string } } | [conversation: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(args, options),
    method: 'get',
})

exportMethod.definition = {
    methods: ["get","head"],
    url: '/api/chat/conversations/{conversation}/export',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Chat\ConversationController::exportMethod
* @see app/Http/Controllers/Api/Chat/ConversationController.php:106
* @route '/api/chat/conversations/{conversation}/export'
*/
exportMethod.url = (args: { conversation: string | { id: string } } | [conversation: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { conversation: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { conversation: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            conversation: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        conversation: typeof args.conversation === 'object'
        ? args.conversation.id
        : args.conversation,
    }

    return exportMethod.definition.url
            .replace('{conversation}', parsedArgs.conversation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Chat\ConversationController::exportMethod
* @see app/Http/Controllers/Api/Chat/ConversationController.php:106
* @route '/api/chat/conversations/{conversation}/export'
*/
exportMethod.get = (args: { conversation: string | { id: string } } | [conversation: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\Chat\ConversationController::exportMethod
* @see app/Http/Controllers/Api/Chat/ConversationController.php:106
* @route '/api/chat/conversations/{conversation}/export'
*/
exportMethod.head = (args: { conversation: string | { id: string } } | [conversation: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportMethod.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\Chat\ConversationController::update
* @see app/Http/Controllers/Api/Chat/ConversationController.php:54
* @route '/api/chat/conversations/{conversation}'
*/
export const update = (args: { conversation: string | { id: string } } | [conversation: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/api/chat/conversations/{conversation}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Api\Chat\ConversationController::update
* @see app/Http/Controllers/Api/Chat/ConversationController.php:54
* @route '/api/chat/conversations/{conversation}'
*/
update.url = (args: { conversation: string | { id: string } } | [conversation: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { conversation: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { conversation: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            conversation: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        conversation: typeof args.conversation === 'object'
        ? args.conversation.id
        : args.conversation,
    }

    return update.definition.url
            .replace('{conversation}', parsedArgs.conversation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Chat\ConversationController::update
* @see app/Http/Controllers/Api/Chat/ConversationController.php:54
* @route '/api/chat/conversations/{conversation}'
*/
update.patch = (args: { conversation: string | { id: string } } | [conversation: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Api\Chat\ConversationController::destroy
* @see app/Http/Controllers/Api/Chat/ConversationController.php:75
* @route '/api/chat/conversations/{conversation}'
*/
export const destroy = (args: { conversation: string | { id: string } } | [conversation: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/chat/conversations/{conversation}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\Chat\ConversationController::destroy
* @see app/Http/Controllers/Api/Chat/ConversationController.php:75
* @route '/api/chat/conversations/{conversation}'
*/
destroy.url = (args: { conversation: string | { id: string } } | [conversation: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { conversation: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { conversation: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            conversation: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        conversation: typeof args.conversation === 'object'
        ? args.conversation.id
        : args.conversation,
    }

    return destroy.definition.url
            .replace('{conversation}', parsedArgs.conversation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Chat\ConversationController::destroy
* @see app/Http/Controllers/Api/Chat/ConversationController.php:75
* @route '/api/chat/conversations/{conversation}'
*/
destroy.delete = (args: { conversation: string | { id: string } } | [conversation: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

const ConversationController = { index, store, destroyAll, show, exportMethod, update, destroy, export: exportMethod }

export default ConversationController