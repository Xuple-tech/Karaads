import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Chat\MessageController::store
* @see app/Http/Controllers/Api/Chat/MessageController.php:28
* @route '/api/chat/messages'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/chat/messages',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Chat\MessageController::store
* @see app/Http/Controllers/Api/Chat/MessageController.php:28
* @route '/api/chat/messages'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Chat\MessageController::store
* @see app/Http/Controllers/Api/Chat/MessageController.php:28
* @route '/api/chat/messages'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\Chat\MessageController::storeStream
* @see app/Http/Controllers/Api/Chat/MessageController.php:59
* @route '/api/chat/messages/stream'
*/
export const storeStream = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeStream.url(options),
    method: 'post',
})

storeStream.definition = {
    methods: ["post"],
    url: '/api/chat/messages/stream',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Chat\MessageController::storeStream
* @see app/Http/Controllers/Api/Chat/MessageController.php:59
* @route '/api/chat/messages/stream'
*/
storeStream.url = (options?: RouteQueryOptions) => {
    return storeStream.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Chat\MessageController::storeStream
* @see app/Http/Controllers/Api/Chat/MessageController.php:59
* @route '/api/chat/messages/stream'
*/
storeStream.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeStream.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\Chat\MessageController::regenerate
* @see app/Http/Controllers/Api/Chat/MessageController.php:92
* @route '/api/chat/messages/{message}/regenerate'
*/
export const regenerate = (args: { message: string | { id: string } } | [message: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerate.url(args, options),
    method: 'post',
})

regenerate.definition = {
    methods: ["post"],
    url: '/api/chat/messages/{message}/regenerate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Chat\MessageController::regenerate
* @see app/Http/Controllers/Api/Chat/MessageController.php:92
* @route '/api/chat/messages/{message}/regenerate'
*/
regenerate.url = (args: { message: string | { id: string } } | [message: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { message: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { message: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            message: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        message: typeof args.message === 'object'
        ? args.message.id
        : args.message,
    }

    return regenerate.definition.url
            .replace('{message}', parsedArgs.message.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Chat\MessageController::regenerate
* @see app/Http/Controllers/Api/Chat/MessageController.php:92
* @route '/api/chat/messages/{message}/regenerate'
*/
regenerate.post = (args: { message: string | { id: string } } | [message: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerate.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\Chat\MessageController::regenerateStream
* @see app/Http/Controllers/Api/Chat/MessageController.php:115
* @route '/api/chat/messages/{message}/regenerate/stream'
*/
export const regenerateStream = (args: { message: string | { id: string } } | [message: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerateStream.url(args, options),
    method: 'post',
})

regenerateStream.definition = {
    methods: ["post"],
    url: '/api/chat/messages/{message}/regenerate/stream',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Chat\MessageController::regenerateStream
* @see app/Http/Controllers/Api/Chat/MessageController.php:115
* @route '/api/chat/messages/{message}/regenerate/stream'
*/
regenerateStream.url = (args: { message: string | { id: string } } | [message: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { message: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { message: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            message: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        message: typeof args.message === 'object'
        ? args.message.id
        : args.message,
    }

    return regenerateStream.definition.url
            .replace('{message}', parsedArgs.message.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Chat\MessageController::regenerateStream
* @see app/Http/Controllers/Api/Chat/MessageController.php:115
* @route '/api/chat/messages/{message}/regenerate/stream'
*/
regenerateStream.post = (args: { message: string | { id: string } } | [message: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerateStream.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\Chat\MessageController::file
* @see app/Http/Controllers/Api/Chat/MessageController.php:140
* @route '/api/chat/files/{file}'
*/
export const file = (args: { file: string | number } | [file: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: file.url(args, options),
    method: 'get',
})

file.definition = {
    methods: ["get","head"],
    url: '/api/chat/files/{file}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Chat\MessageController::file
* @see app/Http/Controllers/Api/Chat/MessageController.php:140
* @route '/api/chat/files/{file}'
*/
file.url = (args: { file: string | number } | [file: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { file: args }
    }

    if (Array.isArray(args)) {
        args = {
            file: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        file: args.file,
    }

    return file.definition.url
            .replace('{file}', parsedArgs.file.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Chat\MessageController::file
* @see app/Http/Controllers/Api/Chat/MessageController.php:140
* @route '/api/chat/files/{file}'
*/
file.get = (args: { file: string | number } | [file: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: file.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\Chat\MessageController::file
* @see app/Http/Controllers/Api/Chat/MessageController.php:140
* @route '/api/chat/files/{file}'
*/
file.head = (args: { file: string | number } | [file: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: file.url(args, options),
    method: 'head',
})

const MessageController = { store, storeStream, regenerate, regenerateStream, file }

export default MessageController