import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::index
* @see app/Http/Controllers/Admin/DeveloperApiController.php:26
* @route '/admin/developer-api'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/developer-api',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::index
* @see app/Http/Controllers/Admin/DeveloperApiController.php:26
* @route '/admin/developer-api'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::index
* @see app/Http/Controllers/Admin/DeveloperApiController.php:26
* @route '/admin/developer-api'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::index
* @see app/Http/Controllers/Admin/DeveloperApiController.php:26
* @route '/admin/developer-api'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::storeModel
* @see app/Http/Controllers/Admin/DeveloperApiController.php:136
* @route '/admin/developer-api/models'
*/
export const storeModel = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeModel.url(options),
    method: 'post',
})

storeModel.definition = {
    methods: ["post"],
    url: '/admin/developer-api/models',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::storeModel
* @see app/Http/Controllers/Admin/DeveloperApiController.php:136
* @route '/admin/developer-api/models'
*/
storeModel.url = (options?: RouteQueryOptions) => {
    return storeModel.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::storeModel
* @see app/Http/Controllers/Admin/DeveloperApiController.php:136
* @route '/admin/developer-api/models'
*/
storeModel.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeModel.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::updateModel
* @see app/Http/Controllers/Admin/DeveloperApiController.php:157
* @route '/admin/developer-api/models/{apiModel}'
*/
export const updateModel = (args: { apiModel: string | { id: string } } | [apiModel: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateModel.url(args, options),
    method: 'put',
})

updateModel.definition = {
    methods: ["put"],
    url: '/admin/developer-api/models/{apiModel}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::updateModel
* @see app/Http/Controllers/Admin/DeveloperApiController.php:157
* @route '/admin/developer-api/models/{apiModel}'
*/
updateModel.url = (args: { apiModel: string | { id: string } } | [apiModel: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { apiModel: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { apiModel: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            apiModel: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        apiModel: typeof args.apiModel === 'object'
        ? args.apiModel.id
        : args.apiModel,
    }

    return updateModel.definition.url
            .replace('{apiModel}', parsedArgs.apiModel.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::updateModel
* @see app/Http/Controllers/Admin/DeveloperApiController.php:157
* @route '/admin/developer-api/models/{apiModel}'
*/
updateModel.put = (args: { apiModel: string | { id: string } } | [apiModel: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateModel.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::toggleModel
* @see app/Http/Controllers/Admin/DeveloperApiController.php:177
* @route '/admin/developer-api/models/{apiModel}/toggle'
*/
export const toggleModel = (args: { apiModel: string | { id: string } } | [apiModel: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleModel.url(args, options),
    method: 'post',
})

toggleModel.definition = {
    methods: ["post"],
    url: '/admin/developer-api/models/{apiModel}/toggle',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::toggleModel
* @see app/Http/Controllers/Admin/DeveloperApiController.php:177
* @route '/admin/developer-api/models/{apiModel}/toggle'
*/
toggleModel.url = (args: { apiModel: string | { id: string } } | [apiModel: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { apiModel: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { apiModel: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            apiModel: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        apiModel: typeof args.apiModel === 'object'
        ? args.apiModel.id
        : args.apiModel,
    }

    return toggleModel.definition.url
            .replace('{apiModel}', parsedArgs.apiModel.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::toggleModel
* @see app/Http/Controllers/Admin/DeveloperApiController.php:177
* @route '/admin/developer-api/models/{apiModel}/toggle'
*/
toggleModel.post = (args: { apiModel: string | { id: string } } | [apiModel: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleModel.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::toggleKey
* @see app/Http/Controllers/Admin/DeveloperApiController.php:184
* @route '/admin/developer-api/keys/{developerApiKey}/toggle'
*/
export const toggleKey = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleKey.url(args, options),
    method: 'post',
})

toggleKey.definition = {
    methods: ["post"],
    url: '/admin/developer-api/keys/{developerApiKey}/toggle',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::toggleKey
* @see app/Http/Controllers/Admin/DeveloperApiController.php:184
* @route '/admin/developer-api/keys/{developerApiKey}/toggle'
*/
toggleKey.url = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { developerApiKey: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { developerApiKey: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            developerApiKey: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        developerApiKey: typeof args.developerApiKey === 'object'
        ? args.developerApiKey.id
        : args.developerApiKey,
    }

    return toggleKey.definition.url
            .replace('{developerApiKey}', parsedArgs.developerApiKey.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::toggleKey
* @see app/Http/Controllers/Admin/DeveloperApiController.php:184
* @route '/admin/developer-api/keys/{developerApiKey}/toggle'
*/
toggleKey.post = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleKey.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::regenerateKey
* @see app/Http/Controllers/Admin/DeveloperApiController.php:191
* @route '/admin/developer-api/keys/{developerApiKey}/regenerate'
*/
export const regenerateKey = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerateKey.url(args, options),
    method: 'post',
})

regenerateKey.definition = {
    methods: ["post"],
    url: '/admin/developer-api/keys/{developerApiKey}/regenerate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::regenerateKey
* @see app/Http/Controllers/Admin/DeveloperApiController.php:191
* @route '/admin/developer-api/keys/{developerApiKey}/regenerate'
*/
regenerateKey.url = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { developerApiKey: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { developerApiKey: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            developerApiKey: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        developerApiKey: typeof args.developerApiKey === 'object'
        ? args.developerApiKey.id
        : args.developerApiKey,
    }

    return regenerateKey.definition.url
            .replace('{developerApiKey}', parsedArgs.developerApiKey.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::regenerateKey
* @see app/Http/Controllers/Admin/DeveloperApiController.php:191
* @route '/admin/developer-api/keys/{developerApiKey}/regenerate'
*/
regenerateKey.post = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerateKey.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::adjustWallet
* @see app/Http/Controllers/Admin/DeveloperApiController.php:200
* @route '/admin/developer-api/wallets/{user}/adjust'
*/
export const adjustWallet = (args: { user: string | { id: string } } | [user: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adjustWallet.url(args, options),
    method: 'post',
})

adjustWallet.definition = {
    methods: ["post"],
    url: '/admin/developer-api/wallets/{user}/adjust',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::adjustWallet
* @see app/Http/Controllers/Admin/DeveloperApiController.php:200
* @route '/admin/developer-api/wallets/{user}/adjust'
*/
adjustWallet.url = (args: { user: string | { id: string } } | [user: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { user: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            user: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        user: typeof args.user === 'object'
        ? args.user.id
        : args.user,
    }

    return adjustWallet.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::adjustWallet
* @see app/Http/Controllers/Admin/DeveloperApiController.php:200
* @route '/admin/developer-api/wallets/{user}/adjust'
*/
adjustWallet.post = (args: { user: string | { id: string } } | [user: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adjustWallet.url(args, options),
    method: 'post',
})

const DeveloperApiController = { index, storeModel, updateModel, toggleModel, toggleKey, regenerateKey, adjustWallet }

export default DeveloperApiController