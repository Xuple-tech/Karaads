import AdminSessionController from './AdminSessionController'

const Auth = {
    AdminSessionController: Object.assign(AdminSessionController, AdminSessionController),
}

export default Auth