import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\WidgetWebsiteSourceController::pluginSync
* @see app/Http/Controllers/WidgetWebsiteSourceController.php:104
* @route '/api/widget/plugin/{token}/sync'
*/
export const pluginSync = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pluginSync.url(args, options),
    method: 'post',
})

pluginSync.definition = {
    methods: ["post"],
    url: '/api/widget/plugin/{token}/sync',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\WidgetWebsiteSourceController::pluginSync
* @see app/Http/Controllers/WidgetWebsiteSourceController.php:104
* @route '/api/widget/plugin/{token}/sync'
*/
pluginSync.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    if (Array.isArray(args)) {
        args = {
            token: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        token: args.token,
    }

    return pluginSync.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\WidgetWebsiteSourceController::pluginSync
* @see app/Http/Controllers/WidgetWebsiteSourceController.php:104
* @route '/api/widget/plugin/{token}/sync'
*/
pluginSync.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pluginSync.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\WidgetWebsiteSourceController::store
* @see app/Http/Controllers/WidgetWebsiteSourceController.php:19
* @route '/api/widget/{widget}/website-sources'
*/
export const store = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/widget/{widget}/website-sources',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\WidgetWebsiteSourceController::store
* @see app/Http/Controllers/WidgetWebsiteSourceController.php:19
* @route '/api/widget/{widget}/website-sources'
*/
store.url = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { widget: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { widget: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            widget: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        widget: typeof args.widget === 'object'
        ? args.widget.id
        : args.widget,
    }

    return store.definition.url
            .replace('{widget}', parsedArgs.widget.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\WidgetWebsiteSourceController::store
* @see app/Http/Controllers/WidgetWebsiteSourceController.php:19
* @route '/api/widget/{widget}/website-sources'
*/
store.post = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\WidgetWebsiteSourceController::update
* @see app/Http/Controllers/WidgetWebsiteSourceController.php:36
* @route '/api/widget/{widget}/website-sources/{source}'
*/
export const update = (args: { widget: string | { id: string }, source: string | { id: string } } | [widget: string | { id: string }, source: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/widget/{widget}/website-sources/{source}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\WidgetWebsiteSourceController::update
* @see app/Http/Controllers/WidgetWebsiteSourceController.php:36
* @route '/api/widget/{widget}/website-sources/{source}'
*/
update.url = (args: { widget: string | { id: string }, source: string | { id: string } } | [widget: string | { id: string }, source: string | { id: string } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            widget: args[0],
            source: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        widget: typeof args.widget === 'object'
        ? args.widget.id
        : args.widget,
        source: typeof args.source === 'object'
        ? args.source.id
        : args.source,
    }

    return update.definition.url
            .replace('{widget}', parsedArgs.widget.toString())
            .replace('{source}', parsedArgs.source.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\WidgetWebsiteSourceController::update
* @see app/Http/Controllers/WidgetWebsiteSourceController.php:36
* @route '/api/widget/{widget}/website-sources/{source}'
*/
update.put = (args: { widget: string | { id: string }, source: string | { id: string } } | [widget: string | { id: string }, source: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\WidgetWebsiteSourceController::verify
* @see app/Http/Controllers/WidgetWebsiteSourceController.php:54
* @route '/api/widget/{widget}/website-sources/{source}/verify'
*/
export const verify = (args: { widget: string | { id: string }, source: string | { id: string } } | [widget: string | { id: string }, source: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verify.url(args, options),
    method: 'post',
})

verify.definition = {
    methods: ["post"],
    url: '/api/widget/{widget}/website-sources/{source}/verify',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\WidgetWebsiteSourceController::verify
* @see app/Http/Controllers/WidgetWebsiteSourceController.php:54
* @route '/api/widget/{widget}/website-sources/{source}/verify'
*/
verify.url = (args: { widget: string | { id: string }, source: string | { id: string } } | [widget: string | { id: string }, source: string | { id: string } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            widget: args[0],
            source: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        widget: typeof args.widget === 'object'
        ? args.widget.id
        : args.widget,
        source: typeof args.source === 'object'
        ? args.source.id
        : args.source,
    }

    return verify.definition.url
            .replace('{widget}', parsedArgs.widget.toString())
            .replace('{source}', parsedArgs.source.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\WidgetWebsiteSourceController::verify
* @see app/Http/Controllers/WidgetWebsiteSourceController.php:54
* @route '/api/widget/{widget}/website-sources/{source}/verify'
*/
verify.post = (args: { widget: string | { id: string }, source: string | { id: string } } | [widget: string | { id: string }, source: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verify.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\WidgetWebsiteSourceController::crawl
* @see app/Http/Controllers/WidgetWebsiteSourceController.php:73
* @route '/api/widget/{widget}/website-sources/{source}/crawl'
*/
export const crawl = (args: { widget: string | { id: string }, source: string | { id: string } } | [widget: string | { id: string }, source: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: crawl.url(args, options),
    method: 'post',
})

crawl.definition = {
    methods: ["post"],
    url: '/api/widget/{widget}/website-sources/{source}/crawl',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\WidgetWebsiteSourceController::crawl
* @see app/Http/Controllers/WidgetWebsiteSourceController.php:73
* @route '/api/widget/{widget}/website-sources/{source}/crawl'
*/
crawl.url = (args: { widget: string | { id: string }, source: string | { id: string } } | [widget: string | { id: string }, source: string | { id: string } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            widget: args[0],
            source: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        widget: typeof args.widget === 'object'
        ? args.widget.id
        : args.widget,
        source: typeof args.source === 'object'
        ? args.source.id
        : args.source,
    }

    return crawl.definition.url
            .replace('{widget}', parsedArgs.widget.toString())
            .replace('{source}', parsedArgs.source.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\WidgetWebsiteSourceController::crawl
* @see app/Http/Controllers/WidgetWebsiteSourceController.php:73
* @route '/api/widget/{widget}/website-sources/{source}/crawl'
*/
crawl.post = (args: { widget: string | { id: string }, source: string | { id: string } } | [widget: string | { id: string }, source: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: crawl.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\WidgetWebsiteSourceController::verificationFile
* @see app/Http/Controllers/WidgetWebsiteSourceController.php:90
* @route '/api/widget/{widget}/website-sources/{source}/verification-file'
*/
export const verificationFile = (args: { widget: string | { id: string }, source: string | { id: string } } | [widget: string | { id: string }, source: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: verificationFile.url(args, options),
    method: 'get',
})

verificationFile.definition = {
    methods: ["get","head"],
    url: '/api/widget/{widget}/website-sources/{source}/verification-file',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\WidgetWebsiteSourceController::verificationFile
* @see app/Http/Controllers/WidgetWebsiteSourceController.php:90
* @route '/api/widget/{widget}/website-sources/{source}/verification-file'
*/
verificationFile.url = (args: { widget: string | { id: string }, source: string | { id: string } } | [widget: string | { id: string }, source: string | { id: string } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            widget: args[0],
            source: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        widget: typeof args.widget === 'object'
        ? args.widget.id
        : args.widget,
        source: typeof args.source === 'object'
        ? args.source.id
        : args.source,
    }

    return verificationFile.definition.url
            .replace('{widget}', parsedArgs.widget.toString())
            .replace('{source}', parsedArgs.source.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\WidgetWebsiteSourceController::verificationFile
* @see app/Http/Controllers/WidgetWebsiteSourceController.php:90
* @route '/api/widget/{widget}/website-sources/{source}/verification-file'
*/
verificationFile.get = (args: { widget: string | { id: string }, source: string | { id: string } } | [widget: string | { id: string }, source: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: verificationFile.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\WidgetWebsiteSourceController::verificationFile
* @see app/Http/Controllers/WidgetWebsiteSourceController.php:90
* @route '/api/widget/{widget}/website-sources/{source}/verification-file'
*/
verificationFile.head = (args: { widget: string | { id: string }, source: string | { id: string } } | [widget: string | { id: string }, source: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: verificationFile.url(args, options),
    method: 'head',
})

const WidgetWebsiteSourceController = { pluginSync, store, update, verify, crawl, verificationFile }

export default WidgetWebsiteSourceController