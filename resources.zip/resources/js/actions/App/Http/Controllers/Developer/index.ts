import DeveloperPortalController from './DeveloperPortalController'
import DeveloperPortalAuthController from './DeveloperPortalAuthController'

const Developer = {
    DeveloperPortalController: Object.assign(DeveloperPortalController, DeveloperPortalController),
    DeveloperPortalAuthController: Object.assign(DeveloperPortalAuthController, DeveloperPortalAuthController),
}

export default Developer