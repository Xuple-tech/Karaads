import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::index
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:27
* @route '/user/developer-api'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/user/developer-api',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::index
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:27
* @route '/user/developer-api'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::index
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:27
* @route '/user/developer-api'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::index
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:27
* @route '/user/developer-api'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::storeKey
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:168
* @route '/user/developer-api/keys'
*/
const storeKeydaad9f6e829402a2cd4dacb89f309de5 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeKeydaad9f6e829402a2cd4dacb89f309de5.url(options),
    method: 'post',
})

storeKeydaad9f6e829402a2cd4dacb89f309de5.definition = {
    methods: ["post"],
    url: '/user/developer-api/keys',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::storeKey
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:168
* @route '/user/developer-api/keys'
*/
storeKeydaad9f6e829402a2cd4dacb89f309de5.url = (options?: RouteQueryOptions) => {
    return storeKeydaad9f6e829402a2cd4dacb89f309de5.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::storeKey
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:168
* @route '/user/developer-api/keys'
*/
storeKeydaad9f6e829402a2cd4dacb89f309de5.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeKeydaad9f6e829402a2cd4dacb89f309de5.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::storeKey
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:168
* @route '/developer-api/keys'
*/
const storeKey2292616dfc6a27cab1ca3c1e266c14e8 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeKey2292616dfc6a27cab1ca3c1e266c14e8.url(options),
    method: 'post',
})

storeKey2292616dfc6a27cab1ca3c1e266c14e8.definition = {
    methods: ["post"],
    url: '/developer-api/keys',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::storeKey
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:168
* @route '/developer-api/keys'
*/
storeKey2292616dfc6a27cab1ca3c1e266c14e8.url = (options?: RouteQueryOptions) => {
    return storeKey2292616dfc6a27cab1ca3c1e266c14e8.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::storeKey
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:168
* @route '/developer-api/keys'
*/
storeKey2292616dfc6a27cab1ca3c1e266c14e8.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeKey2292616dfc6a27cab1ca3c1e266c14e8.url(options),
    method: 'post',
})

export const storeKey = {
    '/user/developer-api/keys': storeKeydaad9f6e829402a2cd4dacb89f309de5,
    '/developer-api/keys': storeKey2292616dfc6a27cab1ca3c1e266c14e8,
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::updateKey
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:191
* @route '/user/developer-api/keys/{developerApiKey}'
*/
const updateKey0b0d72b61b38744dac255a51c54092b8 = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateKey0b0d72b61b38744dac255a51c54092b8.url(args, options),
    method: 'put',
})

updateKey0b0d72b61b38744dac255a51c54092b8.definition = {
    methods: ["put"],
    url: '/user/developer-api/keys/{developerApiKey}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::updateKey
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:191
* @route '/user/developer-api/keys/{developerApiKey}'
*/
updateKey0b0d72b61b38744dac255a51c54092b8.url = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { developerApiKey: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { developerApiKey: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            developerApiKey: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        developerApiKey: typeof args.developerApiKey === 'object'
        ? args.developerApiKey.id
        : args.developerApiKey,
    }

    return updateKey0b0d72b61b38744dac255a51c54092b8.definition.url
            .replace('{developerApiKey}', parsedArgs.developerApiKey.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::updateKey
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:191
* @route '/user/developer-api/keys/{developerApiKey}'
*/
updateKey0b0d72b61b38744dac255a51c54092b8.put = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateKey0b0d72b61b38744dac255a51c54092b8.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::updateKey
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:191
* @route '/developer-api/keys/{developerApiKey}'
*/
const updateKey9253c5322921b293f5a62251a12a884e = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateKey9253c5322921b293f5a62251a12a884e.url(args, options),
    method: 'put',
})

updateKey9253c5322921b293f5a62251a12a884e.definition = {
    methods: ["put"],
    url: '/developer-api/keys/{developerApiKey}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::updateKey
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:191
* @route '/developer-api/keys/{developerApiKey}'
*/
updateKey9253c5322921b293f5a62251a12a884e.url = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { developerApiKey: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { developerApiKey: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            developerApiKey: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        developerApiKey: typeof args.developerApiKey === 'object'
        ? args.developerApiKey.id
        : args.developerApiKey,
    }

    return updateKey9253c5322921b293f5a62251a12a884e.definition.url
            .replace('{developerApiKey}', parsedArgs.developerApiKey.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::updateKey
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:191
* @route '/developer-api/keys/{developerApiKey}'
*/
updateKey9253c5322921b293f5a62251a12a884e.put = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateKey9253c5322921b293f5a62251a12a884e.url(args, options),
    method: 'put',
})

export const updateKey = {
    '/user/developer-api/keys/{developerApiKey}': updateKey0b0d72b61b38744dac255a51c54092b8,
    '/developer-api/keys/{developerApiKey}': updateKey9253c5322921b293f5a62251a12a884e,
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::revokeKey
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:214
* @route '/user/developer-api/keys/{developerApiKey}/revoke'
*/
const revokeKeyb1fe47e0b302a3dfb1582ac7302e8524 = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: revokeKeyb1fe47e0b302a3dfb1582ac7302e8524.url(args, options),
    method: 'post',
})

revokeKeyb1fe47e0b302a3dfb1582ac7302e8524.definition = {
    methods: ["post"],
    url: '/user/developer-api/keys/{developerApiKey}/revoke',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::revokeKey
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:214
* @route '/user/developer-api/keys/{developerApiKey}/revoke'
*/
revokeKeyb1fe47e0b302a3dfb1582ac7302e8524.url = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { developerApiKey: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { developerApiKey: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            developerApiKey: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        developerApiKey: typeof args.developerApiKey === 'object'
        ? args.developerApiKey.id
        : args.developerApiKey,
    }

    return revokeKeyb1fe47e0b302a3dfb1582ac7302e8524.definition.url
            .replace('{developerApiKey}', parsedArgs.developerApiKey.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::revokeKey
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:214
* @route '/user/developer-api/keys/{developerApiKey}/revoke'
*/
revokeKeyb1fe47e0b302a3dfb1582ac7302e8524.post = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: revokeKeyb1fe47e0b302a3dfb1582ac7302e8524.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::revokeKey
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:214
* @route '/developer-api/keys/{developerApiKey}/revoke'
*/
const revokeKey9ff95588d615608789c93e20ae402fc6 = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: revokeKey9ff95588d615608789c93e20ae402fc6.url(args, options),
    method: 'post',
})

revokeKey9ff95588d615608789c93e20ae402fc6.definition = {
    methods: ["post"],
    url: '/developer-api/keys/{developerApiKey}/revoke',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::revokeKey
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:214
* @route '/developer-api/keys/{developerApiKey}/revoke'
*/
revokeKey9ff95588d615608789c93e20ae402fc6.url = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { developerApiKey: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { developerApiKey: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            developerApiKey: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        developerApiKey: typeof args.developerApiKey === 'object'
        ? args.developerApiKey.id
        : args.developerApiKey,
    }

    return revokeKey9ff95588d615608789c93e20ae402fc6.definition.url
            .replace('{developerApiKey}', parsedArgs.developerApiKey.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::revokeKey
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:214
* @route '/developer-api/keys/{developerApiKey}/revoke'
*/
revokeKey9ff95588d615608789c93e20ae402fc6.post = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: revokeKey9ff95588d615608789c93e20ae402fc6.url(args, options),
    method: 'post',
})

export const revokeKey = {
    '/user/developer-api/keys/{developerApiKey}/revoke': revokeKeyb1fe47e0b302a3dfb1582ac7302e8524,
    '/developer-api/keys/{developerApiKey}/revoke': revokeKey9ff95588d615608789c93e20ae402fc6,
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::regenerateKey
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:223
* @route '/user/developer-api/keys/{developerApiKey}/regenerate'
*/
const regenerateKeyf9b65f739ae2d4b5c36e4641587f57ca = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerateKeyf9b65f739ae2d4b5c36e4641587f57ca.url(args, options),
    method: 'post',
})

regenerateKeyf9b65f739ae2d4b5c36e4641587f57ca.definition = {
    methods: ["post"],
    url: '/user/developer-api/keys/{developerApiKey}/regenerate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::regenerateKey
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:223
* @route '/user/developer-api/keys/{developerApiKey}/regenerate'
*/
regenerateKeyf9b65f739ae2d4b5c36e4641587f57ca.url = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { developerApiKey: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { developerApiKey: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            developerApiKey: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        developerApiKey: typeof args.developerApiKey === 'object'
        ? args.developerApiKey.id
        : args.developerApiKey,
    }

    return regenerateKeyf9b65f739ae2d4b5c36e4641587f57ca.definition.url
            .replace('{developerApiKey}', parsedArgs.developerApiKey.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::regenerateKey
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:223
* @route '/user/developer-api/keys/{developerApiKey}/regenerate'
*/
regenerateKeyf9b65f739ae2d4b5c36e4641587f57ca.post = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerateKeyf9b65f739ae2d4b5c36e4641587f57ca.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::regenerateKey
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:223
* @route '/developer-api/keys/{developerApiKey}/regenerate'
*/
const regenerateKeyc73e314c71def61462708a62cf2c767d = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerateKeyc73e314c71def61462708a62cf2c767d.url(args, options),
    method: 'post',
})

regenerateKeyc73e314c71def61462708a62cf2c767d.definition = {
    methods: ["post"],
    url: '/developer-api/keys/{developerApiKey}/regenerate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::regenerateKey
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:223
* @route '/developer-api/keys/{developerApiKey}/regenerate'
*/
regenerateKeyc73e314c71def61462708a62cf2c767d.url = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { developerApiKey: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { developerApiKey: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            developerApiKey: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        developerApiKey: typeof args.developerApiKey === 'object'
        ? args.developerApiKey.id
        : args.developerApiKey,
    }

    return regenerateKeyc73e314c71def61462708a62cf2c767d.definition.url
            .replace('{developerApiKey}', parsedArgs.developerApiKey.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::regenerateKey
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:223
* @route '/developer-api/keys/{developerApiKey}/regenerate'
*/
regenerateKeyc73e314c71def61462708a62cf2c767d.post = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerateKeyc73e314c71def61462708a62cf2c767d.url(args, options),
    method: 'post',
})

export const regenerateKey = {
    '/user/developer-api/keys/{developerApiKey}/regenerate': regenerateKeyf9b65f739ae2d4b5c36e4641587f57ca,
    '/developer-api/keys/{developerApiKey}/regenerate': regenerateKeyc73e314c71def61462708a62cf2c767d,
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::createTopupCheckout
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:234
* @route '/user/developer-api/top-up'
*/
const createTopupCheckout72027e2be322ef852852b6e783ddf6e7 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: createTopupCheckout72027e2be322ef852852b6e783ddf6e7.url(options),
    method: 'post',
})

createTopupCheckout72027e2be322ef852852b6e783ddf6e7.definition = {
    methods: ["post"],
    url: '/user/developer-api/top-up',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::createTopupCheckout
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:234
* @route '/user/developer-api/top-up'
*/
createTopupCheckout72027e2be322ef852852b6e783ddf6e7.url = (options?: RouteQueryOptions) => {
    return createTopupCheckout72027e2be322ef852852b6e783ddf6e7.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::createTopupCheckout
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:234
* @route '/user/developer-api/top-up'
*/
createTopupCheckout72027e2be322ef852852b6e783ddf6e7.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: createTopupCheckout72027e2be322ef852852b6e783ddf6e7.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::createTopupCheckout
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:234
* @route '/developer-api/top-up'
*/
const createTopupCheckout633d2b14dd949f438e15647ec7d062f0 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: createTopupCheckout633d2b14dd949f438e15647ec7d062f0.url(options),
    method: 'post',
})

createTopupCheckout633d2b14dd949f438e15647ec7d062f0.definition = {
    methods: ["post"],
    url: '/developer-api/top-up',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::createTopupCheckout
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:234
* @route '/developer-api/top-up'
*/
createTopupCheckout633d2b14dd949f438e15647ec7d062f0.url = (options?: RouteQueryOptions) => {
    return createTopupCheckout633d2b14dd949f438e15647ec7d062f0.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::createTopupCheckout
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:234
* @route '/developer-api/top-up'
*/
createTopupCheckout633d2b14dd949f438e15647ec7d062f0.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: createTopupCheckout633d2b14dd949f438e15647ec7d062f0.url(options),
    method: 'post',
})

export const createTopupCheckout = {
    '/user/developer-api/top-up': createTopupCheckout72027e2be322ef852852b6e783ddf6e7,
    '/developer-api/top-up': createTopupCheckout633d2b14dd949f438e15647ec7d062f0,
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::dashboard
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:32
* @route '/developer-api'
*/
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/developer-api',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::dashboard
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:32
* @route '/developer-api'
*/
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::dashboard
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:32
* @route '/developer-api'
*/
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::dashboard
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:32
* @route '/developer-api'
*/
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::keys
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:48
* @route '/developer-api/keys'
*/
export const keys = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: keys.url(options),
    method: 'get',
})

keys.definition = {
    methods: ["get","head"],
    url: '/developer-api/keys',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::keys
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:48
* @route '/developer-api/keys'
*/
keys.url = (options?: RouteQueryOptions) => {
    return keys.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::keys
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:48
* @route '/developer-api/keys'
*/
keys.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: keys.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::keys
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:48
* @route '/developer-api/keys'
*/
keys.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: keys.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::usage
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:82
* @route '/developer-api/usage'
*/
export const usage = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: usage.url(options),
    method: 'get',
})

usage.definition = {
    methods: ["get","head"],
    url: '/developer-api/usage',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::usage
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:82
* @route '/developer-api/usage'
*/
usage.url = (options?: RouteQueryOptions) => {
    return usage.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::usage
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:82
* @route '/developer-api/usage'
*/
usage.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: usage.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::usage
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:82
* @route '/developer-api/usage'
*/
usage.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: usage.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::billing
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:118
* @route '/developer-api/billing'
*/
export const billing = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: billing.url(options),
    method: 'get',
})

billing.definition = {
    methods: ["get","head"],
    url: '/developer-api/billing',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::billing
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:118
* @route '/developer-api/billing'
*/
billing.url = (options?: RouteQueryOptions) => {
    return billing.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::billing
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:118
* @route '/developer-api/billing'
*/
billing.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: billing.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::billing
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:118
* @route '/developer-api/billing'
*/
billing.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: billing.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::quickstart
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:148
* @route '/developer-api/quickstart'
*/
export const quickstart = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: quickstart.url(options),
    method: 'get',
})

quickstart.definition = {
    methods: ["get","head"],
    url: '/developer-api/quickstart',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::quickstart
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:148
* @route '/developer-api/quickstart'
*/
quickstart.url = (options?: RouteQueryOptions) => {
    return quickstart.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::quickstart
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:148
* @route '/developer-api/quickstart'
*/
quickstart.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: quickstart.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::quickstart
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:148
* @route '/developer-api/quickstart'
*/
quickstart.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: quickstart.url(options),
    method: 'head',
})

const DeveloperPortalController = { index, storeKey, updateKey, revokeKey, regenerateKey, createTopupCheckout, dashboard, keys, usage, billing, quickstart }

export default DeveloperPortalController