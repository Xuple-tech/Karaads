import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::showLogin
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:19
* @route '/developer-api/login'
*/
export const showLogin = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showLogin.url(options),
    method: 'get',
})

showLogin.definition = {
    methods: ["get","head"],
    url: '/developer-api/login',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::showLogin
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:19
* @route '/developer-api/login'
*/
showLogin.url = (options?: RouteQueryOptions) => {
    return showLogin.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::showLogin
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:19
* @route '/developer-api/login'
*/
showLogin.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showLogin.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::showLogin
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:19
* @route '/developer-api/login'
*/
showLogin.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showLogin.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::login
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:30
* @route '/developer-api/login'
*/
export const login = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

login.definition = {
    methods: ["post"],
    url: '/developer-api/login',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::login
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:30
* @route '/developer-api/login'
*/
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::login
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:30
* @route '/developer-api/login'
*/
login.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::showRegister
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:59
* @route '/developer-api/register'
*/
export const showRegister = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showRegister.url(options),
    method: 'get',
})

showRegister.definition = {
    methods: ["get","head"],
    url: '/developer-api/register',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::showRegister
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:59
* @route '/developer-api/register'
*/
showRegister.url = (options?: RouteQueryOptions) => {
    return showRegister.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::showRegister
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:59
* @route '/developer-api/register'
*/
showRegister.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showRegister.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::showRegister
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:59
* @route '/developer-api/register'
*/
showRegister.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showRegister.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::register
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:68
* @route '/developer-api/register'
*/
export const register = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

register.definition = {
    methods: ["post"],
    url: '/developer-api/register',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::register
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:68
* @route '/developer-api/register'
*/
register.url = (options?: RouteQueryOptions) => {
    return register.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::register
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:68
* @route '/developer-api/register'
*/
register.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::logout
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:49
* @route '/developer-api/logout'
*/
export const logout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

logout.definition = {
    methods: ["post"],
    url: '/developer-api/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::logout
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:49
* @route '/developer-api/logout'
*/
logout.url = (options?: RouteQueryOptions) => {
    return logout.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::logout
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:49
* @route '/developer-api/logout'
*/
logout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

const DeveloperPortalAuthController = { showLogin, login, showRegister, register, logout }

export default DeveloperPortalAuthController