import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/'
*/
const SpaController980bb49ee7ae63891f1d891d2fbcf1c9 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
    method: 'get',
})

SpaController980bb49ee7ae63891f1d891d2fbcf1c9.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/'
*/
SpaController980bb49ee7ae63891f1d891d2fbcf1c9.url = (options?: RouteQueryOptions) => {
    return SpaController980bb49ee7ae63891f1d891d2fbcf1c9.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/'
*/
SpaController980bb49ee7ae63891f1d891d2fbcf1c9.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/'
*/
SpaController980bb49ee7ae63891f1d891d2fbcf1c9.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaController980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/app'
*/
const SpaController66c7f35ef69d84111bb599576cd05b30 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController66c7f35ef69d84111bb599576cd05b30.url(options),
    method: 'get',
})

SpaController66c7f35ef69d84111bb599576cd05b30.definition = {
    methods: ["get","head"],
    url: '/app',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/app'
*/
SpaController66c7f35ef69d84111bb599576cd05b30.url = (options?: RouteQueryOptions) => {
    return SpaController66c7f35ef69d84111bb599576cd05b30.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/app'
*/
SpaController66c7f35ef69d84111bb599576cd05b30.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController66c7f35ef69d84111bb599576cd05b30.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/app'
*/
SpaController66c7f35ef69d84111bb599576cd05b30.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaController66c7f35ef69d84111bb599576cd05b30.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/new'
*/
const SpaController7a022a9b96cb47bd7a175c7742311b98 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController7a022a9b96cb47bd7a175c7742311b98.url(options),
    method: 'get',
})

SpaController7a022a9b96cb47bd7a175c7742311b98.definition = {
    methods: ["get","head"],
    url: '/new',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/new'
*/
SpaController7a022a9b96cb47bd7a175c7742311b98.url = (options?: RouteQueryOptions) => {
    return SpaController7a022a9b96cb47bd7a175c7742311b98.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/new'
*/
SpaController7a022a9b96cb47bd7a175c7742311b98.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController7a022a9b96cb47bd7a175c7742311b98.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/new'
*/
SpaController7a022a9b96cb47bd7a175c7742311b98.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaController7a022a9b96cb47bd7a175c7742311b98.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/privacy-policy'
*/
const SpaController546d1d979582dcab4cda77f98be026ca = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController546d1d979582dcab4cda77f98be026ca.url(options),
    method: 'get',
})

SpaController546d1d979582dcab4cda77f98be026ca.definition = {
    methods: ["get","head"],
    url: '/privacy-policy',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/privacy-policy'
*/
SpaController546d1d979582dcab4cda77f98be026ca.url = (options?: RouteQueryOptions) => {
    return SpaController546d1d979582dcab4cda77f98be026ca.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/privacy-policy'
*/
SpaController546d1d979582dcab4cda77f98be026ca.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController546d1d979582dcab4cda77f98be026ca.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/privacy-policy'
*/
SpaController546d1d979582dcab4cda77f98be026ca.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaController546d1d979582dcab4cda77f98be026ca.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/dashboard'
*/
const SpaController42a740574ecbfbac32f8cc353fc32db9 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController42a740574ecbfbac32f8cc353fc32db9.url(options),
    method: 'get',
})

SpaController42a740574ecbfbac32f8cc353fc32db9.definition = {
    methods: ["get","head"],
    url: '/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/dashboard'
*/
SpaController42a740574ecbfbac32f8cc353fc32db9.url = (options?: RouteQueryOptions) => {
    return SpaController42a740574ecbfbac32f8cc353fc32db9.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/dashboard'
*/
SpaController42a740574ecbfbac32f8cc353fc32db9.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController42a740574ecbfbac32f8cc353fc32db9.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/dashboard'
*/
SpaController42a740574ecbfbac32f8cc353fc32db9.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaController42a740574ecbfbac32f8cc353fc32db9.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/c/new'
*/
const SpaControllerc7bc79bc93669ce210dffd0b836367d8 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaControllerc7bc79bc93669ce210dffd0b836367d8.url(options),
    method: 'get',
})

SpaControllerc7bc79bc93669ce210dffd0b836367d8.definition = {
    methods: ["get","head"],
    url: '/c/new',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/c/new'
*/
SpaControllerc7bc79bc93669ce210dffd0b836367d8.url = (options?: RouteQueryOptions) => {
    return SpaControllerc7bc79bc93669ce210dffd0b836367d8.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/c/new'
*/
SpaControllerc7bc79bc93669ce210dffd0b836367d8.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaControllerc7bc79bc93669ce210dffd0b836367d8.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/c/new'
*/
SpaControllerc7bc79bc93669ce210dffd0b836367d8.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaControllerc7bc79bc93669ce210dffd0b836367d8.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/c/{conversation}'
*/
const SpaController0f437dccbc073956324ffb891aad75f6 = (args: { conversation: string | number } | [conversation: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController0f437dccbc073956324ffb891aad75f6.url(args, options),
    method: 'get',
})

SpaController0f437dccbc073956324ffb891aad75f6.definition = {
    methods: ["get","head"],
    url: '/c/{conversation}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/c/{conversation}'
*/
SpaController0f437dccbc073956324ffb891aad75f6.url = (args: { conversation: string | number } | [conversation: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { conversation: args }
    }

    if (Array.isArray(args)) {
        args = {
            conversation: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        conversation: args.conversation,
    }

    return SpaController0f437dccbc073956324ffb891aad75f6.definition.url
            .replace('{conversation}', parsedArgs.conversation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/c/{conversation}'
*/
SpaController0f437dccbc073956324ffb891aad75f6.get = (args: { conversation: string | number } | [conversation: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController0f437dccbc073956324ffb891aad75f6.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/c/{conversation}'
*/
SpaController0f437dccbc073956324ffb891aad75f6.head = (args: { conversation: string | number } | [conversation: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaController0f437dccbc073956324ffb891aad75f6.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/share/{token}'
*/
const SpaController73a4dea9223b15cc67e1b02d4937aeaa = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController73a4dea9223b15cc67e1b02d4937aeaa.url(args, options),
    method: 'get',
})

SpaController73a4dea9223b15cc67e1b02d4937aeaa.definition = {
    methods: ["get","head"],
    url: '/share/{token}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/share/{token}'
*/
SpaController73a4dea9223b15cc67e1b02d4937aeaa.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    if (Array.isArray(args)) {
        args = {
            token: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        token: args.token,
    }

    return SpaController73a4dea9223b15cc67e1b02d4937aeaa.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/share/{token}'
*/
SpaController73a4dea9223b15cc67e1b02d4937aeaa.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController73a4dea9223b15cc67e1b02d4937aeaa.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/share/{token}'
*/
SpaController73a4dea9223b15cc67e1b02d4937aeaa.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaController73a4dea9223b15cc67e1b02d4937aeaa.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/privacy'
*/
const SpaControllera2c058616aeb0c9393ca03a98bc05c02 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaControllera2c058616aeb0c9393ca03a98bc05c02.url(options),
    method: 'get',
})

SpaControllera2c058616aeb0c9393ca03a98bc05c02.definition = {
    methods: ["get","head"],
    url: '/privacy',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/privacy'
*/
SpaControllera2c058616aeb0c9393ca03a98bc05c02.url = (options?: RouteQueryOptions) => {
    return SpaControllera2c058616aeb0c9393ca03a98bc05c02.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/privacy'
*/
SpaControllera2c058616aeb0c9393ca03a98bc05c02.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaControllera2c058616aeb0c9393ca03a98bc05c02.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/privacy'
*/
SpaControllera2c058616aeb0c9393ca03a98bc05c02.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaControllera2c058616aeb0c9393ca03a98bc05c02.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/terms'
*/
const SpaController619dc3a99425f668ea9cab64e6648cb4 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController619dc3a99425f668ea9cab64e6648cb4.url(options),
    method: 'get',
})

SpaController619dc3a99425f668ea9cab64e6648cb4.definition = {
    methods: ["get","head"],
    url: '/terms',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/terms'
*/
SpaController619dc3a99425f668ea9cab64e6648cb4.url = (options?: RouteQueryOptions) => {
    return SpaController619dc3a99425f668ea9cab64e6648cb4.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/terms'
*/
SpaController619dc3a99425f668ea9cab64e6648cb4.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController619dc3a99425f668ea9cab64e6648cb4.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/terms'
*/
SpaController619dc3a99425f668ea9cab64e6648cb4.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaController619dc3a99425f668ea9cab64e6648cb4.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/terms-of-service'
*/
const SpaControllerafc93a7f43b9c83b4fdbb5592321e7c9 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaControllerafc93a7f43b9c83b4fdbb5592321e7c9.url(options),
    method: 'get',
})

SpaControllerafc93a7f43b9c83b4fdbb5592321e7c9.definition = {
    methods: ["get","head"],
    url: '/terms-of-service',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/terms-of-service'
*/
SpaControllerafc93a7f43b9c83b4fdbb5592321e7c9.url = (options?: RouteQueryOptions) => {
    return SpaControllerafc93a7f43b9c83b4fdbb5592321e7c9.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/terms-of-service'
*/
SpaControllerafc93a7f43b9c83b4fdbb5592321e7c9.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaControllerafc93a7f43b9c83b4fdbb5592321e7c9.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/terms-of-service'
*/
SpaControllerafc93a7f43b9c83b4fdbb5592321e7c9.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaControllerafc93a7f43b9c83b4fdbb5592321e7c9.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/register'
*/
const SpaControllere9819db9819a1d19b38dd89a0c4218c4 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaControllere9819db9819a1d19b38dd89a0c4218c4.url(options),
    method: 'get',
})

SpaControllere9819db9819a1d19b38dd89a0c4218c4.definition = {
    methods: ["get","head"],
    url: '/register',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/register'
*/
SpaControllere9819db9819a1d19b38dd89a0c4218c4.url = (options?: RouteQueryOptions) => {
    return SpaControllere9819db9819a1d19b38dd89a0c4218c4.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/register'
*/
SpaControllere9819db9819a1d19b38dd89a0c4218c4.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaControllere9819db9819a1d19b38dd89a0c4218c4.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/register'
*/
SpaControllere9819db9819a1d19b38dd89a0c4218c4.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaControllere9819db9819a1d19b38dd89a0c4218c4.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/login'
*/
const SpaControllerb6041c76e8e1cd791f8f89d035d48611 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaControllerb6041c76e8e1cd791f8f89d035d48611.url(options),
    method: 'get',
})

SpaControllerb6041c76e8e1cd791f8f89d035d48611.definition = {
    methods: ["get","head"],
    url: '/login',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/login'
*/
SpaControllerb6041c76e8e1cd791f8f89d035d48611.url = (options?: RouteQueryOptions) => {
    return SpaControllerb6041c76e8e1cd791f8f89d035d48611.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/login'
*/
SpaControllerb6041c76e8e1cd791f8f89d035d48611.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaControllerb6041c76e8e1cd791f8f89d035d48611.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/login'
*/
SpaControllerb6041c76e8e1cd791f8f89d035d48611.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaControllerb6041c76e8e1cd791f8f89d035d48611.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/forgot-password'
*/
const SpaController19019de5652af051dc199e877d041d33 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController19019de5652af051dc199e877d041d33.url(options),
    method: 'get',
})

SpaController19019de5652af051dc199e877d041d33.definition = {
    methods: ["get","head"],
    url: '/forgot-password',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/forgot-password'
*/
SpaController19019de5652af051dc199e877d041d33.url = (options?: RouteQueryOptions) => {
    return SpaController19019de5652af051dc199e877d041d33.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/forgot-password'
*/
SpaController19019de5652af051dc199e877d041d33.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController19019de5652af051dc199e877d041d33.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/forgot-password'
*/
SpaController19019de5652af051dc199e877d041d33.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaController19019de5652af051dc199e877d041d33.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/reset-password/{token}'
*/
const SpaController784bb30b123acd5cf553758712ebb4d6 = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController784bb30b123acd5cf553758712ebb4d6.url(args, options),
    method: 'get',
})

SpaController784bb30b123acd5cf553758712ebb4d6.definition = {
    methods: ["get","head"],
    url: '/reset-password/{token}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/reset-password/{token}'
*/
SpaController784bb30b123acd5cf553758712ebb4d6.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    if (Array.isArray(args)) {
        args = {
            token: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        token: args.token,
    }

    return SpaController784bb30b123acd5cf553758712ebb4d6.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/reset-password/{token}'
*/
SpaController784bb30b123acd5cf553758712ebb4d6.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController784bb30b123acd5cf553758712ebb4d6.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/reset-password/{token}'
*/
SpaController784bb30b123acd5cf553758712ebb4d6.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaController784bb30b123acd5cf553758712ebb4d6.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/verify-email'
*/
const SpaController8c3ba70f7c164aec5ec59d449e581883 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController8c3ba70f7c164aec5ec59d449e581883.url(options),
    method: 'get',
})

SpaController8c3ba70f7c164aec5ec59d449e581883.definition = {
    methods: ["get","head"],
    url: '/verify-email',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/verify-email'
*/
SpaController8c3ba70f7c164aec5ec59d449e581883.url = (options?: RouteQueryOptions) => {
    return SpaController8c3ba70f7c164aec5ec59d449e581883.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/verify-email'
*/
SpaController8c3ba70f7c164aec5ec59d449e581883.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController8c3ba70f7c164aec5ec59d449e581883.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/verify-email'
*/
SpaController8c3ba70f7c164aec5ec59d449e581883.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaController8c3ba70f7c164aec5ec59d449e581883.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/confirm-password'
*/
const SpaController80954449d08918a64e010cb0312cc579 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController80954449d08918a64e010cb0312cc579.url(options),
    method: 'get',
})

SpaController80954449d08918a64e010cb0312cc579.definition = {
    methods: ["get","head"],
    url: '/confirm-password',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/confirm-password'
*/
SpaController80954449d08918a64e010cb0312cc579.url = (options?: RouteQueryOptions) => {
    return SpaController80954449d08918a64e010cb0312cc579.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/confirm-password'
*/
SpaController80954449d08918a64e010cb0312cc579.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController80954449d08918a64e010cb0312cc579.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/confirm-password'
*/
SpaController80954449d08918a64e010cb0312cc579.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaController80954449d08918a64e010cb0312cc579.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/settings/profile'
*/
const SpaControllerfc6874003af373efc88e5e18eecd9c17 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaControllerfc6874003af373efc88e5e18eecd9c17.url(options),
    method: 'get',
})

SpaControllerfc6874003af373efc88e5e18eecd9c17.definition = {
    methods: ["get","head"],
    url: '/settings/profile',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/settings/profile'
*/
SpaControllerfc6874003af373efc88e5e18eecd9c17.url = (options?: RouteQueryOptions) => {
    return SpaControllerfc6874003af373efc88e5e18eecd9c17.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/settings/profile'
*/
SpaControllerfc6874003af373efc88e5e18eecd9c17.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaControllerfc6874003af373efc88e5e18eecd9c17.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/settings/profile'
*/
SpaControllerfc6874003af373efc88e5e18eecd9c17.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaControllerfc6874003af373efc88e5e18eecd9c17.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/settings/password'
*/
const SpaController3d83238d90f1e3969ebe570175cfec66 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController3d83238d90f1e3969ebe570175cfec66.url(options),
    method: 'get',
})

SpaController3d83238d90f1e3969ebe570175cfec66.definition = {
    methods: ["get","head"],
    url: '/settings/password',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/settings/password'
*/
SpaController3d83238d90f1e3969ebe570175cfec66.url = (options?: RouteQueryOptions) => {
    return SpaController3d83238d90f1e3969ebe570175cfec66.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/settings/password'
*/
SpaController3d83238d90f1e3969ebe570175cfec66.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController3d83238d90f1e3969ebe570175cfec66.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/settings/password'
*/
SpaController3d83238d90f1e3969ebe570175cfec66.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaController3d83238d90f1e3969ebe570175cfec66.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/settings/appearance'
*/
const SpaControllere19ee86e9cf603ce1a59a1ec5d21dec5 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaControllere19ee86e9cf603ce1a59a1ec5d21dec5.url(options),
    method: 'get',
})

SpaControllere19ee86e9cf603ce1a59a1ec5d21dec5.definition = {
    methods: ["get","head"],
    url: '/settings/appearance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/settings/appearance'
*/
SpaControllere19ee86e9cf603ce1a59a1ec5d21dec5.url = (options?: RouteQueryOptions) => {
    return SpaControllere19ee86e9cf603ce1a59a1ec5d21dec5.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/settings/appearance'
*/
SpaControllere19ee86e9cf603ce1a59a1ec5d21dec5.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaControllere19ee86e9cf603ce1a59a1ec5d21dec5.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/settings/appearance'
*/
SpaControllere19ee86e9cf603ce1a59a1ec5d21dec5.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaControllere19ee86e9cf603ce1a59a1ec5d21dec5.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/settings/personalization'
*/
const SpaController2e12dd19d201a852d7c4ce0b5c03fe52 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController2e12dd19d201a852d7c4ce0b5c03fe52.url(options),
    method: 'get',
})

SpaController2e12dd19d201a852d7c4ce0b5c03fe52.definition = {
    methods: ["get","head"],
    url: '/settings/personalization',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/settings/personalization'
*/
SpaController2e12dd19d201a852d7c4ce0b5c03fe52.url = (options?: RouteQueryOptions) => {
    return SpaController2e12dd19d201a852d7c4ce0b5c03fe52.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/settings/personalization'
*/
SpaController2e12dd19d201a852d7c4ce0b5c03fe52.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController2e12dd19d201a852d7c4ce0b5c03fe52.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/settings/personalization'
*/
SpaController2e12dd19d201a852d7c4ce0b5c03fe52.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaController2e12dd19d201a852d7c4ce0b5c03fe52.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/subscription/pricing'
*/
const SpaController236c33d8cfcce6f1d3853952aa4dca21 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController236c33d8cfcce6f1d3853952aa4dca21.url(options),
    method: 'get',
})

SpaController236c33d8cfcce6f1d3853952aa4dca21.definition = {
    methods: ["get","head"],
    url: '/subscription/pricing',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/subscription/pricing'
*/
SpaController236c33d8cfcce6f1d3853952aa4dca21.url = (options?: RouteQueryOptions) => {
    return SpaController236c33d8cfcce6f1d3853952aa4dca21.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/subscription/pricing'
*/
SpaController236c33d8cfcce6f1d3853952aa4dca21.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController236c33d8cfcce6f1d3853952aa4dca21.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/subscription/pricing'
*/
SpaController236c33d8cfcce6f1d3853952aa4dca21.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaController236c33d8cfcce6f1d3853952aa4dca21.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/pricing'
*/
const SpaControllera6735397690d30570f358ff62fa3ef24 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaControllera6735397690d30570f358ff62fa3ef24.url(options),
    method: 'get',
})

SpaControllera6735397690d30570f358ff62fa3ef24.definition = {
    methods: ["get","head"],
    url: '/pricing',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/pricing'
*/
SpaControllera6735397690d30570f358ff62fa3ef24.url = (options?: RouteQueryOptions) => {
    return SpaControllera6735397690d30570f358ff62fa3ef24.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/pricing'
*/
SpaControllera6735397690d30570f358ff62fa3ef24.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaControllera6735397690d30570f358ff62fa3ef24.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/pricing'
*/
SpaControllera6735397690d30570f358ff62fa3ef24.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaControllera6735397690d30570f358ff62fa3ef24.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/subscription'
*/
const SpaController97132ad62091eb4b4dcbd9d3c3740471 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController97132ad62091eb4b4dcbd9d3c3740471.url(options),
    method: 'get',
})

SpaController97132ad62091eb4b4dcbd9d3c3740471.definition = {
    methods: ["get","head"],
    url: '/subscription',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/subscription'
*/
SpaController97132ad62091eb4b4dcbd9d3c3740471.url = (options?: RouteQueryOptions) => {
    return SpaController97132ad62091eb4b4dcbd9d3c3740471.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/subscription'
*/
SpaController97132ad62091eb4b4dcbd9d3c3740471.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController97132ad62091eb4b4dcbd9d3c3740471.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/subscription'
*/
SpaController97132ad62091eb4b4dcbd9d3c3740471.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaController97132ad62091eb4b4dcbd9d3c3740471.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/billing'
*/
const SpaControllerdae46b3ec56d4448dc39f0145d07613b = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaControllerdae46b3ec56d4448dc39f0145d07613b.url(options),
    method: 'get',
})

SpaControllerdae46b3ec56d4448dc39f0145d07613b.definition = {
    methods: ["get","head"],
    url: '/billing',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/billing'
*/
SpaControllerdae46b3ec56d4448dc39f0145d07613b.url = (options?: RouteQueryOptions) => {
    return SpaControllerdae46b3ec56d4448dc39f0145d07613b.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/billing'
*/
SpaControllerdae46b3ec56d4448dc39f0145d07613b.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaControllerdae46b3ec56d4448dc39f0145d07613b.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/billing'
*/
SpaControllerdae46b3ec56d4448dc39f0145d07613b.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaControllerdae46b3ec56d4448dc39f0145d07613b.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/voice-chat'
*/
const SpaController6929aa802098fd278ee5108ccfd17d06 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController6929aa802098fd278ee5108ccfd17d06.url(options),
    method: 'get',
})

SpaController6929aa802098fd278ee5108ccfd17d06.definition = {
    methods: ["get","head"],
    url: '/voice-chat',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/voice-chat'
*/
SpaController6929aa802098fd278ee5108ccfd17d06.url = (options?: RouteQueryOptions) => {
    return SpaController6929aa802098fd278ee5108ccfd17d06.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/voice-chat'
*/
SpaController6929aa802098fd278ee5108ccfd17d06.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController6929aa802098fd278ee5108ccfd17d06.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/voice-chat'
*/
SpaController6929aa802098fd278ee5108ccfd17d06.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaController6929aa802098fd278ee5108ccfd17d06.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/c/{conversation}/voice'
*/
const SpaController5e4538e721ee6fc8ae4d4a2cbc900dda = (args: { conversation: string | number } | [conversation: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController5e4538e721ee6fc8ae4d4a2cbc900dda.url(args, options),
    method: 'get',
})

SpaController5e4538e721ee6fc8ae4d4a2cbc900dda.definition = {
    methods: ["get","head"],
    url: '/c/{conversation}/voice',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/c/{conversation}/voice'
*/
SpaController5e4538e721ee6fc8ae4d4a2cbc900dda.url = (args: { conversation: string | number } | [conversation: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { conversation: args }
    }

    if (Array.isArray(args)) {
        args = {
            conversation: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        conversation: args.conversation,
    }

    return SpaController5e4538e721ee6fc8ae4d4a2cbc900dda.definition.url
            .replace('{conversation}', parsedArgs.conversation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/c/{conversation}/voice'
*/
SpaController5e4538e721ee6fc8ae4d4a2cbc900dda.get = (args: { conversation: string | number } | [conversation: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController5e4538e721ee6fc8ae4d4a2cbc900dda.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/c/{conversation}/voice'
*/
SpaController5e4538e721ee6fc8ae4d4a2cbc900dda.head = (args: { conversation: string | number } | [conversation: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaController5e4538e721ee6fc8ae4d4a2cbc900dda.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/user/conversations'
*/
const SpaController1153b490015c7f4e35244f1c48c27f9f = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController1153b490015c7f4e35244f1c48c27f9f.url(options),
    method: 'get',
})

SpaController1153b490015c7f4e35244f1c48c27f9f.definition = {
    methods: ["get","head"],
    url: '/user/conversations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/user/conversations'
*/
SpaController1153b490015c7f4e35244f1c48c27f9f.url = (options?: RouteQueryOptions) => {
    return SpaController1153b490015c7f4e35244f1c48c27f9f.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/user/conversations'
*/
SpaController1153b490015c7f4e35244f1c48c27f9f.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController1153b490015c7f4e35244f1c48c27f9f.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/user/conversations'
*/
SpaController1153b490015c7f4e35244f1c48c27f9f.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaController1153b490015c7f4e35244f1c48c27f9f.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/user/settings'
*/
const SpaController52d77e08d9255949ca9ceaffa6e82348 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController52d77e08d9255949ca9ceaffa6e82348.url(options),
    method: 'get',
})

SpaController52d77e08d9255949ca9ceaffa6e82348.definition = {
    methods: ["get","head"],
    url: '/user/settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/user/settings'
*/
SpaController52d77e08d9255949ca9ceaffa6e82348.url = (options?: RouteQueryOptions) => {
    return SpaController52d77e08d9255949ca9ceaffa6e82348.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/user/settings'
*/
SpaController52d77e08d9255949ca9ceaffa6e82348.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController52d77e08d9255949ca9ceaffa6e82348.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/user/settings'
*/
SpaController52d77e08d9255949ca9ceaffa6e82348.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaController52d77e08d9255949ca9ceaffa6e82348.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/user/help'
*/
const SpaController43b61b53b36f60284f0c312e5eabc846 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController43b61b53b36f60284f0c312e5eabc846.url(options),
    method: 'get',
})

SpaController43b61b53b36f60284f0c312e5eabc846.definition = {
    methods: ["get","head"],
    url: '/user/help',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/user/help'
*/
SpaController43b61b53b36f60284f0c312e5eabc846.url = (options?: RouteQueryOptions) => {
    return SpaController43b61b53b36f60284f0c312e5eabc846.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/user/help'
*/
SpaController43b61b53b36f60284f0c312e5eabc846.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController43b61b53b36f60284f0c312e5eabc846.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/user/help'
*/
SpaController43b61b53b36f60284f0c312e5eabc846.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaController43b61b53b36f60284f0c312e5eabc846.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/user/subscription'
*/
const SpaController266c0f918a9352bf71ff998fc72e49b4 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController266c0f918a9352bf71ff998fc72e49b4.url(options),
    method: 'get',
})

SpaController266c0f918a9352bf71ff998fc72e49b4.definition = {
    methods: ["get","head"],
    url: '/user/subscription',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/user/subscription'
*/
SpaController266c0f918a9352bf71ff998fc72e49b4.url = (options?: RouteQueryOptions) => {
    return SpaController266c0f918a9352bf71ff998fc72e49b4.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/user/subscription'
*/
SpaController266c0f918a9352bf71ff998fc72e49b4.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController266c0f918a9352bf71ff998fc72e49b4.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/user/subscription'
*/
SpaController266c0f918a9352bf71ff998fc72e49b4.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaController266c0f918a9352bf71ff998fc72e49b4.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/studio'
*/
const SpaController7081ef06e513d223c848904f90d5f37c = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController7081ef06e513d223c848904f90d5f37c.url(options),
    method: 'get',
})

SpaController7081ef06e513d223c848904f90d5f37c.definition = {
    methods: ["get","head"],
    url: '/studio',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/studio'
*/
SpaController7081ef06e513d223c848904f90d5f37c.url = (options?: RouteQueryOptions) => {
    return SpaController7081ef06e513d223c848904f90d5f37c.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/studio'
*/
SpaController7081ef06e513d223c848904f90d5f37c.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController7081ef06e513d223c848904f90d5f37c.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/studio'
*/
SpaController7081ef06e513d223c848904f90d5f37c.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaController7081ef06e513d223c848904f90d5f37c.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/studio/podcast-master'
*/
const SpaController0d1da230fe7367eb2f734fcb70fc299d = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController0d1da230fe7367eb2f734fcb70fc299d.url(options),
    method: 'get',
})

SpaController0d1da230fe7367eb2f734fcb70fc299d.definition = {
    methods: ["get","head"],
    url: '/studio/podcast-master',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/studio/podcast-master'
*/
SpaController0d1da230fe7367eb2f734fcb70fc299d.url = (options?: RouteQueryOptions) => {
    return SpaController0d1da230fe7367eb2f734fcb70fc299d.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/studio/podcast-master'
*/
SpaController0d1da230fe7367eb2f734fcb70fc299d.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController0d1da230fe7367eb2f734fcb70fc299d.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/studio/podcast-master'
*/
SpaController0d1da230fe7367eb2f734fcb70fc299d.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaController0d1da230fe7367eb2f734fcb70fc299d.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/podcast/generate'
*/
const SpaController209be3f184d0254bc15800576d0a53e8 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController209be3f184d0254bc15800576d0a53e8.url(options),
    method: 'get',
})

SpaController209be3f184d0254bc15800576d0a53e8.definition = {
    methods: ["get","head"],
    url: '/podcast/generate',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/podcast/generate'
*/
SpaController209be3f184d0254bc15800576d0a53e8.url = (options?: RouteQueryOptions) => {
    return SpaController209be3f184d0254bc15800576d0a53e8.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/podcast/generate'
*/
SpaController209be3f184d0254bc15800576d0a53e8.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaController209be3f184d0254bc15800576d0a53e8.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/podcast/generate'
*/
SpaController209be3f184d0254bc15800576d0a53e8.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaController209be3f184d0254bc15800576d0a53e8.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/{path}'
*/
const SpaControllere82770d06df9f3de57e12c6f4a3eb557 = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaControllere82770d06df9f3de57e12c6f4a3eb557.url(args, options),
    method: 'get',
})

SpaControllere82770d06df9f3de57e12c6f4a3eb557.definition = {
    methods: ["get","head"],
    url: '/{path}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/{path}'
*/
SpaControllere82770d06df9f3de57e12c6f4a3eb557.url = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { path: args }
    }

    if (Array.isArray(args)) {
        args = {
            path: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        path: args.path,
    }

    return SpaControllere82770d06df9f3de57e12c6f4a3eb557.definition.url
            .replace('{path}', parsedArgs.path.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/{path}'
*/
SpaControllere82770d06df9f3de57e12c6f4a3eb557.get = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SpaControllere82770d06df9f3de57e12c6f4a3eb557.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/{path}'
*/
SpaControllere82770d06df9f3de57e12c6f4a3eb557.head = (args: { path: string | number } | [path: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SpaControllere82770d06df9f3de57e12c6f4a3eb557.url(args, options),
    method: 'head',
})

const SpaController = {
    '/': SpaController980bb49ee7ae63891f1d891d2fbcf1c9,
    '/app': SpaController66c7f35ef69d84111bb599576cd05b30,
    '/new': SpaController7a022a9b96cb47bd7a175c7742311b98,
    '/privacy-policy': SpaController546d1d979582dcab4cda77f98be026ca,
    '/dashboard': SpaController42a740574ecbfbac32f8cc353fc32db9,
    '/c/new': SpaControllerc7bc79bc93669ce210dffd0b836367d8,
    '/c/{conversation}': SpaController0f437dccbc073956324ffb891aad75f6,
    '/share/{token}': SpaController73a4dea9223b15cc67e1b02d4937aeaa,
    '/privacy': SpaControllera2c058616aeb0c9393ca03a98bc05c02,
    '/terms': SpaController619dc3a99425f668ea9cab64e6648cb4,
    '/terms-of-service': SpaControllerafc93a7f43b9c83b4fdbb5592321e7c9,
    '/register': SpaControllere9819db9819a1d19b38dd89a0c4218c4,
    '/login': SpaControllerb6041c76e8e1cd791f8f89d035d48611,
    '/forgot-password': SpaController19019de5652af051dc199e877d041d33,
    '/reset-password/{token}': SpaController784bb30b123acd5cf553758712ebb4d6,
    '/verify-email': SpaController8c3ba70f7c164aec5ec59d449e581883,
    '/confirm-password': SpaController80954449d08918a64e010cb0312cc579,
    '/settings/profile': SpaControllerfc6874003af373efc88e5e18eecd9c17,
    '/settings/password': SpaController3d83238d90f1e3969ebe570175cfec66,
    '/settings/appearance': SpaControllere19ee86e9cf603ce1a59a1ec5d21dec5,
    '/settings/personalization': SpaController2e12dd19d201a852d7c4ce0b5c03fe52,
    '/subscription/pricing': SpaController236c33d8cfcce6f1d3853952aa4dca21,
    '/pricing': SpaControllera6735397690d30570f358ff62fa3ef24,
    '/subscription': SpaController97132ad62091eb4b4dcbd9d3c3740471,
    '/billing': SpaControllerdae46b3ec56d4448dc39f0145d07613b,
    '/voice-chat': SpaController6929aa802098fd278ee5108ccfd17d06,
    '/c/{conversation}/voice': SpaController5e4538e721ee6fc8ae4d4a2cbc900dda,
    '/user/conversations': SpaController1153b490015c7f4e35244f1c48c27f9f,
    '/user/settings': SpaController52d77e08d9255949ca9ceaffa6e82348,
    '/user/help': SpaController43b61b53b36f60284f0c312e5eabc846,
    '/user/subscription': SpaController266c0f918a9352bf71ff998fc72e49b4,
    '/studio': SpaController7081ef06e513d223c848904f90d5f37c,
    '/studio/podcast-master': SpaController0d1da230fe7367eb2f734fcb70fc299d,
    '/podcast/generate': SpaController209be3f184d0254bc15800576d0a53e8,
    '/{path}': SpaControllere82770d06df9f3de57e12c6f4a3eb557,
}

export default SpaController