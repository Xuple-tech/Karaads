import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\WidgetConfigController::index
* @see app/Http/Controllers/WidgetConfigController.php:24
* @route '/api/widget'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/widget',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\WidgetConfigController::index
* @see app/Http/Controllers/WidgetConfigController.php:24
* @route '/api/widget'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\WidgetConfigController::index
* @see app/Http/Controllers/WidgetConfigController.php:24
* @route '/api/widget'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\WidgetConfigController::index
* @see app/Http/Controllers/WidgetConfigController.php:24
* @route '/api/widget'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\WidgetConfigController::store
* @see app/Http/Controllers/WidgetConfigController.php:37
* @route '/api/widget'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/widget',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\WidgetConfigController::store
* @see app/Http/Controllers/WidgetConfigController.php:37
* @route '/api/widget'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\WidgetConfigController::store
* @see app/Http/Controllers/WidgetConfigController.php:37
* @route '/api/widget'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\WidgetConfigController::show
* @see app/Http/Controllers/WidgetConfigController.php:100
* @route '/api/widget/{widget}'
*/
export const show = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/widget/{widget}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\WidgetConfigController::show
* @see app/Http/Controllers/WidgetConfigController.php:100
* @route '/api/widget/{widget}'
*/
show.url = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { widget: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { widget: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            widget: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        widget: typeof args.widget === 'object'
        ? args.widget.id
        : args.widget,
    }

    return show.definition.url
            .replace('{widget}', parsedArgs.widget.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\WidgetConfigController::show
* @see app/Http/Controllers/WidgetConfigController.php:100
* @route '/api/widget/{widget}'
*/
show.get = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\WidgetConfigController::show
* @see app/Http/Controllers/WidgetConfigController.php:100
* @route '/api/widget/{widget}'
*/
show.head = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\WidgetConfigController::update
* @see app/Http/Controllers/WidgetConfigController.php:109
* @route '/api/widget/{widget}'
*/
export const update = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/widget/{widget}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\WidgetConfigController::update
* @see app/Http/Controllers/WidgetConfigController.php:109
* @route '/api/widget/{widget}'
*/
update.url = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { widget: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { widget: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            widget: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        widget: typeof args.widget === 'object'
        ? args.widget.id
        : args.widget,
    }

    return update.definition.url
            .replace('{widget}', parsedArgs.widget.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\WidgetConfigController::update
* @see app/Http/Controllers/WidgetConfigController.php:109
* @route '/api/widget/{widget}'
*/
update.put = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\WidgetConfigController::destroy
* @see app/Http/Controllers/WidgetConfigController.php:156
* @route '/api/widget/{widget}'
*/
export const destroy = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/widget/{widget}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\WidgetConfigController::destroy
* @see app/Http/Controllers/WidgetConfigController.php:156
* @route '/api/widget/{widget}'
*/
destroy.url = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { widget: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { widget: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            widget: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        widget: typeof args.widget === 'object'
        ? args.widget.id
        : args.widget,
    }

    return destroy.definition.url
            .replace('{widget}', parsedArgs.widget.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\WidgetConfigController::destroy
* @see app/Http/Controllers/WidgetConfigController.php:156
* @route '/api/widget/{widget}'
*/
destroy.delete = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\WidgetConfigController::listKnowledge
* @see app/Http/Controllers/WidgetConfigController.php:164
* @route '/api/widget/{widget}/knowledge'
*/
export const listKnowledge = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: listKnowledge.url(args, options),
    method: 'get',
})

listKnowledge.definition = {
    methods: ["get","head"],
    url: '/api/widget/{widget}/knowledge',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\WidgetConfigController::listKnowledge
* @see app/Http/Controllers/WidgetConfigController.php:164
* @route '/api/widget/{widget}/knowledge'
*/
listKnowledge.url = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { widget: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { widget: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            widget: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        widget: typeof args.widget === 'object'
        ? args.widget.id
        : args.widget,
    }

    return listKnowledge.definition.url
            .replace('{widget}', parsedArgs.widget.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\WidgetConfigController::listKnowledge
* @see app/Http/Controllers/WidgetConfigController.php:164
* @route '/api/widget/{widget}/knowledge'
*/
listKnowledge.get = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: listKnowledge.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\WidgetConfigController::listKnowledge
* @see app/Http/Controllers/WidgetConfigController.php:164
* @route '/api/widget/{widget}/knowledge'
*/
listKnowledge.head = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: listKnowledge.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\WidgetConfigController::addKnowledge
* @see app/Http/Controllers/WidgetConfigController.php:173
* @route '/api/widget/{widget}/knowledge'
*/
export const addKnowledge = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addKnowledge.url(args, options),
    method: 'post',
})

addKnowledge.definition = {
    methods: ["post"],
    url: '/api/widget/{widget}/knowledge',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\WidgetConfigController::addKnowledge
* @see app/Http/Controllers/WidgetConfigController.php:173
* @route '/api/widget/{widget}/knowledge'
*/
addKnowledge.url = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { widget: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { widget: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            widget: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        widget: typeof args.widget === 'object'
        ? args.widget.id
        : args.widget,
    }

    return addKnowledge.definition.url
            .replace('{widget}', parsedArgs.widget.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\WidgetConfigController::addKnowledge
* @see app/Http/Controllers/WidgetConfigController.php:173
* @route '/api/widget/{widget}/knowledge'
*/
addKnowledge.post = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addKnowledge.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\WidgetConfigController::uploadPdf
* @see app/Http/Controllers/WidgetConfigController.php:194
* @route '/api/widget/{widget}/knowledge/pdf'
*/
export const uploadPdf = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadPdf.url(args, options),
    method: 'post',
})

uploadPdf.definition = {
    methods: ["post"],
    url: '/api/widget/{widget}/knowledge/pdf',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\WidgetConfigController::uploadPdf
* @see app/Http/Controllers/WidgetConfigController.php:194
* @route '/api/widget/{widget}/knowledge/pdf'
*/
uploadPdf.url = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { widget: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { widget: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            widget: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        widget: typeof args.widget === 'object'
        ? args.widget.id
        : args.widget,
    }

    return uploadPdf.definition.url
            .replace('{widget}', parsedArgs.widget.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\WidgetConfigController::uploadPdf
* @see app/Http/Controllers/WidgetConfigController.php:194
* @route '/api/widget/{widget}/knowledge/pdf'
*/
uploadPdf.post = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadPdf.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\WidgetConfigController::deleteKnowledge
* @see app/Http/Controllers/WidgetConfigController.php:210
* @route '/api/widget/{widget}/knowledge/{item}'
*/
export const deleteKnowledge = (args: { widget: string | { id: string }, item: string | { id: string } } | [widget: string | { id: string }, item: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteKnowledge.url(args, options),
    method: 'delete',
})

deleteKnowledge.definition = {
    methods: ["delete"],
    url: '/api/widget/{widget}/knowledge/{item}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\WidgetConfigController::deleteKnowledge
* @see app/Http/Controllers/WidgetConfigController.php:210
* @route '/api/widget/{widget}/knowledge/{item}'
*/
deleteKnowledge.url = (args: { widget: string | { id: string }, item: string | { id: string } } | [widget: string | { id: string }, item: string | { id: string } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            widget: args[0],
            item: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        widget: typeof args.widget === 'object'
        ? args.widget.id
        : args.widget,
        item: typeof args.item === 'object'
        ? args.item.id
        : args.item,
    }

    return deleteKnowledge.definition.url
            .replace('{widget}', parsedArgs.widget.toString())
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\WidgetConfigController::deleteKnowledge
* @see app/Http/Controllers/WidgetConfigController.php:210
* @route '/api/widget/{widget}/knowledge/{item}'
*/
deleteKnowledge.delete = (args: { widget: string | { id: string }, item: string | { id: string } } | [widget: string | { id: string }, item: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteKnowledge.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\WidgetConfigController::listTools
* @see app/Http/Controllers/WidgetConfigController.php:219
* @route '/api/widget/{widget}/tools'
*/
export const listTools = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: listTools.url(args, options),
    method: 'get',
})

listTools.definition = {
    methods: ["get","head"],
    url: '/api/widget/{widget}/tools',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\WidgetConfigController::listTools
* @see app/Http/Controllers/WidgetConfigController.php:219
* @route '/api/widget/{widget}/tools'
*/
listTools.url = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { widget: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { widget: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            widget: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        widget: typeof args.widget === 'object'
        ? args.widget.id
        : args.widget,
    }

    return listTools.definition.url
            .replace('{widget}', parsedArgs.widget.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\WidgetConfigController::listTools
* @see app/Http/Controllers/WidgetConfigController.php:219
* @route '/api/widget/{widget}/tools'
*/
listTools.get = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: listTools.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\WidgetConfigController::listTools
* @see app/Http/Controllers/WidgetConfigController.php:219
* @route '/api/widget/{widget}/tools'
*/
listTools.head = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: listTools.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\WidgetConfigController::addTool
* @see app/Http/Controllers/WidgetConfigController.php:228
* @route '/api/widget/{widget}/tools'
*/
export const addTool = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addTool.url(args, options),
    method: 'post',
})

addTool.definition = {
    methods: ["post"],
    url: '/api/widget/{widget}/tools',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\WidgetConfigController::addTool
* @see app/Http/Controllers/WidgetConfigController.php:228
* @route '/api/widget/{widget}/tools'
*/
addTool.url = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { widget: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { widget: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            widget: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        widget: typeof args.widget === 'object'
        ? args.widget.id
        : args.widget,
    }

    return addTool.definition.url
            .replace('{widget}', parsedArgs.widget.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\WidgetConfigController::addTool
* @see app/Http/Controllers/WidgetConfigController.php:228
* @route '/api/widget/{widget}/tools'
*/
addTool.post = (args: { widget: string | { id: string } } | [widget: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addTool.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\WidgetConfigController::updateTool
* @see app/Http/Controllers/WidgetConfigController.php:242
* @route '/api/widget/{widget}/tools/{tool}'
*/
export const updateTool = (args: { widget: string | { id: string }, tool: string | { id: string } } | [widget: string | { id: string }, tool: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateTool.url(args, options),
    method: 'put',
})

updateTool.definition = {
    methods: ["put"],
    url: '/api/widget/{widget}/tools/{tool}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\WidgetConfigController::updateTool
* @see app/Http/Controllers/WidgetConfigController.php:242
* @route '/api/widget/{widget}/tools/{tool}'
*/
updateTool.url = (args: { widget: string | { id: string }, tool: string | { id: string } } | [widget: string | { id: string }, tool: string | { id: string } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            widget: args[0],
            tool: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        widget: typeof args.widget === 'object'
        ? args.widget.id
        : args.widget,
        tool: typeof args.tool === 'object'
        ? args.tool.id
        : args.tool,
    }

    return updateTool.definition.url
            .replace('{widget}', parsedArgs.widget.toString())
            .replace('{tool}', parsedArgs.tool.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\WidgetConfigController::updateTool
* @see app/Http/Controllers/WidgetConfigController.php:242
* @route '/api/widget/{widget}/tools/{tool}'
*/
updateTool.put = (args: { widget: string | { id: string }, tool: string | { id: string } } | [widget: string | { id: string }, tool: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateTool.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\WidgetConfigController::deleteTool
* @see app/Http/Controllers/WidgetConfigController.php:257
* @route '/api/widget/{widget}/tools/{tool}'
*/
export const deleteTool = (args: { widget: string | { id: string }, tool: string | { id: string } } | [widget: string | { id: string }, tool: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteTool.url(args, options),
    method: 'delete',
})

deleteTool.definition = {
    methods: ["delete"],
    url: '/api/widget/{widget}/tools/{tool}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\WidgetConfigController::deleteTool
* @see app/Http/Controllers/WidgetConfigController.php:257
* @route '/api/widget/{widget}/tools/{tool}'
*/
deleteTool.url = (args: { widget: string | { id: string }, tool: string | { id: string } } | [widget: string | { id: string }, tool: string | { id: string } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            widget: args[0],
            tool: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        widget: typeof args.widget === 'object'
        ? args.widget.id
        : args.widget,
        tool: typeof args.tool === 'object'
        ? args.tool.id
        : args.tool,
    }

    return deleteTool.definition.url
            .replace('{widget}', parsedArgs.widget.toString())
            .replace('{tool}', parsedArgs.tool.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\WidgetConfigController::deleteTool
* @see app/Http/Controllers/WidgetConfigController.php:257
* @route '/api/widget/{widget}/tools/{tool}'
*/
deleteTool.delete = (args: { widget: string | { id: string }, tool: string | { id: string } } | [widget: string | { id: string }, tool: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteTool.url(args, options),
    method: 'delete',
})

const WidgetConfigController = { index, store, show, update, destroy, listKnowledge, addKnowledge, uploadPdf, deleteKnowledge, listTools, addTool, updateTool, deleteTool }

export default WidgetConfigController