import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\DeveloperApi\V1\ImageGenerationsController::store
 * @see app/Http/Controllers/DeveloperApi/V1/ImageGenerationsController.php:17
 * @route '//api.127.0.0.1/v1/images/generations'
 */
const storec28da7f9dcf962ca78c5afbdfab6dd94 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storec28da7f9dcf962ca78c5afbdfab6dd94.url(options),
    method: 'post',
})

storec28da7f9dcf962ca78c5afbdfab6dd94.definition = {
    methods: ["post"],
    url: '//api.127.0.0.1/v1/images/generations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DeveloperApi\V1\ImageGenerationsController::store
 * @see app/Http/Controllers/DeveloperApi/V1/ImageGenerationsController.php:17
 * @route '//api.127.0.0.1/v1/images/generations'
 */
storec28da7f9dcf962ca78c5afbdfab6dd94.url = (options?: RouteQueryOptions) => {
    return storec28da7f9dcf962ca78c5afbdfab6dd94.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeveloperApi\V1\ImageGenerationsController::store
 * @see app/Http/Controllers/DeveloperApi/V1/ImageGenerationsController.php:17
 * @route '//api.127.0.0.1/v1/images/generations'
 */
storec28da7f9dcf962ca78c5afbdfab6dd94.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storec28da7f9dcf962ca78c5afbdfab6dd94.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DeveloperApi\V1\ImageGenerationsController::store
 * @see app/Http/Controllers/DeveloperApi/V1/ImageGenerationsController.php:17
 * @route '//localhost/v1/images/generations'
 */
const store7a981afedbe91d98270460aecfdcc414 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store7a981afedbe91d98270460aecfdcc414.url(options),
    method: 'post',
})

store7a981afedbe91d98270460aecfdcc414.definition = {
    methods: ["post"],
    url: '//localhost/v1/images/generations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DeveloperApi\V1\ImageGenerationsController::store
 * @see app/Http/Controllers/DeveloperApi/V1/ImageGenerationsController.php:17
 * @route '//localhost/v1/images/generations'
 */
store7a981afedbe91d98270460aecfdcc414.url = (options?: RouteQueryOptions) => {
    return store7a981afedbe91d98270460aecfdcc414.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeveloperApi\V1\ImageGenerationsController::store
 * @see app/Http/Controllers/DeveloperApi/V1/ImageGenerationsController.php:17
 * @route '//localhost/v1/images/generations'
 */
store7a981afedbe91d98270460aecfdcc414.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store7a981afedbe91d98270460aecfdcc414.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DeveloperApi\V1\ImageGenerationsController::store
 * @see app/Http/Controllers/DeveloperApi/V1/ImageGenerationsController.php:17
 * @route '//127.0.0.1/v1/images/generations'
 */
const store8af54a1c19f004d4560da39e2aca6da9 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store8af54a1c19f004d4560da39e2aca6da9.url(options),
    method: 'post',
})

store8af54a1c19f004d4560da39e2aca6da9.definition = {
    methods: ["post"],
    url: '//127.0.0.1/v1/images/generations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DeveloperApi\V1\ImageGenerationsController::store
 * @see app/Http/Controllers/DeveloperApi/V1/ImageGenerationsController.php:17
 * @route '//127.0.0.1/v1/images/generations'
 */
store8af54a1c19f004d4560da39e2aca6da9.url = (options?: RouteQueryOptions) => {
    return store8af54a1c19f004d4560da39e2aca6da9.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeveloperApi\V1\ImageGenerationsController::store
 * @see app/Http/Controllers/DeveloperApi/V1/ImageGenerationsController.php:17
 * @route '//127.0.0.1/v1/images/generations'
 */
store8af54a1c19f004d4560da39e2aca6da9.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store8af54a1c19f004d4560da39e2aca6da9.url(options),
    method: 'post',
})

export const store = {
    '//api.127.0.0.1/v1/images/generations': storec28da7f9dcf962ca78c5afbdfab6dd94,
    '//localhost/v1/images/generations': store7a981afedbe91d98270460aecfdcc414,
    '//127.0.0.1/v1/images/generations': store8af54a1c19f004d4560da39e2aca6da9,
}

const ImageGenerationsController = { store }

export default ImageGenerationsController