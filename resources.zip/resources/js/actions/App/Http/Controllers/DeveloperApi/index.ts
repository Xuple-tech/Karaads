import V1 from './V1'

const DeveloperApi = {
    V1: Object.assign(V1, V1),
}

export default DeveloperApi