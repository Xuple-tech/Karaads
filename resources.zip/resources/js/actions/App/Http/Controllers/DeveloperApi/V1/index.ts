import ModelsController from './ModelsController'
import ChatCompletionsController from './ChatCompletionsController'
import AccountController from './AccountController'

const V1 = {
    ModelsController: Object.assign(ModelsController, ModelsController),
    ChatCompletionsController: Object.assign(ChatCompletionsController, ChatCompletionsController),
    AccountController: Object.assign(AccountController, AccountController),
}

export default V1