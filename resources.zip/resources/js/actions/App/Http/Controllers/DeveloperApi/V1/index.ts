import ModelsController from './ModelsController'
import ChatCompletionsController from './ChatCompletionsController'
import ImageGenerationsController from './ImageGenerationsController'
import AccountController from './AccountController'
const V1 = {
    ModelsController: Object.assign(ModelsController, ModelsController),
ChatCompletionsController: Object.assign(ChatCompletionsController, ChatCompletionsController),
ImageGenerationsController: Object.assign(ImageGenerationsController, ImageGenerationsController),
AccountController: Object.assign(AccountController, AccountController),
}

export default V1