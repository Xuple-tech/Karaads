import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\DeveloperApi\V1\ChatCompletionsController::store
 * @see app/Http/Controllers/DeveloperApi/V1/ChatCompletionsController.php:18
 * @route '//api.127.0.0.1/v1/chat/completions'
 */
const store6451ca27ce760f026d80918713019c4e = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store6451ca27ce760f026d80918713019c4e.url(options),
    method: 'post',
})

store6451ca27ce760f026d80918713019c4e.definition = {
    methods: ["post"],
    url: '//api.127.0.0.1/v1/chat/completions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DeveloperApi\V1\ChatCompletionsController::store
 * @see app/Http/Controllers/DeveloperApi/V1/ChatCompletionsController.php:18
 * @route '//api.127.0.0.1/v1/chat/completions'
 */
store6451ca27ce760f026d80918713019c4e.url = (options?: RouteQueryOptions) => {
    return store6451ca27ce760f026d80918713019c4e.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeveloperApi\V1\ChatCompletionsController::store
 * @see app/Http/Controllers/DeveloperApi/V1/ChatCompletionsController.php:18
 * @route '//api.127.0.0.1/v1/chat/completions'
 */
store6451ca27ce760f026d80918713019c4e.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store6451ca27ce760f026d80918713019c4e.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DeveloperApi\V1\ChatCompletionsController::store
 * @see app/Http/Controllers/DeveloperApi/V1/ChatCompletionsController.php:18
 * @route '//localhost/v1/chat/completions'
 */
const store8ab8d96d329ac4a001747bf264d4e6c0 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store8ab8d96d329ac4a001747bf264d4e6c0.url(options),
    method: 'post',
})

store8ab8d96d329ac4a001747bf264d4e6c0.definition = {
    methods: ["post"],
    url: '//localhost/v1/chat/completions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DeveloperApi\V1\ChatCompletionsController::store
 * @see app/Http/Controllers/DeveloperApi/V1/ChatCompletionsController.php:18
 * @route '//localhost/v1/chat/completions'
 */
store8ab8d96d329ac4a001747bf264d4e6c0.url = (options?: RouteQueryOptions) => {
    return store8ab8d96d329ac4a001747bf264d4e6c0.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeveloperApi\V1\ChatCompletionsController::store
 * @see app/Http/Controllers/DeveloperApi/V1/ChatCompletionsController.php:18
 * @route '//localhost/v1/chat/completions'
 */
store8ab8d96d329ac4a001747bf264d4e6c0.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store8ab8d96d329ac4a001747bf264d4e6c0.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DeveloperApi\V1\ChatCompletionsController::store
 * @see app/Http/Controllers/DeveloperApi/V1/ChatCompletionsController.php:18
 * @route '//127.0.0.1/v1/chat/completions'
 */
const storecb38b8d8faf54d1d84a3cc961aeb2af2 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storecb38b8d8faf54d1d84a3cc961aeb2af2.url(options),
    method: 'post',
})

storecb38b8d8faf54d1d84a3cc961aeb2af2.definition = {
    methods: ["post"],
    url: '//127.0.0.1/v1/chat/completions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DeveloperApi\V1\ChatCompletionsController::store
 * @see app/Http/Controllers/DeveloperApi/V1/ChatCompletionsController.php:18
 * @route '//127.0.0.1/v1/chat/completions'
 */
storecb38b8d8faf54d1d84a3cc961aeb2af2.url = (options?: RouteQueryOptions) => {
    return storecb38b8d8faf54d1d84a3cc961aeb2af2.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeveloperApi\V1\ChatCompletionsController::store
 * @see app/Http/Controllers/DeveloperApi/V1/ChatCompletionsController.php:18
 * @route '//127.0.0.1/v1/chat/completions'
 */
storecb38b8d8faf54d1d84a3cc961aeb2af2.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storecb38b8d8faf54d1d84a3cc961aeb2af2.url(options),
    method: 'post',
})

export const store = {
    '//api.127.0.0.1/v1/chat/completions': store6451ca27ce760f026d80918713019c4e,
    '//localhost/v1/chat/completions': store8ab8d96d329ac4a001747bf264d4e6c0,
    '//127.0.0.1/v1/chat/completions': storecb38b8d8faf54d1d84a3cc961aeb2af2,
}

const ChatCompletionsController = { store }

export default ChatCompletionsController