import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\DeveloperApi\V1\ChatCompletionsController::store
* @see app/Http/Controllers/DeveloperApi/V1/ChatCompletionsController.php:18
* @route '/api/v1/chat/completions'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/v1/chat/completions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DeveloperApi\V1\ChatCompletionsController::store
* @see app/Http/Controllers/DeveloperApi/V1/ChatCompletionsController.php:18
* @route '/api/v1/chat/completions'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeveloperApi\V1\ChatCompletionsController::store
* @see app/Http/Controllers/DeveloperApi/V1/ChatCompletionsController.php:18
* @route '/api/v1/chat/completions'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

const ChatCompletionsController = { store }

export default ChatCompletionsController