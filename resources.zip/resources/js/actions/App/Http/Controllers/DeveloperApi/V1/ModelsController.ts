import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\DeveloperApi\V1\ModelsController::index
* @see app/Http/Controllers/DeveloperApi/V1/ModelsController.php:15
* @route '/api/v1/models'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/v1/models',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeveloperApi\V1\ModelsController::index
* @see app/Http/Controllers/DeveloperApi/V1/ModelsController.php:15
* @route '/api/v1/models'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeveloperApi\V1\ModelsController::index
* @see app/Http/Controllers/DeveloperApi/V1/ModelsController.php:15
* @route '/api/v1/models'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeveloperApi\V1\ModelsController::index
* @see app/Http/Controllers/DeveloperApi/V1/ModelsController.php:15
* @route '/api/v1/models'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

const ModelsController = { index }

export default ModelsController