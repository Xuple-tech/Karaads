import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\DeveloperApi\V1\ModelsController::index
 * @see app/Http/Controllers/DeveloperApi/V1/ModelsController.php:15
 * @route '//api.127.0.0.1/v1/models'
 */
const indexf6633769c1432055c0ab5ef19a18fe58 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexf6633769c1432055c0ab5ef19a18fe58.url(options),
    method: 'get',
})

indexf6633769c1432055c0ab5ef19a18fe58.definition = {
    methods: ["get","head"],
    url: '//api.127.0.0.1/v1/models',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeveloperApi\V1\ModelsController::index
 * @see app/Http/Controllers/DeveloperApi/V1/ModelsController.php:15
 * @route '//api.127.0.0.1/v1/models'
 */
indexf6633769c1432055c0ab5ef19a18fe58.url = (options?: RouteQueryOptions) => {
    return indexf6633769c1432055c0ab5ef19a18fe58.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeveloperApi\V1\ModelsController::index
 * @see app/Http/Controllers/DeveloperApi/V1/ModelsController.php:15
 * @route '//api.127.0.0.1/v1/models'
 */
indexf6633769c1432055c0ab5ef19a18fe58.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexf6633769c1432055c0ab5ef19a18fe58.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DeveloperApi\V1\ModelsController::index
 * @see app/Http/Controllers/DeveloperApi/V1/ModelsController.php:15
 * @route '//api.127.0.0.1/v1/models'
 */
indexf6633769c1432055c0ab5ef19a18fe58.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: indexf6633769c1432055c0ab5ef19a18fe58.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DeveloperApi\V1\ModelsController::index
 * @see app/Http/Controllers/DeveloperApi/V1/ModelsController.php:15
 * @route '//localhost/v1/models'
 */
const index65057daddf7ccdc10f4a3fd714ee4c12 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index65057daddf7ccdc10f4a3fd714ee4c12.url(options),
    method: 'get',
})

index65057daddf7ccdc10f4a3fd714ee4c12.definition = {
    methods: ["get","head"],
    url: '//localhost/v1/models',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeveloperApi\V1\ModelsController::index
 * @see app/Http/Controllers/DeveloperApi/V1/ModelsController.php:15
 * @route '//localhost/v1/models'
 */
index65057daddf7ccdc10f4a3fd714ee4c12.url = (options?: RouteQueryOptions) => {
    return index65057daddf7ccdc10f4a3fd714ee4c12.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeveloperApi\V1\ModelsController::index
 * @see app/Http/Controllers/DeveloperApi/V1/ModelsController.php:15
 * @route '//localhost/v1/models'
 */
index65057daddf7ccdc10f4a3fd714ee4c12.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index65057daddf7ccdc10f4a3fd714ee4c12.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DeveloperApi\V1\ModelsController::index
 * @see app/Http/Controllers/DeveloperApi/V1/ModelsController.php:15
 * @route '//localhost/v1/models'
 */
index65057daddf7ccdc10f4a3fd714ee4c12.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index65057daddf7ccdc10f4a3fd714ee4c12.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DeveloperApi\V1\ModelsController::index
 * @see app/Http/Controllers/DeveloperApi/V1/ModelsController.php:15
 * @route '//127.0.0.1/v1/models'
 */
const index81cf66bda6dddd027467bfa32e49cdb4 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index81cf66bda6dddd027467bfa32e49cdb4.url(options),
    method: 'get',
})

index81cf66bda6dddd027467bfa32e49cdb4.definition = {
    methods: ["get","head"],
    url: '//127.0.0.1/v1/models',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeveloperApi\V1\ModelsController::index
 * @see app/Http/Controllers/DeveloperApi/V1/ModelsController.php:15
 * @route '//127.0.0.1/v1/models'
 */
index81cf66bda6dddd027467bfa32e49cdb4.url = (options?: RouteQueryOptions) => {
    return index81cf66bda6dddd027467bfa32e49cdb4.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeveloperApi\V1\ModelsController::index
 * @see app/Http/Controllers/DeveloperApi/V1/ModelsController.php:15
 * @route '//127.0.0.1/v1/models'
 */
index81cf66bda6dddd027467bfa32e49cdb4.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index81cf66bda6dddd027467bfa32e49cdb4.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DeveloperApi\V1\ModelsController::index
 * @see app/Http/Controllers/DeveloperApi/V1/ModelsController.php:15
 * @route '//127.0.0.1/v1/models'
 */
index81cf66bda6dddd027467bfa32e49cdb4.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index81cf66bda6dddd027467bfa32e49cdb4.url(options),
    method: 'head',
})

export const index = {
    '//api.127.0.0.1/v1/models': indexf6633769c1432055c0ab5ef19a18fe58,
    '//localhost/v1/models': index65057daddf7ccdc10f4a3fd714ee4c12,
    '//127.0.0.1/v1/models': index81cf66bda6dddd027467bfa32e49cdb4,
}

const ModelsController = { index }

export default ModelsController