import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::me
* @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:17
* @route '/api/v1/me'
*/
export const me = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: me.url(options),
    method: 'get',
})

me.definition = {
    methods: ["get","head"],
    url: '/api/v1/me',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::me
* @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:17
* @route '/api/v1/me'
*/
me.url = (options?: RouteQueryOptions) => {
    return me.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::me
* @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:17
* @route '/api/v1/me'
*/
me.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: me.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::me
* @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:17
* @route '/api/v1/me'
*/
me.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: me.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::usage
* @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:44
* @route '/api/v1/usage'
*/
export const usage = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: usage.url(options),
    method: 'get',
})

usage.definition = {
    methods: ["get","head"],
    url: '/api/v1/usage',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::usage
* @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:44
* @route '/api/v1/usage'
*/
usage.url = (options?: RouteQueryOptions) => {
    return usage.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::usage
* @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:44
* @route '/api/v1/usage'
*/
usage.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: usage.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::usage
* @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:44
* @route '/api/v1/usage'
*/
usage.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: usage.url(options),
    method: 'head',
})

const AccountController = { me, usage }

export default AccountController