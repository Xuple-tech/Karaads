import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::usage
 * @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:44
 * @route '//api.127.0.0.1/v1/usage'
 */
const usage0cd24c36ad5780ae5a18cda4a9beff0b = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: usage0cd24c36ad5780ae5a18cda4a9beff0b.url(options),
    method: 'get',
})

usage0cd24c36ad5780ae5a18cda4a9beff0b.definition = {
    methods: ["get","head"],
    url: '//api.127.0.0.1/v1/usage',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::usage
 * @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:44
 * @route '//api.127.0.0.1/v1/usage'
 */
usage0cd24c36ad5780ae5a18cda4a9beff0b.url = (options?: RouteQueryOptions) => {
    return usage0cd24c36ad5780ae5a18cda4a9beff0b.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::usage
 * @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:44
 * @route '//api.127.0.0.1/v1/usage'
 */
usage0cd24c36ad5780ae5a18cda4a9beff0b.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: usage0cd24c36ad5780ae5a18cda4a9beff0b.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::usage
 * @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:44
 * @route '//api.127.0.0.1/v1/usage'
 */
usage0cd24c36ad5780ae5a18cda4a9beff0b.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: usage0cd24c36ad5780ae5a18cda4a9beff0b.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::usage
 * @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:44
 * @route '//localhost/v1/usage'
 */
const usagebb3962081c2417e5708c7dddd25b3130 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: usagebb3962081c2417e5708c7dddd25b3130.url(options),
    method: 'get',
})

usagebb3962081c2417e5708c7dddd25b3130.definition = {
    methods: ["get","head"],
    url: '//localhost/v1/usage',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::usage
 * @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:44
 * @route '//localhost/v1/usage'
 */
usagebb3962081c2417e5708c7dddd25b3130.url = (options?: RouteQueryOptions) => {
    return usagebb3962081c2417e5708c7dddd25b3130.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::usage
 * @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:44
 * @route '//localhost/v1/usage'
 */
usagebb3962081c2417e5708c7dddd25b3130.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: usagebb3962081c2417e5708c7dddd25b3130.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::usage
 * @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:44
 * @route '//localhost/v1/usage'
 */
usagebb3962081c2417e5708c7dddd25b3130.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: usagebb3962081c2417e5708c7dddd25b3130.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::usage
 * @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:44
 * @route '//127.0.0.1/v1/usage'
 */
const usagea5a4bc6a79f4a39107326276ad40c879 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: usagea5a4bc6a79f4a39107326276ad40c879.url(options),
    method: 'get',
})

usagea5a4bc6a79f4a39107326276ad40c879.definition = {
    methods: ["get","head"],
    url: '//127.0.0.1/v1/usage',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::usage
 * @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:44
 * @route '//127.0.0.1/v1/usage'
 */
usagea5a4bc6a79f4a39107326276ad40c879.url = (options?: RouteQueryOptions) => {
    return usagea5a4bc6a79f4a39107326276ad40c879.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::usage
 * @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:44
 * @route '//127.0.0.1/v1/usage'
 */
usagea5a4bc6a79f4a39107326276ad40c879.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: usagea5a4bc6a79f4a39107326276ad40c879.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::usage
 * @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:44
 * @route '//127.0.0.1/v1/usage'
 */
usagea5a4bc6a79f4a39107326276ad40c879.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: usagea5a4bc6a79f4a39107326276ad40c879.url(options),
    method: 'head',
})

export const usage = {
    '//api.127.0.0.1/v1/usage': usage0cd24c36ad5780ae5a18cda4a9beff0b,
    '//localhost/v1/usage': usagebb3962081c2417e5708c7dddd25b3130,
    '//127.0.0.1/v1/usage': usagea5a4bc6a79f4a39107326276ad40c879,
}

/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::me
 * @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:17
 * @route '//api.127.0.0.1/v1/me'
 */
const medb887d6eed623fcc7fe1409e3badf33e = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: medb887d6eed623fcc7fe1409e3badf33e.url(options),
    method: 'get',
})

medb887d6eed623fcc7fe1409e3badf33e.definition = {
    methods: ["get","head"],
    url: '//api.127.0.0.1/v1/me',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::me
 * @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:17
 * @route '//api.127.0.0.1/v1/me'
 */
medb887d6eed623fcc7fe1409e3badf33e.url = (options?: RouteQueryOptions) => {
    return medb887d6eed623fcc7fe1409e3badf33e.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::me
 * @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:17
 * @route '//api.127.0.0.1/v1/me'
 */
medb887d6eed623fcc7fe1409e3badf33e.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: medb887d6eed623fcc7fe1409e3badf33e.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::me
 * @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:17
 * @route '//api.127.0.0.1/v1/me'
 */
medb887d6eed623fcc7fe1409e3badf33e.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: medb887d6eed623fcc7fe1409e3badf33e.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::me
 * @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:17
 * @route '//localhost/v1/me'
 */
const me7b65d5084ebff5b512c9533ab0d2517e = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: me7b65d5084ebff5b512c9533ab0d2517e.url(options),
    method: 'get',
})

me7b65d5084ebff5b512c9533ab0d2517e.definition = {
    methods: ["get","head"],
    url: '//localhost/v1/me',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::me
 * @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:17
 * @route '//localhost/v1/me'
 */
me7b65d5084ebff5b512c9533ab0d2517e.url = (options?: RouteQueryOptions) => {
    return me7b65d5084ebff5b512c9533ab0d2517e.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::me
 * @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:17
 * @route '//localhost/v1/me'
 */
me7b65d5084ebff5b512c9533ab0d2517e.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: me7b65d5084ebff5b512c9533ab0d2517e.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::me
 * @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:17
 * @route '//localhost/v1/me'
 */
me7b65d5084ebff5b512c9533ab0d2517e.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: me7b65d5084ebff5b512c9533ab0d2517e.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::me
 * @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:17
 * @route '//127.0.0.1/v1/me'
 */
const me05405db7f1749f4abc5befbaaf6bf1ea = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: me05405db7f1749f4abc5befbaaf6bf1ea.url(options),
    method: 'get',
})

me05405db7f1749f4abc5befbaaf6bf1ea.definition = {
    methods: ["get","head"],
    url: '//127.0.0.1/v1/me',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::me
 * @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:17
 * @route '//127.0.0.1/v1/me'
 */
me05405db7f1749f4abc5befbaaf6bf1ea.url = (options?: RouteQueryOptions) => {
    return me05405db7f1749f4abc5befbaaf6bf1ea.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::me
 * @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:17
 * @route '//127.0.0.1/v1/me'
 */
me05405db7f1749f4abc5befbaaf6bf1ea.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: me05405db7f1749f4abc5befbaaf6bf1ea.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DeveloperApi\V1\AccountController::me
 * @see app/Http/Controllers/DeveloperApi/V1/AccountController.php:17
 * @route '//127.0.0.1/v1/me'
 */
me05405db7f1749f4abc5befbaaf6bf1ea.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: me05405db7f1749f4abc5befbaaf6bf1ea.url(options),
    method: 'head',
})

export const me = {
    '//api.127.0.0.1/v1/me': medb887d6eed623fcc7fe1409e3badf33e,
    '//localhost/v1/me': me7b65d5084ebff5b512c9533ab0d2517e,
    '//127.0.0.1/v1/me': me05405db7f1749f4abc5befbaaf6bf1ea,
}

const AccountController = { usage, me }

export default AccountController