import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\WidgetPublicController::config
* @see app/Http/Controllers/WidgetPublicController.php:21
* @route '/api/widget/{token}/config'
*/
export const config = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: config.url(args, options),
    method: 'get',
})

config.definition = {
    methods: ["get","head"],
    url: '/api/widget/{token}/config',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\WidgetPublicController::config
* @see app/Http/Controllers/WidgetPublicController.php:21
* @route '/api/widget/{token}/config'
*/
config.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    if (Array.isArray(args)) {
        args = {
            token: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        token: args.token,
    }

    return config.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\WidgetPublicController::config
* @see app/Http/Controllers/WidgetPublicController.php:21
* @route '/api/widget/{token}/config'
*/
config.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: config.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\WidgetPublicController::config
* @see app/Http/Controllers/WidgetPublicController.php:21
* @route '/api/widget/{token}/config'
*/
config.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: config.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\WidgetPublicController::startSession
* @see app/Http/Controllers/WidgetPublicController.php:35
* @route '/api/widget/{token}/session'
*/
export const startSession = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startSession.url(args, options),
    method: 'post',
})

startSession.definition = {
    methods: ["post"],
    url: '/api/widget/{token}/session',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\WidgetPublicController::startSession
* @see app/Http/Controllers/WidgetPublicController.php:35
* @route '/api/widget/{token}/session'
*/
startSession.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    if (Array.isArray(args)) {
        args = {
            token: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        token: args.token,
    }

    return startSession.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\WidgetPublicController::startSession
* @see app/Http/Controllers/WidgetPublicController.php:35
* @route '/api/widget/{token}/session'
*/
startSession.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startSession.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\WidgetPublicController::chat
* @see app/Http/Controllers/WidgetPublicController.php:82
* @route '/api/widget/{token}/chat'
*/
export const chat = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: chat.url(args, options),
    method: 'post',
})

chat.definition = {
    methods: ["post"],
    url: '/api/widget/{token}/chat',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\WidgetPublicController::chat
* @see app/Http/Controllers/WidgetPublicController.php:82
* @route '/api/widget/{token}/chat'
*/
chat.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    if (Array.isArray(args)) {
        args = {
            token: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        token: args.token,
    }

    return chat.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\WidgetPublicController::chat
* @see app/Http/Controllers/WidgetPublicController.php:82
* @route '/api/widget/{token}/chat'
*/
chat.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: chat.url(args, options),
    method: 'post',
})

const WidgetPublicController = { config, startSession, chat }

export default WidgetPublicController