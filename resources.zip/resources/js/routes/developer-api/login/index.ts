import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::store
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:30
* @route '/developer-api/login'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/developer-api/login',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::store
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:30
* @route '/developer-api/login'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::store
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:30
* @route '/developer-api/login'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

const login = {
    store: Object.assign(store, store),
}

export default login