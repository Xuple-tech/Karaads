import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::index
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:48
* @route '/developer-api/keys'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/developer-api/keys',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::index
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:48
* @route '/developer-api/keys'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::index
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:48
* @route '/developer-api/keys'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::index
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:48
* @route '/developer-api/keys'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::store
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:168
* @route '/developer-api/keys'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/developer-api/keys',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::store
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:168
* @route '/developer-api/keys'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::store
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:168
* @route '/developer-api/keys'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::update
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:191
* @route '/developer-api/keys/{developerApiKey}'
*/
export const update = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/developer-api/keys/{developerApiKey}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::update
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:191
* @route '/developer-api/keys/{developerApiKey}'
*/
update.url = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { developerApiKey: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { developerApiKey: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            developerApiKey: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        developerApiKey: typeof args.developerApiKey === 'object'
        ? args.developerApiKey.id
        : args.developerApiKey,
    }

    return update.definition.url
            .replace('{developerApiKey}', parsedArgs.developerApiKey.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::update
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:191
* @route '/developer-api/keys/{developerApiKey}'
*/
update.put = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::revoke
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:214
* @route '/developer-api/keys/{developerApiKey}/revoke'
*/
export const revoke = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: revoke.url(args, options),
    method: 'post',
})

revoke.definition = {
    methods: ["post"],
    url: '/developer-api/keys/{developerApiKey}/revoke',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::revoke
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:214
* @route '/developer-api/keys/{developerApiKey}/revoke'
*/
revoke.url = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { developerApiKey: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { developerApiKey: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            developerApiKey: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        developerApiKey: typeof args.developerApiKey === 'object'
        ? args.developerApiKey.id
        : args.developerApiKey,
    }

    return revoke.definition.url
            .replace('{developerApiKey}', parsedArgs.developerApiKey.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::revoke
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:214
* @route '/developer-api/keys/{developerApiKey}/revoke'
*/
revoke.post = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: revoke.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::regenerate
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:223
* @route '/developer-api/keys/{developerApiKey}/regenerate'
*/
export const regenerate = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerate.url(args, options),
    method: 'post',
})

regenerate.definition = {
    methods: ["post"],
    url: '/developer-api/keys/{developerApiKey}/regenerate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::regenerate
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:223
* @route '/developer-api/keys/{developerApiKey}/regenerate'
*/
regenerate.url = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { developerApiKey: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { developerApiKey: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            developerApiKey: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        developerApiKey: typeof args.developerApiKey === 'object'
        ? args.developerApiKey.id
        : args.developerApiKey,
    }

    return regenerate.definition.url
            .replace('{developerApiKey}', parsedArgs.developerApiKey.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::regenerate
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:223
* @route '/developer-api/keys/{developerApiKey}/regenerate'
*/
regenerate.post = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerate.url(args, options),
    method: 'post',
})

const keys = {
    index: Object.assign(index, index),
    store: Object.assign(store, store),
    update: Object.assign(update, update),
    revoke: Object.assign(revoke, revoke),
    regenerate: Object.assign(regenerate, regenerate),
}

export default keys