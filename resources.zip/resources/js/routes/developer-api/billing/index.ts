import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::index
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:118
* @route '/developer-api/billing'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/developer-api/billing',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::index
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:118
* @route '/developer-api/billing'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::index
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:118
* @route '/developer-api/billing'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::index
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:118
* @route '/developer-api/billing'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

const billing = {
    index: Object.assign(index, index),
}

export default billing