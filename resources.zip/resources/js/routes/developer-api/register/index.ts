import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::store
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:68
* @route '/developer-api/register'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/developer-api/register',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::store
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:68
* @route '/developer-api/register'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::store
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:68
* @route '/developer-api/register'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

const register = {
    store: Object.assign(store, store),
}

export default register