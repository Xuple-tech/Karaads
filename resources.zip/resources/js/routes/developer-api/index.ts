import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../wayfinder'
import loginDf2c2a from './login'
import register702019 from './register'
import keys from './keys'
import usage from './usage'
import billing from './billing'
/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::login
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:19
* @route '/developer-api/login'
*/
export const login = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: login.url(options),
    method: 'get',
})

login.definition = {
    methods: ["get","head"],
    url: '/developer-api/login',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::login
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:19
* @route '/developer-api/login'
*/
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::login
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:19
* @route '/developer-api/login'
*/
login.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: login.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::login
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:19
* @route '/developer-api/login'
*/
login.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: login.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::register
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:59
* @route '/developer-api/register'
*/
export const register = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: register.url(options),
    method: 'get',
})

register.definition = {
    methods: ["get","head"],
    url: '/developer-api/register',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::register
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:59
* @route '/developer-api/register'
*/
register.url = (options?: RouteQueryOptions) => {
    return register.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::register
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:59
* @route '/developer-api/register'
*/
register.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: register.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::register
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:59
* @route '/developer-api/register'
*/
register.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: register.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::logout
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:49
* @route '/developer-api/logout'
*/
export const logout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

logout.definition = {
    methods: ["post"],
    url: '/developer-api/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::logout
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:49
* @route '/developer-api/logout'
*/
logout.url = (options?: RouteQueryOptions) => {
    return logout.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalAuthController::logout
* @see app/Http/Controllers/Developer/DeveloperPortalAuthController.php:49
* @route '/developer-api/logout'
*/
logout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::index
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:32
* @route '/developer-api'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/developer-api',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::index
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:32
* @route '/developer-api'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::index
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:32
* @route '/developer-api'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::index
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:32
* @route '/developer-api'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::quickstart
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:148
* @route '/developer-api/quickstart'
*/
export const quickstart = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: quickstart.url(options),
    method: 'get',
})

quickstart.definition = {
    methods: ["get","head"],
    url: '/developer-api/quickstart',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::quickstart
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:148
* @route '/developer-api/quickstart'
*/
quickstart.url = (options?: RouteQueryOptions) => {
    return quickstart.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::quickstart
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:148
* @route '/developer-api/quickstart'
*/
quickstart.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: quickstart.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::quickstart
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:148
* @route '/developer-api/quickstart'
*/
quickstart.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: quickstart.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::topup
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:234
* @route '/developer-api/top-up'
*/
export const topup = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: topup.url(options),
    method: 'post',
})

topup.definition = {
    methods: ["post"],
    url: '/developer-api/top-up',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::topup
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:234
* @route '/developer-api/top-up'
*/
topup.url = (options?: RouteQueryOptions) => {
    return topup.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::topup
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:234
* @route '/developer-api/top-up'
*/
topup.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: topup.url(options),
    method: 'post',
})

const developerApi = {
    login: Object.assign(login, loginDf2c2a),
    register: Object.assign(register, register702019),
    logout: Object.assign(logout, logout),
    index: Object.assign(index, index),
    keys: Object.assign(keys, keys),
    usage: Object.assign(usage, usage),
    billing: Object.assign(billing, billing),
    quickstart: Object.assign(quickstart, quickstart),
    topup: Object.assign(topup, topup),
}

export default developerApi