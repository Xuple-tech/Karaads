import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::index
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:82
* @route '/developer-api/usage'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/developer-api/usage',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::index
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:82
* @route '/developer-api/usage'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::index
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:82
* @route '/developer-api/usage'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::index
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:82
* @route '/developer-api/usage'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

const usage = {
    index: Object.assign(index, index),
}

export default usage