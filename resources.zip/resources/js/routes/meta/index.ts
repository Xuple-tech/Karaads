import webhook from './webhook'
import oauth from './oauth'

const meta = {
    webhook: Object.assign(webhook, webhook),
    oauth: Object.assign(oauth, oauth),
}

export default meta