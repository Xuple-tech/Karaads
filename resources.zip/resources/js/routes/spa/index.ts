import voice from './voice'

const spa = {
    voice: Object.assign(voice, voice),
}

export default spa