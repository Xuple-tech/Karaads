import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\SpaVoiceConversationController::index
* @see app/Http/Controllers/Api/SpaVoiceConversationController.php:12
* @route '/api/spa/voice/conversations'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/spa/voice/conversations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\SpaVoiceConversationController::index
* @see app/Http/Controllers/Api/SpaVoiceConversationController.php:12
* @route '/api/spa/voice/conversations'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SpaVoiceConversationController::index
* @see app/Http/Controllers/Api/SpaVoiceConversationController.php:12
* @route '/api/spa/voice/conversations'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\SpaVoiceConversationController::index
* @see app/Http/Controllers/Api/SpaVoiceConversationController.php:12
* @route '/api/spa/voice/conversations'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\SpaVoiceConversationController::store
* @see app/Http/Controllers/Api/SpaVoiceConversationController.php:28
* @route '/api/spa/voice/conversations'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/spa/voice/conversations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\SpaVoiceConversationController::store
* @see app/Http/Controllers/Api/SpaVoiceConversationController.php:28
* @route '/api/spa/voice/conversations'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SpaVoiceConversationController::store
* @see app/Http/Controllers/Api/SpaVoiceConversationController.php:28
* @route '/api/spa/voice/conversations'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\SpaVoiceConversationController::show
* @see app/Http/Controllers/Api/SpaVoiceConversationController.php:46
* @route '/api/spa/voice/conversations/{conversation}'
*/
export const show = (args: { conversation: string | { id: string } } | [conversation: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/spa/voice/conversations/{conversation}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\SpaVoiceConversationController::show
* @see app/Http/Controllers/Api/SpaVoiceConversationController.php:46
* @route '/api/spa/voice/conversations/{conversation}'
*/
show.url = (args: { conversation: string | { id: string } } | [conversation: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { conversation: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { conversation: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            conversation: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        conversation: typeof args.conversation === 'object'
        ? args.conversation.id
        : args.conversation,
    }

    return show.definition.url
            .replace('{conversation}', parsedArgs.conversation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SpaVoiceConversationController::show
* @see app/Http/Controllers/Api/SpaVoiceConversationController.php:46
* @route '/api/spa/voice/conversations/{conversation}'
*/
show.get = (args: { conversation: string | { id: string } } | [conversation: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\SpaVoiceConversationController::show
* @see app/Http/Controllers/Api/SpaVoiceConversationController.php:46
* @route '/api/spa/voice/conversations/{conversation}'
*/
show.head = (args: { conversation: string | { id: string } } | [conversation: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

const voice = {
    index: Object.assign(index, index),
    store: Object.assign(store, store),
    show: Object.assign(show, show),
}

export default voice