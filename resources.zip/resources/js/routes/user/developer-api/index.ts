import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../wayfinder'
import keys from './keys'
/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::index
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:27
* @route '/user/developer-api'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/user/developer-api',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::index
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:27
* @route '/user/developer-api'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::index
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:27
* @route '/user/developer-api'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::index
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:27
* @route '/user/developer-api'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::topup
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:234
* @route '/user/developer-api/top-up'
*/
export const topup = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: topup.url(options),
    method: 'post',
})

topup.definition = {
    methods: ["post"],
    url: '/user/developer-api/top-up',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::topup
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:234
* @route '/user/developer-api/top-up'
*/
topup.url = (options?: RouteQueryOptions) => {
    return topup.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Developer\DeveloperPortalController::topup
* @see app/Http/Controllers/Developer/DeveloperPortalController.php:234
* @route '/user/developer-api/top-up'
*/
topup.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: topup.url(options),
    method: 'post',
})

const developerApi = {
    index: Object.assign(index, index),
    keys: Object.assign(keys, keys),
    topup: Object.assign(topup, topup),
}

export default developerApi