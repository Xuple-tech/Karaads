import conversations from './conversations'
import shares from './shares'

const api = {
    conversations: Object.assign(conversations, conversations),
    shares: Object.assign(shares, shares),
}

export default api