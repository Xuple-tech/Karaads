import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../wayfinder'
/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/docs/legal/terms'
*/
export const terms = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: terms.url(options),
    method: 'get',
})

terms.definition = {
    methods: ["get","head","post","put","patch","delete","options"],
    url: '/docs/legal/terms',
} satisfies RouteDefinition<["get","head","post","put","patch","delete","options"]>

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/docs/legal/terms'
*/
terms.url = (options?: RouteQueryOptions) => {
    return terms.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/docs/legal/terms'
*/
terms.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: terms.url(options),
    method: 'get',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/docs/legal/terms'
*/
terms.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: terms.url(options),
    method: 'head',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/docs/legal/terms'
*/
terms.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: terms.url(options),
    method: 'post',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/docs/legal/terms'
*/
terms.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: terms.url(options),
    method: 'put',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/docs/legal/terms'
*/
terms.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: terms.url(options),
    method: 'patch',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/docs/legal/terms'
*/
terms.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: terms.url(options),
    method: 'delete',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/docs/legal/terms'
*/
terms.options = (options?: RouteQueryOptions): RouteDefinition<'options'> => ({
    url: terms.url(options),
    method: 'options',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/docs/legal/privacy-policy'
*/
export const privacy_policy = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: privacy_policy.url(options),
    method: 'get',
})

privacy_policy.definition = {
    methods: ["get","head","post","put","patch","delete","options"],
    url: '/docs/legal/privacy-policy',
} satisfies RouteDefinition<["get","head","post","put","patch","delete","options"]>

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/docs/legal/privacy-policy'
*/
privacy_policy.url = (options?: RouteQueryOptions) => {
    return privacy_policy.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/docs/legal/privacy-policy'
*/
privacy_policy.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: privacy_policy.url(options),
    method: 'get',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/docs/legal/privacy-policy'
*/
privacy_policy.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: privacy_policy.url(options),
    method: 'head',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/docs/legal/privacy-policy'
*/
privacy_policy.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: privacy_policy.url(options),
    method: 'post',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/docs/legal/privacy-policy'
*/
privacy_policy.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: privacy_policy.url(options),
    method: 'put',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/docs/legal/privacy-policy'
*/
privacy_policy.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: privacy_policy.url(options),
    method: 'patch',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/docs/legal/privacy-policy'
*/
privacy_policy.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: privacy_policy.url(options),
    method: 'delete',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/docs/legal/privacy-policy'
*/
privacy_policy.options = (options?: RouteQueryOptions): RouteDefinition<'options'> => ({
    url: privacy_policy.url(options),
    method: 'options',
})

const legal = {
    terms: Object.assign(terms, terms),
    privacy_policy: Object.assign(privacy_policy, privacy_policy),
}

export default legal