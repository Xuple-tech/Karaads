import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../wayfinder'
import legal from './legal'
/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/docs'
*/
export const main = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: main.url(options),
    method: 'get',
})

main.definition = {
    methods: ["get","head","post","put","patch","delete","options"],
    url: '/docs',
} satisfies RouteDefinition<["get","head","post","put","patch","delete","options"]>

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/docs'
*/
main.url = (options?: RouteQueryOptions) => {
    return main.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/docs'
*/
main.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: main.url(options),
    method: 'get',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/docs'
*/
main.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: main.url(options),
    method: 'head',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/docs'
*/
main.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: main.url(options),
    method: 'post',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/docs'
*/
main.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: main.url(options),
    method: 'put',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/docs'
*/
main.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: main.url(options),
    method: 'patch',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/docs'
*/
main.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: main.url(options),
    method: 'delete',
})

/**
* @see \Illuminate\Routing\RedirectController::__invoke
* @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
* @route '/docs'
*/
main.options = (options?: RouteQueryOptions): RouteDefinition<'options'> => ({
    url: main.url(options),
    method: 'options',
})

/**
* @see \App\Http\Controllers\DeveloperApiDocsController::api
* @see app/Http/Controllers/DeveloperApiDocsController.php:11
* @route '/docs/api'
*/
export const api = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: api.url(options),
    method: 'get',
})

api.definition = {
    methods: ["get","head"],
    url: '/docs/api',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeveloperApiDocsController::api
* @see app/Http/Controllers/DeveloperApiDocsController.php:11
* @route '/docs/api'
*/
api.url = (options?: RouteQueryOptions) => {
    return api.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeveloperApiDocsController::api
* @see app/Http/Controllers/DeveloperApiDocsController.php:11
* @route '/docs/api'
*/
api.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: api.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeveloperApiDocsController::api
* @see app/Http/Controllers/DeveloperApiDocsController.php:11
* @route '/docs/api'
*/
api.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: api.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\DeveloperApiDocsController::agents
* @see app/Http/Controllers/DeveloperApiDocsController.php:33
* @route '/docs/agents'
*/
export const agents = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: agents.url(options),
    method: 'get',
})

agents.definition = {
    methods: ["get","head"],
    url: '/docs/agents',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeveloperApiDocsController::agents
* @see app/Http/Controllers/DeveloperApiDocsController.php:33
* @route '/docs/agents'
*/
agents.url = (options?: RouteQueryOptions) => {
    return agents.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeveloperApiDocsController::agents
* @see app/Http/Controllers/DeveloperApiDocsController.php:33
* @route '/docs/agents'
*/
agents.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: agents.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DeveloperApiDocsController::agents
* @see app/Http/Controllers/DeveloperApiDocsController.php:33
* @route '/docs/agents'
*/
agents.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: agents.url(options),
    method: 'head',
})

const docs = {
    main: Object.assign(main, main),
    legal: Object.assign(legal, legal),
    api: Object.assign(api, api),
    agents: Object.assign(agents, agents),
}

export default docs