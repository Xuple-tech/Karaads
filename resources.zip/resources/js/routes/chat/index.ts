import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../wayfinder'
import api from './api'
import file from './file'
/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/c/new'
*/
export const newMethod = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: newMethod.url(options),
    method: 'get',
})

newMethod.definition = {
    methods: ["get","head"],
    url: '/c/new',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/c/new'
*/
newMethod.url = (options?: RouteQueryOptions) => {
    return newMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/c/new'
*/
newMethod.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: newMethod.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/c/new'
*/
newMethod.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: newMethod.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/c/{conversation}'
*/
export const show = (args: { conversation: string | number } | [conversation: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/c/{conversation}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/c/{conversation}'
*/
show.url = (args: { conversation: string | number } | [conversation: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { conversation: args }
    }

    if (Array.isArray(args)) {
        args = {
            conversation: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        conversation: args.conversation,
    }

    return show.definition.url
            .replace('{conversation}', parsedArgs.conversation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/c/{conversation}'
*/
show.get = (args: { conversation: string | number } | [conversation: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SpaController::__invoke
* @see app/Http/Controllers/SpaController.php:9
* @route '/c/{conversation}'
*/
show.head = (args: { conversation: string | number } | [conversation: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

const chat = {
    api: Object.assign(api, api),
    file: Object.assign(file, file),
    new: Object.assign(newMethod, newMethod),
    show: Object.assign(show, show),
}

export default chat