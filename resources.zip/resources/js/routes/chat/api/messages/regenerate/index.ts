import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Chat\MessageController::stream
* @see app/Http/Controllers/Api/Chat/MessageController.php:115
* @route '/api/chat/messages/{message}/regenerate/stream'
*/
export const stream = (args: { message: string | { id: string } } | [message: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stream.url(args, options),
    method: 'post',
})

stream.definition = {
    methods: ["post"],
    url: '/api/chat/messages/{message}/regenerate/stream',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Chat\MessageController::stream
* @see app/Http/Controllers/Api/Chat/MessageController.php:115
* @route '/api/chat/messages/{message}/regenerate/stream'
*/
stream.url = (args: { message: string | { id: string } } | [message: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { message: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { message: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            message: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        message: typeof args.message === 'object'
        ? args.message.id
        : args.message,
    }

    return stream.definition.url
            .replace('{message}', parsedArgs.message.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Chat\MessageController::stream
* @see app/Http/Controllers/Api/Chat/MessageController.php:115
* @route '/api/chat/messages/{message}/regenerate/stream'
*/
stream.post = (args: { message: string | { id: string } } | [message: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stream.url(args, options),
    method: 'post',
})

const regenerate = {
    stream: Object.assign(stream, stream),
}

export default regenerate