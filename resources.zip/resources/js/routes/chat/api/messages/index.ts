import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../wayfinder'
import stream9fa923 from './stream'
import regenerateA60a3a from './regenerate'
/**
* @see \App\Http\Controllers\Api\Chat\MessageController::store
* @see app/Http/Controllers/Api/Chat/MessageController.php:28
* @route '/api/chat/messages'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/chat/messages',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Chat\MessageController::store
* @see app/Http/Controllers/Api/Chat/MessageController.php:28
* @route '/api/chat/messages'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Chat\MessageController::store
* @see app/Http/Controllers/Api/Chat/MessageController.php:28
* @route '/api/chat/messages'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\Chat\MessageController::stream
* @see app/Http/Controllers/Api/Chat/MessageController.php:59
* @route '/api/chat/messages/stream'
*/
export const stream = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stream.url(options),
    method: 'post',
})

stream.definition = {
    methods: ["post"],
    url: '/api/chat/messages/stream',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Chat\MessageController::stream
* @see app/Http/Controllers/Api/Chat/MessageController.php:59
* @route '/api/chat/messages/stream'
*/
stream.url = (options?: RouteQueryOptions) => {
    return stream.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Chat\MessageController::stream
* @see app/Http/Controllers/Api/Chat/MessageController.php:59
* @route '/api/chat/messages/stream'
*/
stream.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stream.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\Chat\MessageController::regenerate
* @see app/Http/Controllers/Api/Chat/MessageController.php:92
* @route '/api/chat/messages/{message}/regenerate'
*/
export const regenerate = (args: { message: string | { id: string } } | [message: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerate.url(args, options),
    method: 'post',
})

regenerate.definition = {
    methods: ["post"],
    url: '/api/chat/messages/{message}/regenerate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Chat\MessageController::regenerate
* @see app/Http/Controllers/Api/Chat/MessageController.php:92
* @route '/api/chat/messages/{message}/regenerate'
*/
regenerate.url = (args: { message: string | { id: string } } | [message: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { message: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { message: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            message: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        message: typeof args.message === 'object'
        ? args.message.id
        : args.message,
    }

    return regenerate.definition.url
            .replace('{message}', parsedArgs.message.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Chat\MessageController::regenerate
* @see app/Http/Controllers/Api/Chat/MessageController.php:92
* @route '/api/chat/messages/{message}/regenerate'
*/
regenerate.post = (args: { message: string | { id: string } } | [message: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerate.url(args, options),
    method: 'post',
})

const messages = {
    store: Object.assign(store, store),
    stream: Object.assign(stream, stream9fa923),
    regenerate: Object.assign(regenerate, regenerateA60a3a),
}

export default messages