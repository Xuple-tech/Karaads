import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../../../wayfinder'
/**
* @see routes/api.php:69
* @route '/api/chat/messages/stream'
*/
export const getGuard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getGuard.url(options),
    method: 'get',
})

getGuard.definition = {
    methods: ["get","head"],
    url: '/api/chat/messages/stream',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/api.php:69
* @route '/api/chat/messages/stream'
*/
getGuard.url = (options?: RouteQueryOptions) => {
    return getGuard.definition.url + queryParams(options)
}

/**
* @see routes/api.php:69
* @route '/api/chat/messages/stream'
*/
getGuard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getGuard.url(options),
    method: 'get',
})

/**
* @see routes/api.php:69
* @route '/api/chat/messages/stream'
*/
getGuard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getGuard.url(options),
    method: 'head',
})

const stream = {
    getGuard: Object.assign(getGuard, getGuard),
}

export default stream