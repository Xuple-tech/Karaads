import conversations from './conversations'
import messages from './messages'

const api = {
    conversations: Object.assign(conversations, conversations),
    messages: Object.assign(messages, messages),
}

export default api