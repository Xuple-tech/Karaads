import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::store
* @see app/Http/Controllers/Admin/DeveloperApiController.php:136
* @route '/admin/developer-api/models'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/developer-api/models',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::store
* @see app/Http/Controllers/Admin/DeveloperApiController.php:136
* @route '/admin/developer-api/models'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::store
* @see app/Http/Controllers/Admin/DeveloperApiController.php:136
* @route '/admin/developer-api/models'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::update
* @see app/Http/Controllers/Admin/DeveloperApiController.php:157
* @route '/admin/developer-api/models/{apiModel}'
*/
export const update = (args: { apiModel: string | { id: string } } | [apiModel: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/developer-api/models/{apiModel}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::update
* @see app/Http/Controllers/Admin/DeveloperApiController.php:157
* @route '/admin/developer-api/models/{apiModel}'
*/
update.url = (args: { apiModel: string | { id: string } } | [apiModel: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { apiModel: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { apiModel: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            apiModel: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        apiModel: typeof args.apiModel === 'object'
        ? args.apiModel.id
        : args.apiModel,
    }

    return update.definition.url
            .replace('{apiModel}', parsedArgs.apiModel.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::update
* @see app/Http/Controllers/Admin/DeveloperApiController.php:157
* @route '/admin/developer-api/models/{apiModel}'
*/
update.put = (args: { apiModel: string | { id: string } } | [apiModel: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::toggle
* @see app/Http/Controllers/Admin/DeveloperApiController.php:177
* @route '/admin/developer-api/models/{apiModel}/toggle'
*/
export const toggle = (args: { apiModel: string | { id: string } } | [apiModel: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggle.url(args, options),
    method: 'post',
})

toggle.definition = {
    methods: ["post"],
    url: '/admin/developer-api/models/{apiModel}/toggle',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::toggle
* @see app/Http/Controllers/Admin/DeveloperApiController.php:177
* @route '/admin/developer-api/models/{apiModel}/toggle'
*/
toggle.url = (args: { apiModel: string | { id: string } } | [apiModel: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { apiModel: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { apiModel: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            apiModel: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        apiModel: typeof args.apiModel === 'object'
        ? args.apiModel.id
        : args.apiModel,
    }

    return toggle.definition.url
            .replace('{apiModel}', parsedArgs.apiModel.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::toggle
* @see app/Http/Controllers/Admin/DeveloperApiController.php:177
* @route '/admin/developer-api/models/{apiModel}/toggle'
*/
toggle.post = (args: { apiModel: string | { id: string } } | [apiModel: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggle.url(args, options),
    method: 'post',
})

const models = {
    store: Object.assign(store, store),
    update: Object.assign(update, update),
    toggle: Object.assign(toggle, toggle),
}

export default models