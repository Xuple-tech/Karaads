import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::toggle
* @see app/Http/Controllers/Admin/DeveloperApiController.php:184
* @route '/admin/developer-api/keys/{developerApiKey}/toggle'
*/
export const toggle = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggle.url(args, options),
    method: 'post',
})

toggle.definition = {
    methods: ["post"],
    url: '/admin/developer-api/keys/{developerApiKey}/toggle',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::toggle
* @see app/Http/Controllers/Admin/DeveloperApiController.php:184
* @route '/admin/developer-api/keys/{developerApiKey}/toggle'
*/
toggle.url = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { developerApiKey: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { developerApiKey: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            developerApiKey: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        developerApiKey: typeof args.developerApiKey === 'object'
        ? args.developerApiKey.id
        : args.developerApiKey,
    }

    return toggle.definition.url
            .replace('{developerApiKey}', parsedArgs.developerApiKey.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::toggle
* @see app/Http/Controllers/Admin/DeveloperApiController.php:184
* @route '/admin/developer-api/keys/{developerApiKey}/toggle'
*/
toggle.post = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggle.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::regenerate
* @see app/Http/Controllers/Admin/DeveloperApiController.php:191
* @route '/admin/developer-api/keys/{developerApiKey}/regenerate'
*/
export const regenerate = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerate.url(args, options),
    method: 'post',
})

regenerate.definition = {
    methods: ["post"],
    url: '/admin/developer-api/keys/{developerApiKey}/regenerate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::regenerate
* @see app/Http/Controllers/Admin/DeveloperApiController.php:191
* @route '/admin/developer-api/keys/{developerApiKey}/regenerate'
*/
regenerate.url = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { developerApiKey: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { developerApiKey: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            developerApiKey: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        developerApiKey: typeof args.developerApiKey === 'object'
        ? args.developerApiKey.id
        : args.developerApiKey,
    }

    return regenerate.definition.url
            .replace('{developerApiKey}', parsedArgs.developerApiKey.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::regenerate
* @see app/Http/Controllers/Admin/DeveloperApiController.php:191
* @route '/admin/developer-api/keys/{developerApiKey}/regenerate'
*/
regenerate.post = (args: { developerApiKey: string | { id: string } } | [developerApiKey: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerate.url(args, options),
    method: 'post',
})

const keys = {
    toggle: Object.assign(toggle, toggle),
    regenerate: Object.assign(regenerate, regenerate),
}

export default keys