import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../wayfinder'
import models from './models'
import keys from './keys'
import wallets from './wallets'
/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::index
* @see app/Http/Controllers/Admin/DeveloperApiController.php:26
* @route '/admin/developer-api'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/developer-api',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::index
* @see app/Http/Controllers/Admin/DeveloperApiController.php:26
* @route '/admin/developer-api'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::index
* @see app/Http/Controllers/Admin/DeveloperApiController.php:26
* @route '/admin/developer-api'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\DeveloperApiController::index
* @see app/Http/Controllers/Admin/DeveloperApiController.php:26
* @route '/admin/developer-api'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

const developerApi = {
    index: Object.assign(index, index),
    models: Object.assign(models, models),
    keys: Object.assign(keys, keys),
    wallets: Object.assign(wallets, wallets),
}

export default developerApi