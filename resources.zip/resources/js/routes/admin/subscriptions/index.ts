import plans from './plans'
import features from './features'

const subscriptions = {
    plans: Object.assign(plans, plans),
    features: Object.assign(features, features),
}

export default subscriptions