import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../wayfinder'
import password from './password'
import verification from './verification'
/**
* @see \App\Http\Controllers\Api\SessionAuthController::user
* @see app/Http/Controllers/Api/SessionAuthController.php:24
* @route '/api/session/user'
*/
export const user = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: user.url(options),
    method: 'get',
})

user.definition = {
    methods: ["get","head"],
    url: '/api/session/user',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\SessionAuthController::user
* @see app/Http/Controllers/Api/SessionAuthController.php:24
* @route '/api/session/user'
*/
user.url = (options?: RouteQueryOptions) => {
    return user.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SessionAuthController::user
* @see app/Http/Controllers/Api/SessionAuthController.php:24
* @route '/api/session/user'
*/
user.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: user.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\SessionAuthController::user
* @see app/Http/Controllers/Api/SessionAuthController.php:24
* @route '/api/session/user'
*/
user.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: user.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\SessionAuthController::login
* @see app/Http/Controllers/Api/SessionAuthController.php:35
* @route '/api/session/login'
*/
export const login = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

login.definition = {
    methods: ["post"],
    url: '/api/session/login',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\SessionAuthController::login
* @see app/Http/Controllers/Api/SessionAuthController.php:35
* @route '/api/session/login'
*/
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SessionAuthController::login
* @see app/Http/Controllers/Api/SessionAuthController.php:35
* @route '/api/session/login'
*/
login.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\SessionAuthController::register
* @see app/Http/Controllers/Api/SessionAuthController.php:62
* @route '/api/session/register'
*/
export const register = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

register.definition = {
    methods: ["post"],
    url: '/api/session/register',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\SessionAuthController::register
* @see app/Http/Controllers/Api/SessionAuthController.php:62
* @route '/api/session/register'
*/
register.url = (options?: RouteQueryOptions) => {
    return register.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SessionAuthController::register
* @see app/Http/Controllers/Api/SessionAuthController.php:62
* @route '/api/session/register'
*/
register.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\SessionAuthController::logout
* @see app/Http/Controllers/Api/SessionAuthController.php:96
* @route '/api/session/logout'
*/
export const logout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

logout.definition = {
    methods: ["post"],
    url: '/api/session/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\SessionAuthController::logout
* @see app/Http/Controllers/Api/SessionAuthController.php:96
* @route '/api/session/logout'
*/
logout.url = (options?: RouteQueryOptions) => {
    return logout.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SessionAuthController::logout
* @see app/Http/Controllers/Api/SessionAuthController.php:96
* @route '/api/session/logout'
*/
logout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

const session = {
    user: Object.assign(user, user),
    login: Object.assign(login, login),
    register: Object.assign(register, register),
    password: Object.assign(password, password),
    verification: Object.assign(verification, verification),
    logout: Object.assign(logout, logout),
}

export default session