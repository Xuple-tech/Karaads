import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\SessionAuthController::email
* @see app/Http/Controllers/Api/SessionAuthController.php:105
* @route '/api/session/forgot-password'
*/
export const email = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: email.url(options),
    method: 'post',
})

email.definition = {
    methods: ["post"],
    url: '/api/session/forgot-password',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\SessionAuthController::email
* @see app/Http/Controllers/Api/SessionAuthController.php:105
* @route '/api/session/forgot-password'
*/
email.url = (options?: RouteQueryOptions) => {
    return email.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SessionAuthController::email
* @see app/Http/Controllers/Api/SessionAuthController.php:105
* @route '/api/session/forgot-password'
*/
email.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: email.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\SessionAuthController::reset
* @see app/Http/Controllers/Api/SessionAuthController.php:119
* @route '/api/session/reset-password'
*/
export const reset = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reset.url(options),
    method: 'post',
})

reset.definition = {
    methods: ["post"],
    url: '/api/session/reset-password',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\SessionAuthController::reset
* @see app/Http/Controllers/Api/SessionAuthController.php:119
* @route '/api/session/reset-password'
*/
reset.url = (options?: RouteQueryOptions) => {
    return reset.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SessionAuthController::reset
* @see app/Http/Controllers/Api/SessionAuthController.php:119
* @route '/api/session/reset-password'
*/
reset.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reset.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\SessionAuthController::confirm
* @see app/Http/Controllers/Api/SessionAuthController.php:175
* @route '/api/session/confirm-password'
*/
export const confirm = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: confirm.url(options),
    method: 'post',
})

confirm.definition = {
    methods: ["post"],
    url: '/api/session/confirm-password',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\SessionAuthController::confirm
* @see app/Http/Controllers/Api/SessionAuthController.php:175
* @route '/api/session/confirm-password'
*/
confirm.url = (options?: RouteQueryOptions) => {
    return confirm.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SessionAuthController::confirm
* @see app/Http/Controllers/Api/SessionAuthController.php:175
* @route '/api/session/confirm-password'
*/
confirm.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: confirm.url(options),
    method: 'post',
})

const password = {
    email: Object.assign(email, email),
    reset: Object.assign(reset, reset),
    confirm: Object.assign(confirm, confirm),
}

export default password