import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../wayfinder'
/**
* @see routes/web.php:115
* @route '/widget/embed.js'
*/
export const loader = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: loader.url(options),
    method: 'get',
})

loader.definition = {
    methods: ["get","head"],
    url: '/widget/embed.js',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:115
* @route '/widget/embed.js'
*/
loader.url = (options?: RouteQueryOptions) => {
    return loader.definition.url + queryParams(options)
}

/**
* @see routes/web.php:115
* @route '/widget/embed.js'
*/
loader.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: loader.url(options),
    method: 'get',
})

/**
* @see routes/web.php:115
* @route '/widget/embed.js'
*/
loader.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: loader.url(options),
    method: 'head',
})

const embed = {
    loader: Object.assign(loader, loader),
}

export default embed