import embed from './embed'

const widget = {
    embed: Object.assign(embed, embed),
}

export default widget