<?php

namespace App\Http\Controllers;

use Illuminate\Contracts\View\View;

class SpaController extends Controller
{
    public function __invoke(): View
    {
        return view('spa', [
            'appearance' => 'system',
        ]);
    }
}
