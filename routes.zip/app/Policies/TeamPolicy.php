<?php

namespace App\Policies;

use App\Models\Team;
use App\Models\User;

class TeamPolicy
{
    public function viewAny(User $user): bool
    {
        return true;
    }

    public function view(User $user, Team $team): bool
    {
        return $team->hasMember($user);
    }

    public function create(User $user): bool
    {
        return true;
    }

    public function update(User $user, Team $team): bool
    {
        return $team->isAdmin($user);
    }

    public function delete(User $user, Team $team): bool
    {
        return $team->isOwner($user);
    }

    public function manageMembership(User $user, Team $team): bool
    {
        return $team->isAdmin($user) || $team->isManager($user);
    }

    public function manageInvitations(User $user, Team $team): bool
    {
        return $team->isAdmin($user) || $team->isManager($user);
    }
}
